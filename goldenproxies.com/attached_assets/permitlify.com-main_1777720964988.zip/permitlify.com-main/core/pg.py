"""
Postgres connection helper for Supabase.

Uses psycopg3 with a small thread-safe connection pool. The Supabase pooler
endpoint (port 6543) is the *transaction* pooler, so we disable named prepared
statements via prepare_threshold=None.
"""
import os
import threading
import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

_pool = None
_lock = threading.Lock()


def _dsn() -> str:
    url = os.environ.get('SUPABASE_DATABASE_URL')
    if not url:
        raise RuntimeError(
            "SUPABASE_DATABASE_URL is not set. Add it as a Replit secret "
            "with the Supabase Postgres connection string."
        )
    if 'sslmode=' not in url:
        url += ('&' if '?' in url else '?') + 'sslmode=require'
    return url


def get_pool() -> ConnectionPool:
    global _pool
    if _pool is None:
        with _lock:
            if _pool is None:
                # min_size=2 so each gunicorn worker boots with two
                # warm connections in hand (see gunicorn.conf.py
                # post_fork hook, which calls get_pool().wait() right
                # after fork). Pre-PR-#112 this was 1, which meant the
                # worker's *second* concurrent request still paid the
                # ~290 ms Supabase-RTT cold-connection cost.
                _pool = ConnectionPool(
                    conninfo=_dsn(),
                    min_size=2,
                    max_size=8,
                    kwargs={
                        'prepare_threshold': None,
                        'row_factory': dict_row,
                    },
                    open=True,
                )
    return _pool


def conn():
    """Context manager that yields a pooled connection (auto-commits on exit)."""
    return get_pool().connection()


def query(sql: str, params: tuple = ()) -> list[dict]:
    with conn() as c, c.cursor() as cur:
        cur.execute(sql, params)
        if cur.description is None:
            return []
        return list(cur.fetchall())


def query_one(sql: str, params: tuple = ()) -> dict | None:
    rows = query(sql, params)
    return rows[0] if rows else None


def execute(sql: str, params: tuple = ()) -> int:
    with conn() as c, c.cursor() as cur:
        cur.execute(sql, params)
        return cur.rowcount


def execute_returning(sql: str, params: tuple = ()) -> dict | None:
    with conn() as c, c.cursor() as cur:
        cur.execute(sql, params)
        if cur.description is None:
            return None
        row = cur.fetchone()
        return row
