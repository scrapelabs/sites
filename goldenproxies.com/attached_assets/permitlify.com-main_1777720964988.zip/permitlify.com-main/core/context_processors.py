from . import whop as wp


_FALLBACK_PRICING = {
    'mode': 'prod', 'is_dev': False,
    'starter_monthly':  29, 'starter_annual':   23,
    'pro_monthly':      99, 'pro_annual':       79,
    'agency_monthly':  249, 'agency_annual':   199,
    'starter_monthly_total':  348, 'starter_annual_total':  276, 'starter_annual_save':  72,
    'pro_monthly_total':     1188, 'pro_annual_total':      948, 'pro_annual_save':     240,
    'agency_monthly_total':  2988, 'agency_annual_total':  2388, 'agency_annual_save':  600,
}


def pricing(request):
    """Expose mode-aware plan pricing dict to every template."""
    try:
        return {'pricing': wp.get_pricing_dict()}
    except Exception:
        return {'pricing': _FALLBACK_PRICING}


def site_origin(request):
    """
    Expose the canonical site origin (e.g. ``https://permitlify.com``) to
    every template so SEO tags (canonical, OG, Twitter, JSON-LD) can build
    absolute URLs that always point at the production domain — never at
    whatever Host header reached the server.

    Falls back to the live request scheme + host when ``SITE_ORIGIN`` is
    not set (local dev, staging, etc.) so canonicals still work end-to-end.
    """
    from django.conf import settings as _s
    origin = getattr(_s, 'SITE_ORIGIN', '') or ''
    if not origin:
        try:
            origin = f"{request.scheme}://{request.get_host()}"
        except Exception:
            origin = ''
    return {'site_origin': origin}


def user_session(request):
    """
    Expose session-derived user info to every template.

    Public pages (homepage, pricing, blog, etc.) use this to swap the
    "Log In / Get Started Free" buttons for a single "Dashboard" link
    when the visitor is already authenticated. Authenticated app pages
    can also rely on these without re-reading the session in every view.

    Always returns the keys (with falsy defaults) so templates can use
    `{% if user_logged_in %}` without worrying about missing variables.
    """
    s = getattr(request, 'session', None)
    if s is None:
        return {
            'user_logged_in': False, 'user_id': None,
            'user_email': '', 'user_name': '',
            'user_initials': '', 'user_plan': '',
        }
    uid = s.get('user_id')
    return {
        'user_logged_in': bool(uid),
        'user_id': uid,
        'user_email': s.get('user_email', '') or '',
        'user_name': s.get('user_name', '') or '',
        'user_initials': s.get('user_initials', '') or '',
        'user_plan': s.get('user_plan', '') or '',
    }
