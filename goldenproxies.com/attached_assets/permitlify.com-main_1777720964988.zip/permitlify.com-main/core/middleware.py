"""Performance-focused middleware for Permitlify.

PublicCacheMiddleware adds a short ``Cache-Control: public, max-age=…,
stale-while-revalidate=…`` header to anonymous GET responses for our
marketing pages, so a returning visitor (or any CDN in front of the app
later) can serve the cached HTML for the next few minutes instead of
re-rendering on every hit. This pairs with the in-process settings cache
in ``core.whop`` — together they take the homepage TTFB from ~1.2s of DB
wait down to a few ms on cache hits.

Important:
  - Only applied to anonymous visitors (no ``user_id`` session, no auth
    headers). Logged-in users see personalised nav/badges/etc, so we
    keep their pages private.
  - Only applied to GET / HEAD requests on a strict whitelist of paths
    (or path prefixes for blog post slugs). Anything else falls through
    untouched.
  - Skipped if a cookie is being set on the response, since caching a
    response that mutates client state would be a correctness bug.
  - Vary: Cookie is added so a CDN keyed on cookies still distinguishes
    logged-in pages.
"""
from __future__ import annotations
from typing import Callable

# Exact paths that can safely be cached publicly. Blog post detail pages
# match by prefix below.
_PUBLIC_EXACT = {
    '/',
    '/our-story/',
    '/how-it-works/',
    '/pricing/',
    '/careers/',
    '/privacy/',
    '/terms/',
    '/blog/',
}
_PUBLIC_PREFIXES = (
    '/blog/',     # /blog/<slug>/
)
# 5 min fresh + 10 min stale-while-revalidate. Short enough that pricing
# edits in the admin show up quickly, long enough to absorb traffic spikes.
_MAX_AGE = 300
_SWR     = 600


def _is_anonymous(request) -> bool:
    """A request is 'anonymous' for caching purposes when there's no
    logged-in user in the session and no Authorization header. We treat
    *any* session user as logged in even if the row is gone, because the
    rendered nav still differs."""
    if request.session.get('user_id'):
        return False
    if request.META.get('HTTP_AUTHORIZATION'):
        return False
    return True


def _is_public_path(path: str) -> bool:
    if path in _PUBLIC_EXACT:
        return True
    for pre in _PUBLIC_PREFIXES:
        # e.g. /blog/some-slug/ — but not /blog/ itself (already in EXACT)
        if path.startswith(pre) and len(path) > len(pre):
            return True
    return False


class PublicCacheMiddleware:
    def __init__(self, get_response: Callable):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if request.method not in ('GET', 'HEAD'):
            return response
        if response.status_code != 200:
            return response
        if not _is_public_path(request.path):
            return response
        if not _is_anonymous(request):
            return response
        # Don't cache responses that set/clear cookies — they're carrying
        # client state, and caching would replay it for everyone.
        if response.cookies:
            return response
        # Don't override an explicit no-cache the view already set.
        existing = response.get('Cache-Control', '').lower()
        if 'no-store' in existing or 'private' in existing:
            return response
        response['Cache-Control'] = (
            f'public, max-age={_MAX_AGE}, '
            f'stale-while-revalidate={_SWR}'
        )
        # Cookie + Accept-Encoding so a CDN distinguishes logged-in vs
        # anonymous (different HTML) and gzip vs identity.
        existing_vary = response.get('Vary', '')
        vary_parts = {p.strip() for p in existing_vary.split(',') if p.strip()}
        vary_parts.update({'Cookie', 'Accept-Encoding'})
        response['Vary'] = ', '.join(sorted(vary_parts))
        return response


class AdminHTMLCacheInvalidationMiddleware:
    """Drop the per-worker admin HTML cache after any admin write.

    Pairs with ``core.cache.cached_admin_html`` (the decorator that
    stores rendered admin GET responses for ~15 s). Whenever the admin
    does *anything* mutating under ``/admin-panel/*`` — delete a user,
    flip a Whop mode, save email settings, ban an email, etc. — this
    middleware flushes every cached admin page in this worker so the
    next GET re-renders from fresh DB state.

    Coarse-but-correct: the cache only ever holds ~10 admin pages
    × <100 KB each, so blowing the whole thing away on any write is
    free and immune to "I forgot to invalidate that one path" bugs.
    Place this AFTER CommonMiddleware so we only see the resolved
    request.path / request.method, and AFTER CsrfViewMiddleware so
    invalid POSTs (which return 403 before the view runs) don't
    needlessly invalidate.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        # Only invalidate on successful writes to /admin-panel/*.
        # GET/HEAD never mutate state, and a 4xx/5xx means the write
        # didn't happen so there's nothing to invalidate.
        if (request.method not in ('GET', 'HEAD')
                and request.path.startswith('/admin-panel/')
                and 200 <= getattr(response, 'status_code', 0) < 400):
            try:
                from .cache import invalidate_admin_html_cache
                invalidate_admin_html_cache()
            except Exception:
                # Cache is best-effort; never break the response on
                # an invalidation hiccup.
                pass
        return response
