"""Transactional email sender for Permitlify.

Wraps the Resend HTTP API (https://resend.com/docs/api-reference/emails/send-email)
behind a tiny ``send_email`` helper that:

* Looks up the From address / display name / reply-to for the given service
  category (billing, support, alerts, marketing, system) from
  ``system_settings`` so admins can change them at runtime from the admin panel.
* Uses Resend if ``RESEND_API_KEY`` is set, falls back to Django's SMTP
  backend if SMTP env vars are configured, otherwise returns a clear error
  pointing the admin at the right secret.
* Returns ``(ok: bool, error: str)`` instead of raising — the test workflow
  in ``admin_email_settings`` surfaces the error string directly to the UI.

Pure stdlib + Django; no new third-party deps.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any

from .db import get_system_setting


_RESEND_ENDPOINT = 'https://api.resend.com/emails'
_RESEND_TIMEOUT  = 12  # seconds


# ---- Transport credential helpers -------------------------------------------
# Same pattern as core.whop._db_setting: prefer the value saved in
# ``system_settings`` (admin-editable from /admin-panel/email-settings/),
# fall back to the env var so existing deployments keep working.
def _transport_setting(db_key: str, env_key: str, default: str = '') -> str:
    val = get_system_setting(db_key, '')
    if val:
        return str(val)
    return (os.environ.get(env_key) or default or '').strip()


def get_resend_api_key() -> str:
    return _transport_setting('email_resend_api_key', 'RESEND_API_KEY')


def get_smtp_config() -> dict[str, Any]:
    """Return SMTP config — DB first, env fallback. Empty strings on absent."""
    return {
        'host':     _transport_setting('email_smtp_host',     'EMAIL_HOST'),
        'port':     _transport_setting('email_smtp_port',     'EMAIL_PORT', '587'),
        'user':     _transport_setting('email_smtp_user',     'EMAIL_HOST_USER'),
        'password': _transport_setting('email_smtp_password', 'EMAIL_HOST_PASSWORD'),
        'use_tls':  (get_system_setting('email_smtp_use_tls', '') or
                     os.environ.get('EMAIL_USE_TLS', 'true')).strip().lower() in ('1', 'true', 'yes', 'on'),
    }


def get_transport_status() -> dict[str, Any]:
    """Summarise which transport (if any) is currently active.

    Used by the admin page banner so the operator knows at a glance
    whether saving credentials made the page "live".
    """
    if get_resend_api_key():
        return {'active': 'resend', 'label': 'Resend (HTTP API)', 'configured': True}
    smtp = get_smtp_config()
    if smtp['user'] and smtp['host']:
        return {'active': 'smtp',
                'label': f"SMTP ({smtp['host']}:{smtp['port']} as {smtp['user']})",
                'configured': True}
    return {'active': '', 'label': 'None', 'configured': False}


# Service-key -> default From / Name / Reply-To, mirrors core.views._EMAIL_SERVICES.
# Duplicated minimally here so this module has no circular import on views.py.
_DEFAULTS = {
    'billing':   {'from_email': 'billing@permitlify.com',  'from_name': 'Permitlify Billing',  'reply_to': 'billing@permitlify.com'},
    'support':   {'from_email': 'support@permitlify.com',  'from_name': 'Permitlify Support',  'reply_to': 'support@permitlify.com'},
    'alerts':    {'from_email': 'alerts@permitlify.com',   'from_name': 'Permitlify Alerts',   'reply_to': 'noreply@permitlify.com'},
    'marketing': {'from_email': 'hello@permitlify.com',    'from_name': 'Permitlify Team',     'reply_to': 'hello@permitlify.com'},
    'system':    {'from_email': 'noreply@permitlify.com',  'from_name': 'Permitlify',          'reply_to': ''},
}


def get_service_sender(svc_key: str) -> dict[str, str]:
    """Return the resolved {from_email, from_name, reply_to} for a service.

    Falls back to the hardcoded defaults if no admin override is saved.
    Unknown service keys fall back to the ``system`` defaults so callers
    never crash on a typo.
    """
    defs = _DEFAULTS.get(svc_key) or _DEFAULTS['system']
    return {
        'from_email': get_system_setting(f'{svc_key}_from_email', defs['from_email']) or defs['from_email'],
        'from_name':  get_system_setting(f'{svc_key}_from_name',  defs['from_name'])  or defs['from_name'],
        'reply_to':   get_system_setting(f'{svc_key}_reply_to',   defs['reply_to'])   or defs['reply_to'],
    }


def _format_from(name: str, email: str) -> str:
    """Build an RFC 5322 ``From`` header value: ``"Name" <email>``."""
    name = (name or '').strip()
    email = (email or '').strip()
    if not email:
        return ''
    if not name:
        return email
    # Strip quotes that would break the header
    safe_name = name.replace('"', '')
    return f'"{safe_name}" <{email}>'


def _send_via_resend(api_key: str, payload: dict[str, Any]) -> tuple[bool, str]:
    """POST to the Resend API. Returns (ok, error_or_id)."""
    body = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(
        _RESEND_ENDPOINT,
        data=body,
        method='POST',
        headers={
            'Authorization': f'Bearer {api_key}',
            'Content-Type':  'application/json',
            'User-Agent':    'permitlify-admin',
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=_RESEND_TIMEOUT) as resp:
            data = json.loads(resp.read().decode('utf-8') or '{}')
            msg_id = data.get('id') or ''
            return True, msg_id
    except urllib.error.HTTPError as e:
        # Resend returns JSON {message, name} on errors — surface message.
        try:
            err_body = json.loads(e.read().decode('utf-8') or '{}')
            err_msg  = err_body.get('message') or err_body.get('name') or str(e)
        except Exception:
            err_msg = f'Resend API error (HTTP {e.code})'
        return False, err_msg
    except urllib.error.URLError as e:
        return False, f'Network error contacting Resend: {e.reason}'
    except Exception as e:
        return False, f'Unexpected Resend error: {e}'


def _send_via_smtp(
    *,
    from_header: str,
    reply_to: str,
    to: str,
    subject: str,
    text: str,
    html: str | None,
) -> tuple[bool, str]:
    """SMTP path using the credentials saved in admin → Email Settings
    (DB) with env-var fallback.

    We bypass Django's global EMAIL_BACKEND because the admin can change
    SMTP creds at runtime without restarting; building an EmailBackend
    per-call honours those overrides immediately. Returns (ok, error).
    """
    smtp = get_smtp_config()
    if not smtp['user'] or not smtp['host']:
        return False, (
            'No email transport configured. Add a Resend API key (recommended) '
            'or SMTP host + user + password in the Transport section above, '
            'or via the RESEND_API_KEY / EMAIL_HOST_* env vars.'
        )
    try:
        from django.core.mail.backends.smtp import EmailBackend
        from django.core.mail.message import EmailMultiAlternatives
        try:
            port_int = int(smtp['port'])
        except (TypeError, ValueError):
            port_int = 587
        backend = EmailBackend(
            host=smtp['host'],
            port=port_int,
            username=smtp['user'],
            password=smtp['password'],
            use_tls=bool(smtp['use_tls']),
            timeout=15,
        )
        msg = EmailMultiAlternatives(
            subject=subject,
            body=text,
            from_email=from_header,
            to=[to],
            reply_to=[reply_to] if reply_to else None,
            connection=backend,
        )
        if html:
            msg.attach_alternative(html, 'text/html')
        sent = msg.send(fail_silently=False)
        return (sent > 0, '' if sent > 0 else 'SMTP server accepted but rejected the message.')
    except Exception as e:
        return False, f'SMTP send failed: {e}'


def send_email(
    svc_key: str,
    to: str,
    subject: str,
    body_text: str,
    body_html: str | None = None,
) -> tuple[bool, str]:
    """Send a transactional email for the given service category.

    Returns ``(True, message_id_or_empty)`` on success, ``(False, error)``
    on failure. Never raises so callers (including the admin test endpoint)
    can show the error string directly.
    """
    to = (to or '').strip()
    if not to or '@' not in to:
        return False, 'Recipient email is required and must be valid.'
    subject = (subject or '').strip()
    if not subject:
        return False, 'Subject is required.'
    if not (body_text or '').strip() and not (body_html or '').strip():
        return False, 'Body is required.'

    sender = get_service_sender(svc_key)
    from_header = _format_from(sender['from_name'], sender['from_email'])
    if not from_header:
        return False, f'No From address configured for service "{svc_key}".'

    api_key = get_resend_api_key()
    if api_key:
        payload: dict[str, Any] = {
            'from':    from_header,
            'to':      [to],
            'subject': subject,
            'text':    body_text or '',
        }
        if body_html:
            payload['html'] = body_html
        if sender['reply_to']:
            payload['reply_to'] = sender['reply_to']
        return _send_via_resend(api_key, payload)

    return _send_via_smtp(
        from_header=from_header,
        reply_to=sender['reply_to'],
        to=to,
        subject=subject,
        text=body_text or '',
        html=body_html,
    )


def get_service_health(svc_key: str) -> dict[str, Any]:
    """Return verification metadata for a service category.

    Stored in system_settings:
      - {svc}_verified_at      ISO 8601 timestamp of last admin "mark as working" click
      - {svc}_verified_by      Admin email who marked it
      - {svc}_last_test_at     ISO 8601 of most recent test send attempt
      - {svc}_last_test_to     Recipient of last test send
      - {svc}_last_test_status 'sent' | 'failed' | ''
      - {svc}_last_test_error  Error string if status == 'failed'

    Returns a flat dict suitable for direct template consumption.
    """
    return {
        'verified_at':      get_system_setting(f'{svc_key}_verified_at',      '') or '',
        'verified_by':      get_system_setting(f'{svc_key}_verified_by',      '') or '',
        'last_test_at':     get_system_setting(f'{svc_key}_last_test_at',     '') or '',
        'last_test_to':     get_system_setting(f'{svc_key}_last_test_to',     '') or '',
        'last_test_status': get_system_setting(f'{svc_key}_last_test_status', '') or '',
        'last_test_error':  get_system_setting(f'{svc_key}_last_test_error',  '') or '',
    }
