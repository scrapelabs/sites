"""Accela permit scraper — Firecrawl + Claude AI.

A "scraper" in this codebase is a saved Accela CapDetail URL plus
metadata. Each run fetches one or more URLs through Firecrawl (which
handles the .NET WebForms JS rendering), feeds the resulting markdown
to Claude with a strict extraction prompt, and pushes the structured
permit dict into the existing ``permits`` table via ``upsert_permit``.

Background runs are tracked in ``scraper_runs`` so the admin UI can
poll progress and render a progress bar without any external job
queue (we use the same fire-and-forget daemon-thread pattern the
email + auth-code subsystems use).
"""

from __future__ import annotations

import json
import logging
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, date

from . import db, pg
from .db import (
    add_supported_city,
    append_scraper_run_step,
    create_scraper_run,
    get_scraper,
    get_supported_cities,
    get_system_setting,
    refresh_scraper_total_permits,
    update_scraper,
    update_scraper_run,
    upsert_permit,
)

log = logging.getLogger(__name__)

# ── Per-thread "current scraper run" tracker ─────────────────────────
# So firecrawl_scrape() / claude_extract() can stamp every API call
# with the run id without changing their public signature (and without
# threading run_id through every helper). The cron worker enters this
# context for the whole per-target unit of work.

_call_ctx = threading.local()


class _track_run:
    """Context manager: tags every Firecrawl/Claude call made on the
    current thread with the given scraper_run_id (and optional source
    label for the usage tables)."""

    def __init__(self, run_id, source: str = 'accela'):
        self.run_id = int(run_id) if run_id else None
        self.source = source
        self._prev = None

    def __enter__(self):
        self._prev = (
            getattr(_call_ctx, 'run_id', None),
            getattr(_call_ctx, 'source', None),
        )
        _call_ctx.run_id = self.run_id
        _call_ctx.source = self.source
        return self

    def __exit__(self, exc_type, exc, tb):
        prev_run, prev_src = self._prev
        _call_ctx.run_id = prev_run
        _call_ctx.source = prev_src
        return False


def _current_run_id():
    return getattr(_call_ctx, 'run_id', None)


def _current_source(default: str = 'accela'):
    return getattr(_call_ctx, 'source', None) or default


FIRECRAWL_URL    = 'https://api.firecrawl.dev/v1/scrape'
ANTHROPIC_URL    = 'https://api.anthropic.com/v1/messages'
ANTHROPIC_VERSION = '2023-06-01'
DEFAULT_MODEL    = 'claude-3-5-sonnet-latest'


class ScraperError(Exception):
    """Raised by scraper helpers; carries a user-readable message."""


# ─────────────────────────── URL helpers ──────────────────────────────

def parse_accela_url(url: str) -> dict:
    """Extract Accela CapDetail params (agencyCode, Module, capID1/2/3)
    from a URL. Returns an empty dict on a non-Accela URL."""
    try:
        parsed = urllib.parse.urlparse((url or '').strip())
    except Exception:
        return {}
    # Strict host allowlist — `endswith('accela.com')` would falsely
    # accept attacker-controlled hosts like `evilaccela.com`. Use the
    # parsed hostname (lower-cased, no port) and require it to BE
    # `accela.com` or a true subdomain (`*.accela.com`).
    host = (parsed.hostname or '').lower()
    if host != 'accela.com' and not host.endswith('.accela.com'):
        return {}
    qs = urllib.parse.parse_qs(parsed.query)
    out = {
        'agency_code': (qs.get('agencyCode') or [''])[0].upper(),
        'module':      (qs.get('Module')     or [''])[0],
        'cap_id_1':    (qs.get('capID1')     or [''])[0],
        'cap_id_2':    (qs.get('capID2')     or [''])[0],
        'cap_id_3':    (qs.get('capID3')     or [''])[0],
        'tab_name':    (qs.get('TabName')    or [''])[0],
    }
    return {k: v for k, v in out.items() if v} | {
        'agency_code': out['agency_code'],
        'module':      out['module'],
        'cap_id_1':    out['cap_id_1'],
        'cap_id_2':    out['cap_id_2'],
        'cap_id_3':    out['cap_id_3'],
    }


def build_accela_url(template_url: str, *, cap_id_3: int | str) -> str:
    """Rebuild an Accela CapDetail URL with a different ``capID3``."""
    parsed = urllib.parse.urlparse(template_url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    qs['capID3'] = [str(cap_id_3).zfill(5)]
    flat = [(k, v[0]) for k, v in qs.items()]
    new_q = urllib.parse.urlencode(flat, doseq=False)
    return urllib.parse.urlunparse(parsed._replace(query=new_q))


# ─────────────────────────── Firecrawl ────────────────────────────────

# JSON schema we send to Firecrawl's `jsonOptions`. The schema both
# (1) tells Firecrawl's LLM the exact shape we expect back, and
# (2) lets us pass the same shape into Claude as a fallback. Keep this
# in sync with `_normalise_permit` field names.
PERMIT_JSON_SCHEMA: dict = {
    'type': 'object',
    'properties': {
        'permit_number':    {'type': 'string',  'description': 'Visible record / CAP number for this permit.'},
        'detail_url':       {'type': ['string', 'null'], 'description': 'Absolute URL to the CapDetail.aspx page for this permit (the link wrapping the permit number in the list table). Null if the row has no link.'},
        'permit_type':      {'type': 'string',  'description': "Short category, e.g. 'Roofing', 'HVAC Replacement'."},
        'description':      {'type': 'string',  'description': 'Full work description / scope of work.'},
        'status':           {'type': 'string',  'description': "e.g. 'Issued', 'Approved', 'Pending'."},
        'applied_date':     {'type': ['string', 'null'], 'description': 'YYYY-MM-DD or null.'},
        'issued_date':      {'type': ['string', 'null'], 'description': 'YYYY-MM-DD or null.'},
        'expires_date':     {'type': ['string', 'null'], 'description': 'YYYY-MM-DD or null.'},
        'address':          {'type': 'string',  'description': 'Full site address (street + number).'},
        'city':             {'type': 'string'},
        'state':            {'type': 'string',  'description': '2-letter US state code.'},
        'zip':              {'type': 'string',  'description': '5-digit ZIP.'},
        'latitude':         {'type': ['number', 'null']},
        'longitude':        {'type': ['number', 'null']},
        'owner_name':       {'type': 'string'},
        'contractor_name':  {'type': 'string'},
        'contractor_phone': {'type': 'string',  'description': 'Phone formatted (NNN) NNN-NNNN.'},
        'contractor_email': {'type': 'string',  'description': 'Lowercase, valid email.'},
        'valuation_cents':  {'type': ['integer', 'null'], 'description': 'Project value in cents (e.g. $45,000 → 4500000).'},
        'square_feet':      {'type': ['integer', 'null']},
        'trade':            {'type': 'string',  'description': 'One of: roofing, hvac, plumbing, electrical, solar, general, civil, other.'},
        'ai_score':         {'type': 'integer', 'description': 'Lead-quality score 0-100.'},
        'ai_grade':         {'type': 'string',  'description': 'Letter grade A through F.'},
        'ai_tier':          {'type': 'string',  'description': 'One of: hot, warm, cool.'},
        'ai_reasoning':     {'type': 'string',  'description': 'One-to-two sentence justification of the score.'},
    },
    'required': ['permit_number', 'permit_type', 'address'],
}


def get_extraction_prompt() -> str:
    """Active DETAIL-page extraction prompt — admin override
    (system_setting 'extraction_prompt') or the built-in default.
    Used for BOTH Firecrawl's `jsonOptions.prompt` AND Claude's
    system message when scraping a single CapDetail page."""
    override = (get_system_setting('extraction_prompt') or '').strip()
    return override or EXTRACT_SYSTEM_PROMPT


# ─────────── List-page (CapHome / search results) extraction ──────────

# Schema for the LIST page: an envelope object with one entry per
# visible row in the search results table.
PERMIT_LIST_JSON_SCHEMA: dict = {
    'type': 'object',
    'properties': {
        'permits': {
            'type':  'array',
            'items': PERMIT_JSON_SCHEMA,
        },
    },
    'required': ['permits'],
}

# Built-in (NOT user-editable) wrapper that turns the one unified
# extraction prompt into a list-page directive. The orchestration
# (date-range filter, follow each row to its detail page, paginate)
# now lives in `_run_worker` — the prompt only has to teach the LLM
# the per-row extraction shape PLUS how to surface a `detail_url`.
# NOTE: We use literal token strings (``__DATE_FILTER_RULE__`` /
# ``__PER_PERMIT_PROMPT__``) and ``str.replace`` rather than
# ``str.format`` because the wrapper text contains JSON examples
# with literal ``{…}`` braces — ``.format`` would try to interpret
# those as format placeholders and KeyError out.
LIST_PAGE_WRAPPER: str = """You are looking at an Accela CapHome / search-results page that
shows MANY permits in a single results table. Typical visible columns:

  Date | Permit Number | Permit Type | Status | Address | Action

═══════════════════════════════════════════════════════════════════════
              CRITICAL RULES — READ EVERY LINE
═══════════════════════════════════════════════════════════════════════
1. Return JSON of shape  { "permits": [ {…}, {…}, … ] }

2. EXHAUSTIVE EXTRACTION — return ONE entry for EVERY data row visible
   in the results table on THIS page.
   • Accela list pages typically show 10, 25, 50, or 100 rows.
   • If you can SEE 10 rows in the markdown, return 10 entries.
   • If you can SEE 25 rows, return 25 entries. No exceptions.
   • Returning only 2 or 3 rows when more are visible is a CRITICAL
     FAILURE — you are NOT being helpful by "summarising"; the
     downstream system NEEDS every row.
   • Do NOT sample. Do NOT pick the "best" rows. Do NOT skip rows
     because they look similar. Do NOT cap at any small number.

3. SELF-CHECK before returning: count how many <tr> data rows
   (i.e. table rows that are NOT the header) appear in the markdown
   for the results table, and confirm the length of your `permits`
   array equals that number. If they differ, you missed rows — go
   back and add them.

4. Do NOT invent rows you cannot see in the markdown.

5. Do NOT include the header row, pagination links, filter controls,
   "Records Found:" banners, or "Showing 1-10 of 100+" summary text
   as permit entries.

6. The page may say "Showing 1-10 of 100+" — only extract THIS page's
   visible rows. The system fetches subsequent pages itself in a
   separate call. Don't try to be clever about pagination.

7. For EACH row, fill `detail_url` with the FULL absolute URL that the
   Permit Number link points to (look for an <a href="…CapDetail.aspx
   …capID3=…"> wrapping the permit number text in the markdown). If
   you cannot find an href, set it to null. This URL is critical —
   the system uses it to follow into each permit's detail page.

8. Required fields per row are `permit_number`, `permit_type`, and
   `address`. If `address` is genuinely missing for a row use the
   empty string ""; do NOT skip the row.
__DATE_FILTER_RULE__
═══════════════════════════════════════════════════════════════════════

EXAMPLE — for a results table with 6 visible rows you would return:

  {
    "permits": [
      { "permit_number": "BLD22-00001", "permit_type": "Roofing",     "address": "12 Main St",  "applied_date": "2025-04-01", "detail_url": "https://…CapDetail.aspx?…capID3=001" },
      { "permit_number": "BLD22-00002", "permit_type": "HVAC",        "address": "44 Elm Ave",  "applied_date": "2025-04-02", "detail_url": "https://…CapDetail.aspx?…capID3=002" },
      { "permit_number": "BLD22-00003", "permit_type": "Plumbing",    "address": "9 Oak Rd",    "applied_date": "2025-04-03", "detail_url": "https://…CapDetail.aspx?…capID3=003" },
      { "permit_number": "BLD22-00004", "permit_type": "Electrical",  "address": "77 Pine Ln",  "applied_date": "2025-04-04", "detail_url": "https://…CapDetail.aspx?…capID3=004" },
      { "permit_number": "BLD22-00005", "permit_type": "Solar",       "address": "3 Cedar Ct",  "applied_date": "2025-04-05", "detail_url": "https://…CapDetail.aspx?…capID3=005" },
      { "permit_number": "BLD22-00006", "permit_type": "Re-roof",     "address": "21 Maple Dr", "applied_date": "2025-04-06", "detail_url": "https://…CapDetail.aspx?…capID3=006" }
    ]
  }

Note 6 input rows → 6 output entries. NEVER 2. NEVER 3.

For EACH visible row, extract using the per-permit schema below
(fields the LIST page does NOT show — contractor email/phone, owner,
valuation, dates other than `applied_date` — should be null/empty;
the system fetches the per-permit detail page after this list call
to fill them in via Claude):

__PER_PERMIT_PROMPT__
"""


def get_list_extraction_prompt(date_from=None, date_to=None) -> str:
    """Compose the LIST-page extraction prompt by wrapping the user's
    one unified per-permit prompt with list-page orchestration rules.
    The date-range filter is injected as an additional rule when the
    admin specified a window in the Run-now form."""
    rule = ''
    if date_from or date_to:
        rule = (
            '7. DATE FILTER: Only include rows whose Date column falls in\n'
            f'   [{date_from or "begin"} … {date_to or "today"}].\n'
            '   Skip out-of-range rows entirely (do NOT include them in\n'
            '   the output array — the system also re-checks dates on\n'
            '   its side as a safety net).'
        )
    per_permit = get_extraction_prompt()
    return (LIST_PAGE_WRAPPER
            .replace('__DATE_FILTER_RULE__', rule)
            .replace('__PER_PERMIT_PROMPT__', per_permit))


def is_accela_list_url(url: str) -> bool:
    """True if the URL points at an Accela CapHome / search-results
    page (many permits shown in a table) rather than a single
    CapDetail page (one permit per page).

    We treat anything that ISN'T explicitly CapDetail.aspx as a list
    page — Accela has several list-style pages (CapHome, AddressList,
    GeneralSearch, ContactList) and we want to fall through to the
    list extractor for all of them.
    """
    u = (url or '').lower()
    if 'capdetail.aspx' in u:
        return False
    return any(marker in u for marker in (
        'caphome.aspx', 'caplist.aspx', 'addresslist',
        'generalsearch', 'contactlist', '/cap/cap',
    )) or '?module=' in u and 'capid' not in u


def firecrawl_scrape(url: str, *, api_key: str | None = None,
                     timeout: int = 120, mode: str = 'detail',
                     date_from=None, date_to=None) -> dict:
    """Scrape an Accela page via Firecrawl.

    Accela is a .NET WebForms app — the body of the page is built by
    JavaScript after the initial HTML loads. We tell Firecrawl to
    wait a few seconds (``waitFor``) AND to also issue an explicit
    ``wait`` action so the rendered table cells exist before
    extraction.

    We also ask Firecrawl to do an LLM-based JSON extraction in the
    same call (``formats: ['json']`` + ``jsonOptions``) using the
    active extraction prompt — Firecrawl's hosted model gets a first
    pass at structured data and we only fall back to a second Claude
    call if its JSON is empty or malformed.

    ``mode='detail'`` → single-permit schema (for CapDetail.aspx).
    ``mode='list'``   → many-permits envelope (for CapHome.aspx and
                        other search-results pages).
    """
    url = (url or '').strip()
    if not url:
        raise ScraperError('URL is required')
    if not (url.startswith('http://') or url.startswith('https://')):
        raise ScraperError('URL must start with http:// or https://')
    if mode not in ('detail', 'list'):
        raise ScraperError(f'firecrawl_scrape: bad mode {mode!r}')

    key = (api_key or get_system_setting('firecrawl_api_key') or '').strip()
    if not key:
        raise ScraperError('Firecrawl API key is not configured. '
                           'Add it in Scraper Settings.')

    if mode == 'list':
        prompt = get_list_extraction_prompt(date_from, date_to)
        schema = PERMIT_LIST_JSON_SCHEMA
    else:
        prompt = get_extraction_prompt()
        schema = PERMIT_JSON_SCHEMA

    body = json.dumps({
        'url': url,
        'formats': ['markdown', 'html', 'json'],
        'onlyMainContent': False,
        'waitFor': 3000,
        'timeout': 60000,
        'actions': [
            {'type': 'wait', 'milliseconds': 2500},
        ],
        'jsonOptions': {
            'prompt': prompt,
            'schema': schema,
        },
    }).encode('utf-8')

    req = urllib.request.Request(
        FIRECRAWL_URL,
        data=body,
        method='POST',
        headers={
            'Authorization': f'Bearer {key}',
            'Content-Type':  'application/json',
            'Accept':        'application/json',
        },
    )
    _t0 = time.monotonic()
    _status = None
    _bytes = 0
    _err = None
    try:
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                _status = resp.getcode()
                raw_body = resp.read()
                _bytes = len(raw_body)
                payload = json.loads(raw_body.decode('utf-8'))
        except urllib.error.HTTPError as e:
            _status = e.code
            try:
                err_body = json.loads(e.read().decode('utf-8'))
                err_msg = err_body.get('error') or err_body.get('message') or str(err_body)
            except Exception:
                err_msg = f'HTTP {e.code}'
            _err = f'Firecrawl error: {err_msg}'
            raise ScraperError(_err) from e
        except urllib.error.URLError as e:
            _err = f'Firecrawl network error: {e.reason}'
            raise ScraperError(_err) from e
        except Exception as e:
            _err = f'Firecrawl failed: {e}'
            raise ScraperError(_err) from e

        if not payload.get('success', True):
            _err = f"Firecrawl reported failure: {payload.get('error', 'unknown')}"
            raise ScraperError(_err)

        data = payload.get('data') or {}
        md   = (data.get('markdown') or '').strip()
        html = (data.get('html') or '').strip()
        js   = data.get('json') or data.get('llm_extraction') or {}
        if not md and not html and not js:
            _err = 'Firecrawl returned no content for that URL.'
            raise ScraperError(_err)
    finally:
        try:
            db.record_firecrawl_call(
                scraper_run_id=_current_run_id(),
                source=_current_source('accela'),
                mode=mode,
                url=url,
                status_code=_status,
                latency_ms=int((time.monotonic() - _t0) * 1000),
                response_bytes=_bytes or None,
                error=_err,
            )
        except Exception:
            log.exception('firecrawl usage recording failed')
    return {
        'markdown': md,
        'html':     html,
        'json':     js if isinstance(js, dict) else {},
        'metadata': data.get('metadata') or {},
    }


# ─────────────────────────── Anthropic / Claude ────────────────────────

EXTRACT_SYSTEM_PROMPT = """You are an expert permit-data extraction agent for Permitlify, a SaaS that turns raw building-permit web pages into structured leads for contractors, roofers, plumbers, HVAC, solar and home-services pros.

You will be given the markdown of a single Accela permit detail page (CapDetail.aspx). Your job: extract every available field about that one permit, and add a Permitlify-quality AI lead score. Return STRICT JSON — no prose, no markdown fences, no commentary.

╭─ Required JSON shape ─────────────────────────────────────────────────╮
│ {                                                                    │
│   "permit_number":     "string  -- the visible record / CAP number",│
│   "permit_type":       "string  -- short category, e.g. 'Roofing'", │
│   "description":       "string  -- the work description / scope",   │
│   "status":            "string  -- e.g. 'Issued', 'Approved'",      │
│   "applied_date":      "YYYY-MM-DD or null",                        │
│   "issued_date":       "YYYY-MM-DD or null",                        │
│   "expires_date":      "YYYY-MM-DD or null",                        │
│   "address":           "string  -- full site address",              │
│   "city":              "string",                                    │
│   "state":             "string  -- 2-letter US state code",         │
│   "zip":               "string  -- 5-digit zip",                    │
│   "latitude":          "number or null",                            │
│   "longitude":         "number or null",                            │
│   "owner_name":        "string  -- the property owner",             │
│   "contractor_name":   "string  -- the licensed contractor",        │
│   "contractor_phone":  "string  -- formatted (NNN) NNN-NNNN",       │
│   "contractor_email":  "string  -- lowercase, valid email",         │
│   "valuation_cents":   "integer -- project value in cents",         │
│   "square_feet":       "integer or null",                           │
│   "trade":             "string  -- one of: roofing, hvac, plumbing, │
│                          electrical, solar, general, civil, other", │
│   "ai_score":          "integer 0-100",                             │
│   "ai_grade":          "string  -- one of: A, A-, B+, B, B-, C+, C, │
│                          C-, D+, D, F",                             │
│   "ai_tier":           "string  -- one of: hot, warm, cool",        │
│   "ai_reasoning":      "string  -- 1-2 sentences why this score"    │
│ }                                                                    │
╰──────────────────────────────────────────────────────────────────────╯

╭─ Scoring rubric ──────────────────────────────────────────────────────╮
│ Start at 50. Add/subtract based on:                                  │
│   +20  Issued/Approved status (vs pending/review)                    │
│   +15  Project valuation > $50k          +5 if > $250k               │
│   +10  Contractor email present                                      │
│   +10  Contractor phone present                                      │
│   +5   Address + zip both present                                    │
│   +5   Issued/applied within last 30 days                            │
│   −15  Status = expired, withdrawn, void, denied                     │
│   −10  No contractor info at all                                     │
│ Clamp to 0-100. Tier: ≥80 → hot, 60-79 → warm, <60 → cool.           │
│ Grade: 90+ A, 85-89 A-, 80-84 B+, 75-79 B, 70-74 B-, 65-69 C+,       │
│ 60-64 C, 55-59 C-, 50-54 D+, 45-49 D, <45 F.                         │
╰──────────────────────────────────────────────────────────────────────╯

╭─ Rules ───────────────────────────────────────────────────────────────╮
│ • If a field truly cannot be found, use null (or "" for strings).    │
│   Never invent data.                                                 │
│ • Convert valuations like "$45,000" → 4500000 (cents).               │
│ • Convert dates like "04/12/2026" → "2026-04-12".                    │
│ • Normalise state to 2-letter ABBR (Texas → TX).                     │
│ • Normalise phone to "(NNN) NNN-NNNN" if 10 digits found, else "".   │
│ • Lowercase email; reject anything without a valid '@'.              │
│ • For Accela "UG" agency code, default city='Unincorporated' and     │
│   state='WA' ONLY if the page has no address — otherwise extract     │
│   city/state from the visible address.                               │
│ • Output ONE flat JSON object. No arrays, no wrapper.                │
╰──────────────────────────────────────────────────────────────────────╯

╭─ Example output ──────────────────────────────────────────────────────╮
│ {"permit_number":"BLD25-00061","permit_type":"Residential Roofing", │
│  "description":"Reroof, 28 sq comp shingle","status":"Issued",      │
│  "applied_date":"2025-03-04","issued_date":"2025-03-12",            │
│  "expires_date":"2025-09-12","address":"742 Evergreen Ter",         │
│  "city":"Tacoma","state":"WA","zip":"98404",                        │
│  "latitude":null,"longitude":null,                                  │
│  "owner_name":"Homer Simpson",                                      │
│  "contractor_name":"PNW Roof Co",                                   │
│  "contractor_phone":"(253) 555-0144",                               │
│  "contractor_email":"bids@pnwroof.com",                             │
│  "valuation_cents":1850000,"square_feet":1800,                      │
│  "trade":"roofing","ai_score":86,"ai_grade":"A-","ai_tier":"hot",   │
│  "ai_reasoning":"Issued residential reroof with full contact info — │
│  high-intent active project ready to bid this week."}               │
╰──────────────────────────────────────────────────────────────────────╯
"""


def _extract_json(text: str) -> dict:
    """Pull the first JSON object out of Claude's response."""
    text = (text or '').strip()
    if not text:
        raise ScraperError('Claude returned an empty response.')
    # Direct parse first — strict prompt usually gives us bare JSON.
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Fall back: find the first {...} balanced block.
    start = text.find('{')
    if start < 0:
        raise ScraperError('Claude response had no JSON object.')
    depth = 0
    for i, ch in enumerate(text[start:], start):
        if ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                blob = text[start:i + 1]
                try:
                    return json.loads(blob)
                except json.JSONDecodeError as e:
                    raise ScraperError(f'Claude JSON parse failed: {e}') from e
    raise ScraperError('Claude JSON object was not closed.')


def claude_extract(markdown: str, *, source_url: str = '',
                   api_key: str | None = None,
                   model: str | None = None,
                   timeout: int = 90) -> dict:
    """Send the scraped markdown to Claude and return a parsed permit
    dict matching the columns of the ``permits`` table."""
    md = (markdown or '').strip()
    if not md:
        raise ScraperError('No markdown to extract from — Firecrawl returned empty.')

    key = (api_key or get_system_setting('claude_api_key') or '').strip()
    if not key:
        raise ScraperError('Claude API key is not configured. '
                           'Add it in Scraper Settings.')
    mdl = (model or get_system_setting('claude_model') or '').strip() or DEFAULT_MODEL

    user_parts = []
    if source_url:
        user_parts.append(f'Source URL: {source_url}')
    # Hard cap the markdown we send so a runaway page doesn't blow the
    # token budget. 32 KB is plenty for a single CapDetail screen.
    if len(md) > 32000:
        md = md[:32000] + '\n…(truncated)'
    user_parts.append('Permit page markdown:\n\n' + md)
    user_prompt = '\n\n'.join(user_parts)

    body = json.dumps({
        'model':      mdl,
        'max_tokens': 1500,
        'system':     get_extraction_prompt(),
        'messages':   [{'role': 'user', 'content': user_prompt}],
    }).encode('utf-8')

    req = urllib.request.Request(
        ANTHROPIC_URL, data=body, method='POST',
        headers={
            'x-api-key':         key,
            'anthropic-version': ANTHROPIC_VERSION,
            'Content-Type':      'application/json',
            'Accept':            'application/json',
        },
    )
    _t0 = time.monotonic()
    _status = None
    _err = None
    _in_tok = 0
    _out_tok = 0
    payload = None
    try:
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                _status = resp.getcode()
                payload = json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            _status = e.code
            try:
                err_body = json.loads(e.read().decode('utf-8'))
                err_msg = (err_body.get('error') or {}).get('message') or str(err_body)
            except Exception:
                err_msg = f'HTTP {e.code}'
            _err = f'Claude error: {err_msg}'
            raise ScraperError(_err) from e
        except urllib.error.URLError as e:
            _err = f'Claude network error: {e.reason}'
            raise ScraperError(_err) from e
        except Exception as e:
            _err = f'Claude failed: {e}'
            raise ScraperError(_err) from e

        usage = (payload or {}).get('usage') or {}
        try:
            _in_tok  = int(usage.get('input_tokens')  or 0)
            _out_tok = int(usage.get('output_tokens') or 0)
        except Exception:
            _in_tok = _out_tok = 0
    finally:
        try:
            db.record_claude_call(
                scraper_run_id=_current_run_id(),
                source=_current_source('accela'),
                model=mdl,
                status_code=_status,
                latency_ms=int((time.monotonic() - _t0) * 1000),
                input_tokens=_in_tok,
                output_tokens=_out_tok,
                error=_err,
            )
        except Exception:
            log.exception('claude usage recording failed')

    blocks = payload.get('content') or []
    text = ''
    for b in blocks:
        if isinstance(b, dict) and b.get('type') == 'text':
            text += b.get('text') or ''
    raw = _extract_json(text)
    return _normalise_permit(raw)


# ─────────────────────────── Accela link finder ──────────────────────────
#
# Helpers for the Scrapers → "Accela Permit Search" admin page. Given a
# city + state, we hand the lookup to Firecrawl's autonomous Agent
# (``app.agent(prompt=…, schema=…, model=…, max_credits=…)``) which
# performs its own browsing/search and returns a structured pick that
# matches our Pydantic schema. The agent call is recorded to
# ``firecrawl_calls`` with ``mode='agent'`` and ``source='accela_finder'``
# so the Firecrawl Usage dashboard keeps a single canonical view of
# every external API hit.

ACCELA_FINDER_SOURCE = 'accela_finder'

# ── Claude-backed finder ─────────────────────────────────────────────
# The finder used to call Firecrawl's autonomous Agent (one HTTP call
# per city, browses the open web, returns a structured pick). It has
# been switched to Claude per admin request: Claude has been verified
# to return the right URL from its training-data knowledge of public
# Accela deployments, doesn't require a per-call browse credit, and
# keeps all AI usage in one ledger (`claude_calls`).
#
# The Firecrawl helper below (`firecrawl_agent_pick`) is kept in the
# file as dead code for revertability — nothing currently calls it.
ACCELA_FINDER_DEFAULT_MODEL       = 'claude-haiku-4-5'
ACCELA_FINDER_VALID_MODELS        = (
    'claude-haiku-4-5',            # cheapest — usually enough
    'claude-sonnet-4-5-20250929',  # smarter pick for tricky cities
    'claude-opus-4-5',             # most expensive
)
# NOTE: the older ``claude-3-5-haiku-latest`` / ``claude-3-5-sonnet-latest``
# aliases were removed by Anthropic in late 2025 — keep this list in sync
# with the models actually returning 200 from /v1/messages today.
ACCELA_FINDER_DEFAULT_MAX_TOKENS  = 3000
ACCELA_FINDER_MAX_TOKENS_CAP      = 8000
# Legacy alias retained because templates / system_settings still
# reference it. Now interpreted as max_tokens, not Firecrawl credits.
ACCELA_FINDER_DEFAULT_MAX_CREDITS = ACCELA_FINDER_DEFAULT_MAX_TOKENS

# Anthropic's server-side web-search tool. claude.ai's "Adaptive" mode
# browses the web to verify the page actually loads before answering;
# the raw /v1/messages API answers from training data only and gives
# weaker results on lesser-known Accela deployments (admin reported
# Wichita / Overland Park / Kansas City / Topeka all returning "no
# accela.com URL found" via API while claude.ai found the right
# aca-prod.accela.com URL for the same prompt). Enabling web_search
# brings parity. Server-side tool — Anthropic executes the search and
# returns the final text in the same response, no client-side loop.
ACCELA_FINDER_WEB_SEARCH_TOOL = {
    'type':     'web_search_20250305',
    'name':     'web_search',
    'max_uses': 5,
}

# Same friendly-error rewrite the per-scraper agent does — Claude's
# overload / quota errors should suggest raising the cap or retrying
# rather than implying the API key is broken.
ACCELA_FINDER_BUDGET_HINT_NEEDLES = (
    'rate limit',
    'overloaded',
    'capacity',
    'max_tokens',
)

# The user-editable prompt template is now JUST the "ask" part — it
# tells Claude what to find. The mandatory parts (use the web-search
# tool, the host rule, the JSON output schema) live in the system
# prompt below so a customised user template can't accidentally turn
# them off. This is a defence against the failure mode admin hit when
# a one-line saved template like "Find the Accela URL for {city},
# {state}." caused Claude to answer from memory and return null for
# every city.
ACCELA_FINDER_DEFAULT_PROMPT = (
    "Find the public 'Citizen Access' building-permit search page "
    "for {city}, {state} hosted by Accela."
)

# System prompt is NOT user-editable. It mandates the parts that
# break the feature when missing: web-search use, the accela.com
# host rule, the strict JSON output format. Sent on every call,
# regardless of what the user has typed in the prompt-template box.
ACCELA_FINDER_SYSTEM_PROMPT = (
    "You are a research assistant that finds the public URL of an "
    "Accela 'Citizen Access' building-permit search page for a given "
    "US city.\n\n"
    "USE THE WEB-SEARCH TOOL — for every request, run web searches "
    "such as:\n"
    "  - \"<city> <state> accela citizen access\"\n"
    "  - \"<city> <state> accela building permit search\"\n"
    "  - \"site:accela.com <city>\"\n"
    "Do NOT answer from memory — confirm the URL exists via search "
    "before reporting it.\n\n"
    "STRICT RULES:\n"
    " 1. The URL host MUST be accela.com or a subdomain of accela.com "
    "(e.g. aca-prod.accela.com, aca.accela.com, <city>aca.accela.com). "
    "Reject anything else — *.gov / *.org portals are out of scope even "
    "when they're Accela-powered.\n"
    " 2. Prefer pages whose path contains 'CapHome.aspx', "
    "'GeneralSearch', or '/Cap/' — these are the actual permit search "
    "forms. Reject login pages, account-creation pages, and "
    "home/welcome landing pages when a search page exists.\n"
    " 3. The URL must be the page that lets a citizen SEARCH building "
    "permits, not a single permit-detail page (CapDetail) and not an "
    "unrelated module like business licences.\n"
    " 4. Confidence is 'high' if you found the page via web search and "
    "confirmed the host + path, 'medium' if you found a likely "
    "accela.com URL but could not confirm the exact search-page path, "
    "'low' otherwise.\n"
    " 5. If after searching NO accela.com URL satisfies rule 1, return "
    "url=null with confidence='low' and explain in one sentence.\n\n"
    "Reply with EXACTLY one JSON object and nothing else — no prose, "
    "no markdown fences:\n"
    '  {"url": "https://…accela.com/…" or null,\n'
    '   "city": "<city>",\n'
    '   "state": "<state>",\n'
    '   "confidence": "high"|"medium"|"low",\n'
    '   "reason": "one short sentence"}'
)


def claude_finder_pick(city: str, state_name: str,
                       *, prompt_template: str | None = None,
                       model: str | None = None,
                       max_tokens: int | None = None,
                       api_key: str | None = None,
                       timeout: int = 120) -> dict:
    """Ask Claude to pick the best Accela permit-search URL for one city.

    Replaces the previous Firecrawl-Agent finder. Returns the SAME
    envelope shape so the JS / push wiring stays unchanged::

        {
          'ok':         bool,
          'url':        str | None,
          'confidence': 'high'|'medium'|'low',
          'reason':     str,
          'error':      str | None,
          'log': {
              'status':         int | None,    # HTTP status
              'agent_id':       str | None,    # Claude message id
              'model':          str,
              'credits_used':   int | None,    # input+output tokens
              'credits_budget': int,           # max_tokens we sent
              'prompt':         str,
              'data':           Any,           # parsed JSON or None
              'error':          str | None,
              'latency_ms':     int,
          },
        }

    Records exactly one row in ``claude_calls`` with
    ``source='accela_finder'`` so the existing Claude Usage dashboard
    counts it. Never raises on a Claude failure — surfaces the error
    in the returned envelope so the table can render it inline next
    to successful rows.
    """
    key = (api_key or get_system_setting('claude_api_key') or '').strip()
    if not key:
        raise ScraperError('Claude API key is not configured. '
                           'Add it in Scraper Settings.')

    # ── Sanitise the optional knobs ────────────────────────────────
    tmpl = (prompt_template or ACCELA_FINDER_DEFAULT_PROMPT).strip()
    if not tmpl:
        tmpl = ACCELA_FINDER_DEFAULT_PROMPT
    if len(tmpl) > 4000:
        tmpl = tmpl[:4000]

    mdl = (model or ACCELA_FINDER_DEFAULT_MODEL).strip()
    if mdl not in ACCELA_FINDER_VALID_MODELS:
        mdl = ACCELA_FINDER_DEFAULT_MODEL

    try:
        mt = int(max_tokens) if max_tokens is not None else ACCELA_FINDER_DEFAULT_MAX_TOKENS
    except (TypeError, ValueError):
        mt = ACCELA_FINDER_DEFAULT_MAX_TOKENS
    mt = max(1, min(mt, ACCELA_FINDER_MAX_TOKENS_CAP))

    # Substitute {city} / {state} placeholders. Forgive missing braces
    # on a custom prompt — str.format would raise KeyError otherwise.
    safe_city  = (city  or '').strip()
    safe_state = (state_name or '').strip()
    try:
        prompt = tmpl.format(city=safe_city, state=safe_state)
    except (IndexError, KeyError):
        prompt = (tmpl
                  .replace('{city}',  safe_city)
                  .replace('{state}', safe_state))

    # The system prompt carries the mandatory rules (use web-search,
    # accela.com host rule, JSON output schema). It is intentionally
    # NOT user-editable — see ACCELA_FINDER_SYSTEM_PROMPT for why.
    system_prompt = ACCELA_FINDER_SYSTEM_PROMPT

    body = json.dumps({
        'model':      mdl,
        'max_tokens': mt,
        'system':     system_prompt,
        # Server-side web search: Anthropic runs the searches itself
        # and returns the final text in the same response — no
        # tool-result loop on our side. See ACCELA_FINDER_WEB_SEARCH_TOOL
        # for the rationale (claude.ai parity).
        'tools':      [ACCELA_FINDER_WEB_SEARCH_TOOL],
        'messages':   [{'role': 'user', 'content': prompt}],
    }).encode('utf-8')

    req = urllib.request.Request(
        ANTHROPIC_URL, data=body, method='POST',
        headers={
            'x-api-key':         key,
            'anthropic-version': ANTHROPIC_VERSION,
            'Content-Type':      'application/json',
            'Accept':            'application/json',
        },
    )

    _t0       = time.monotonic()
    _status   = None
    _err      = None
    _msg_id   = None
    _in_tok   = 0
    _out_tok  = 0
    _retries  = 0
    payload   = None
    try:
        # Anthropic enforces a per-org input-tokens-per-minute budget.
        # With web_search enabled each call now consumes ~25-30k input
        # tokens (search results land in context), so two cities back-
        # to-back can blow the default 50k/min limit and surface as a
        # 429. Anthropic returns ``retry-after`` (seconds) on those —
        # honour it up to twice before giving up. Bounded to 90 s total
        # extra wait so a stuck queue doesn't pile up Django workers.
        for _attempt in range(3):  # initial + 2 retries
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    _status = resp.getcode()
                    payload = json.loads(resp.read().decode('utf-8'))
                    break  # success
            except urllib.error.HTTPError as e:
                _status = e.code
                try:
                    err_body = json.loads(e.read().decode('utf-8'))
                    err_msg  = (err_body.get('error') or {}).get('message') or str(err_body)
                except Exception:
                    err_msg  = f'HTTP {e.code}'
                if e.code == 429 and _attempt < 2:
                    # ``Retry-After`` is RFC-7231 — typically an integer
                    # number of seconds. Clamp to [1, 45] so a buggy /
                    # absurdly large value can't wedge the request.
                    try:
                        wait = int(e.headers.get('retry-after') or 30)
                    except (TypeError, ValueError):
                        wait = 30
                    wait = max(1, min(wait, 45))
                    _retries += 1
                    time.sleep(wait)
                    # Rebuild the request — urllib.Request is single-use
                    # once .urlopen has consumed it on the failed attempt.
                    req = urllib.request.Request(
                        ANTHROPIC_URL, data=body, method='POST',
                        headers={
                            'x-api-key':         key,
                            'anthropic-version': ANTHROPIC_VERSION,
                            'Content-Type':      'application/json',
                            'Accept':            'application/json',
                        },
                    )
                    continue
                _err = f'Claude error: {err_msg}'
                break
            except urllib.error.URLError as e:
                _err = f'Claude network error: {e.reason}'
                break
            except Exception as e:
                _err = f'Claude failed: {e}'
                break

        if payload is not None:
            _msg_id = payload.get('id')
            usage   = payload.get('usage') or {}
            try:
                _in_tok  = int(usage.get('input_tokens')  or 0)
                _out_tok = int(usage.get('output_tokens') or 0)
            except Exception:
                _in_tok = _out_tok = 0
            # web_search ran server-side: Anthropic reports the request
            # count under usage.server_tool_use.web_search_requests so
            # the admin can tell at a glance whether Claude actually
            # browsed (=> high-quality answer) vs replied from memory
            # (=> the prompt or tool wiring may need adjustment).
            try:
                _web_searches = int(((usage.get('server_tool_use') or {})
                                     .get('web_search_requests')) or 0)
            except Exception:
                _web_searches = 0
        else:
            _web_searches = 0
    finally:
        try:
            db.record_claude_call(
                scraper_run_id=_current_run_id(),
                source=_current_source(ACCELA_FINDER_SOURCE),
                model=mdl,
                status_code=_status,
                latency_ms=int((time.monotonic() - _t0) * 1000),
                input_tokens=_in_tok,
                output_tokens=_out_tok,
                error=_err,
            )
        except Exception:
            log.exception('claude finder usage recording failed')

    # ── Rewrite the friendly hint for known transient errors ───────
    if _err:
        _err_lc = _err.lower()
        if any(n in _err_lc for n in ACCELA_FINDER_BUDGET_HINT_NEEDLES):
            _err = (
                f"Claude was rate-limited or asked for more output than "
                f"budgeted ({mt} tokens). Wait a few seconds and retry, "
                f"or raise 'Max output tokens' in the finder settings. "
                f"(Original error: {_err})"
            )

    # ── Parse Claude's reply into our envelope ─────────────────────
    text = ''
    parsed = None
    if payload is not None:
        for b in payload.get('content') or []:
            if isinstance(b, dict) and b.get('type') == 'text':
                text += b.get('text') or ''
        if text:
            try:
                parsed = _extract_json(text)
            except ScraperError as e:
                if not _err:
                    _err = f'Claude returned non-JSON output: {e}'
        else:
            # No text block at all in a 200 response is a real failure
            # mode when web_search is enabled: if max_tokens runs out
            # mid tool-use Claude can return only server_tool_use /
            # web_search_tool_result blocks with no final answer. Without
            # this guard we'd silently report ok=true,url=null which
            # looks identical to a legitimate "no URL found" answer.
            if not _err:
                stop = payload.get('stop_reason') or 'unknown'
                _err = (f'Claude returned no text answer (stop_reason='
                        f'{stop}). Try raising "Max output tokens" — web '
                        f'search may have consumed the budget.')

    chosen_url = None
    confidence = 'low'
    reason     = ''
    if isinstance(parsed, dict):
        raw_url = parsed.get('url')
        if isinstance(raw_url, str):
            chosen_url = raw_url.strip() or None
        confidence = (parsed.get('confidence') or 'low')
        if not isinstance(confidence, str):
            confidence = 'low'
        confidence = confidence.strip().lower()
        reason = (parsed.get('reason') or '')
        if not isinstance(reason, str):
            reason = ''
        reason = reason.strip()[:300]
    if confidence not in ('high', 'medium', 'low'):
        confidence = 'low'

    # ── Defence-in-depth: enforce the host rule the prompt sets ────
    if chosen_url:
        try:
            host = (urllib.parse.urlparse(chosen_url).hostname or '').lower()
        except Exception:
            host = ''
        if host != 'accela.com' and not host.endswith('.accela.com'):
            reason     = f'Claude picked non-accela host: {host or "unknown"}'
            chosen_url = None
            confidence = 'low'

    return {
        'ok':         _err is None,
        'url':        chosen_url,
        'confidence': confidence,
        'reason':     reason or (_err or '')[:300],
        'error':      _err,
        'log': {
            'status':         _status,
            'agent_id':       _msg_id,
            'model':          mdl,
            'credits_used':   (_in_tok + _out_tok) or None,
            'credits_budget': mt,
            'web_searches':   _web_searches,
            'retries':        _retries,
            'prompt':         prompt[:2000],
            'data':           parsed if parsed is not None else (text[:1000] or None),
            'error':          _err,
            'latency_ms':     int((time.monotonic() - _t0) * 1000),
        },
    }


def firecrawl_agent_pick(city: str, state_name: str,
                         *, prompt_template: str | None = None,
                         model: str | None = None,
                         max_credits: int | None = None,
                         api_key: str | None = None,
                         timeout: int = 180) -> dict:
    """Use Firecrawl's autonomous Agent to find the best Accela
    permit-search URL for one city.

    Returns a dict::

        {
          'ok':           bool,
          'url':          str | None,
          'confidence':   'high' | 'medium' | 'low',
          'reason':       str,
          'error':        str | None,
          'log': {
              'status':       'completed' | 'failed' | 'processing' | None,
              'agent_id':     str | None,
              'model':        str | None,
              'credits_used': int | None,
              'prompt':       str,         # what we actually sent
              'data':         Any,         # raw .data from the agent (may be None)
              'error':        str | None,
              'latency_ms':   int,
          },
        }

    Records exactly one row in ``firecrawl_calls`` with
    ``mode='agent'`` and ``source='accela_finder'`` so the existing
    Firecrawl Usage dashboard counts it. Never raises on a Firecrawl
    failure — surfaces the error in the returned envelope so the
    table can render it inline alongside successful rows.
    """
    # Lazy imports — keep the SDK out of the import path of every
    # request that doesn't use the finder, and make the optional
    # dependency easy to spot.
    try:
        from firecrawl import Firecrawl
        from pydantic import BaseModel, Field
    except Exception as e:                               # pragma: no cover
        raise ScraperError(
            'Firecrawl SDK is not installed. Run '
            '"pip install firecrawl-py pydantic".'
        ) from e

    key = (api_key or get_system_setting('firecrawl_api_key') or '').strip()
    if not key:
        raise ScraperError('Firecrawl API key is not configured. '
                           'Add it in Scraper Settings.')

    # ── Sanitise the optional knobs ────────────────────────────────
    tmpl = (prompt_template or ACCELA_FINDER_DEFAULT_PROMPT).strip()
    if not tmpl:
        tmpl = ACCELA_FINDER_DEFAULT_PROMPT
    if len(tmpl) > 4000:
        tmpl = tmpl[:4000]

    mdl = (model or ACCELA_FINDER_DEFAULT_MODEL).strip()
    if mdl not in ACCELA_FINDER_VALID_MODELS:
        mdl = ACCELA_FINDER_DEFAULT_MODEL

    try:
        mc = int(max_credits) if max_credits is not None else ACCELA_FINDER_DEFAULT_MAX_CREDITS
    except (TypeError, ValueError):
        mc = ACCELA_FINDER_DEFAULT_MAX_CREDITS
    mc = max(1, mc)

    # Substitute {city} / {state} placeholders (forgive missing braces
    # on a custom prompt — str.format would raise KeyError).
    safe_city  = (city  or '').strip()
    safe_state = (state_name or '').strip()
    try:
        prompt = tmpl.format(city=safe_city, state=safe_state)
    except (IndexError, KeyError):
        prompt = (tmpl
                  .replace('{city}',  safe_city)
                  .replace('{state}', safe_state))

    # ── Schema the agent must conform its answer to ────────────────
    class AccelaSuggestion(BaseModel):
        url:        str | None = Field(
            None,
            description=(
                'Public Citizen Access permit-search URL on accela.com or '
                'a subdomain of accela.com. Null if no suitable URL exists.'
            ),
        )
        confidence: str = Field(
            'low',
            description='One of: high, medium, low.',
        )
        reason:     str = Field(
            '',
            description='One short sentence explaining the choice.',
        )

    fc = Firecrawl(api_key=key)

    _t0 = time.monotonic()
    _err = None
    _status = None
    _agent_id = None
    _credits = None
    _data = None
    response_obj = None
    try:
        try:
            response_obj = fc.agent(
                prompt=prompt,
                schema=AccelaSuggestion,
                model=mdl,                # 'spark-1-mini' | 'spark-1-pro'
                max_credits=mc,
                timeout=timeout,
            )
        except Exception as e:
            _err = f'Firecrawl agent error: {e}'

        if response_obj is not None:
            _status   = getattr(response_obj, 'status', None)
            _agent_id = getattr(response_obj, 'id', None)
            _credits  = getattr(response_obj, 'credits_used', None)
            _data     = getattr(response_obj, 'data', None)
            resp_err  = getattr(response_obj, 'error', None)
            if not _err and resp_err:
                _err = f'Firecrawl agent reported: {resp_err}'

        # If the agent ran out of *our* per-call budget (not the
        # Firecrawl account balance), rewrite the error so the admin
        # knows the fix is to raise "Max credits / city" — not to top
        # up their Firecrawl account. Also covers the agent's own
        # "Refusal: Error: Agent reached max credits" wording.
        if _err:
            _err_lc = _err.lower()
            if any(n in _err_lc for n in ACCELA_FINDER_BUDGET_HINT_NEEDLES):
                _err = (
                    f"Agent ran out of the per-city credit budget "
                    f"(used {mc} credits before finishing). "
                    f"Increase 'Max credits / city' in the Firecrawl "
                    f"agent settings above and retry. "
                    f"(Original error: {_err})"
                )
    finally:
        try:
            db.record_firecrawl_call(
                scraper_run_id=_current_run_id(),
                source=_current_source(ACCELA_FINDER_SOURCE),
                mode='agent',
                url=(safe_city + ', ' + safe_state)[:2048],
                status_code=200 if _status == 'completed' else (500 if _err else None),
                latency_ms=int((time.monotonic() - _t0) * 1000),
                response_bytes=None,
                error=_err,
                city=safe_city or None,
                state=safe_state or None,
            )
        except Exception:
            log.exception('firecrawl agent usage recording failed')

    # Normalise the structured pick into our standard envelope ──
    chosen_url = None
    confidence = 'low'
    reason     = ''
    if isinstance(_data, dict):
        chosen_url = (_data.get('url') or '').strip() or None
        confidence = (_data.get('confidence') or 'low').strip().lower()
        reason     = (_data.get('reason') or '').strip()[:300]
    elif _data is not None:
        # Pydantic model instance (or namespace-like)
        try:
            chosen_url = (getattr(_data, 'url', None) or '').strip() or None
            confidence = (getattr(_data, 'confidence', None) or 'low').strip().lower()
            reason     = (getattr(_data, 'reason', None) or '').strip()[:300]
        except Exception:
            pass
    if confidence not in ('high', 'medium', 'low'):
        confidence = 'low'

    # ── Defence-in-depth: enforce the host rule the prompt sets ──
    if chosen_url:
        try:
            host = (urllib.parse.urlparse(chosen_url).hostname or '').lower()
        except Exception:
            host = ''
        if host != 'accela.com' and not host.endswith('.accela.com'):
            reason     = f'Agent picked non-accela host: {host or "unknown"}'
            chosen_url = None
            confidence = 'low'

    # ── Log payload (browser-renderable) ──────────────────────────
    if isinstance(_data, dict):
        log_data = _data
    elif _data is None:
        log_data = None
    else:
        try:
            log_data = _data.model_dump()
        except Exception:
            try:
                log_data = dict(_data)
            except Exception:
                log_data = {'_repr': repr(_data)[:500]}

    return {
        'ok':         _err is None,
        'url':        chosen_url,
        'confidence': confidence,
        'reason':     reason or (_err or '')[:300],
        'error':      _err,
        'log': {
            'status':         _status,
            'agent_id':       _agent_id,
            'model':          mdl,
            'credits_used':   _credits,
            'credits_budget': mc,
            'prompt':         prompt[:2000],
            'data':           log_data,
            'error':          _err,
            'latency_ms':     int((time.monotonic() - _t0) * 1000),
        },
    }



# ───────────────────────── Per-scraper Agent ──────────────────────────
#
# The per-scraper page (/admin-panel/scrapers/<sid>/) used to drive a
# two-stage Firecrawl-scrape + Claude-extract pipeline. We now hand the
# entire job (browse the search page, paginate, open each detail page,
# pull every interesting field) to Firecrawl's autonomous Agent — same
# SDK the finder uses, just with a permits-list schema. One prompt =
# one HTTP call = N structured permit dicts back, ready for upsert.

ACCELA_SCRAPER_AGENT_SOURCE = 'accela_scraper_agent'

ACCELA_SCRAPER_AGENT_DEFAULT_MODEL       = 'spark-1-mini'
ACCELA_SCRAPER_AGENT_VALID_MODELS        = ('spark-1-mini', 'spark-1-pro')
ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS = 1500
ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP     = 50000

# Same friendly-error rewrite the finder does — the message Firecrawl
# returns when it ran out of *our* per-call budget reads like an
# account-balance error, but the fix is to raise the per-run cap.
ACCELA_SCRAPER_AGENT_BUDGET_HINT_NEEDLES = (
    'reached max credits',
    'max credits',
    'credit limit',
    'credits exhausted',
)

ACCELA_SCRAPER_AGENT_DEFAULT_PROMPT = (
    "You are scraping a public Accela 'Citizen Access' building-permit "
    "search page for {city}, {state}. The starting URL is:\n"
    "    {url}\n\n"
    "STEP 1 — Open the URL. If a date filter exists on the page, set "
    "From={date_from} To={date_to} and submit the form.\n"
    "STEP 2 — Walk the results. Paginate forward using the 'Next' link "
    "(or page-number links) until you've seen every result page that "
    "matches the filter, OR you hit page 20.\n"
    "STEP 3 — For each row, open the permit's detail page (CapDetail) "
    "and extract:\n"
    "  • permit_number     — the human-readable permit number\n"
    "  • permit_type       — short type/category text\n"
    "  • description       — work description\n"
    "  • status            — issued / finaled / pending / etc.\n"
    "  • address           — full street address line\n"
    "  • city, state, zip  — location\n"
    "  • applied_date, issued_date, expires_date — ISO YYYY-MM-DD\n"
    "  • valuation_cents   — project value in CENTS (multiply $ by 100)\n"
    "  • square_feet       — integer if listed\n"
    "  • owner_name        — owner / applicant\n"
    "  • contractor_name   — primary contractor / business\n"
    "  • contractor_phone  — 10-digit US phone if listed\n"
    "  • contractor_email  — contact email if listed\n"
    "  • trade             — one of: roofing, hvac, plumbing, "
    "electrical, solar, general, civil, other (your best guess from "
    "permit_type + description)\n"
    "  • detail_url        — the absolute URL of the CapDetail page\n\n"
    "RULES:\n"
    " - Only return real permits. Skip business licences, inspections, "
    "code-enforcement cases.\n"
    " - Leave any field you cannot find on the page as null — do NOT "
    "invent values.\n"
    " - Stop early and return what you have if you spend half the "
    "credit budget on pagination."
)


def firecrawl_agent_scrape_permits(
    scraper: dict,
    *,
    date_from: str | None = None,
    date_to:   str | None = None,
    prompt_template: str | None = None,
    model:           str | None = None,
    max_credits:     int | None = None,
    api_key:         str | None = None,
    timeout:         int = 600,
) -> dict:
    """Hand a whole scrape (list + per-row detail extraction) to the
    Firecrawl Agent. Returns an envelope::

        {
          'ok':      bool,
          'permits': [ {raw extracted dict}, ... ],
          'error':   str | None,
          'log': {
              'status':         'completed' | 'failed' | ...,
              'agent_id':       str | None,
              'model':          str,
              'credits_used':   int | None,
              'credits_budget': int,
              'prompt':         str,        # truncated, human-readable
              'latency_ms':     int,
              'error':          str | None,
          },
        }

    Records exactly one row in ``firecrawl_calls`` with ``mode='agent'``
    and ``source='accela_scraper_agent'``. NEVER raises on a Firecrawl
    failure — surfaces the error in the envelope so the worker can
    record it as a partial run rather than crashing the daemon thread.
    """
    try:
        from firecrawl import Firecrawl
        from pydantic import BaseModel, Field
    except Exception as e:                                # pragma: no cover
        raise ScraperError(
            'Firecrawl SDK is not installed. Run '
            '"pip install firecrawl-py pydantic".'
        ) from e

    key = (api_key or get_system_setting('firecrawl_api_key') or '').strip()
    if not key:
        raise ScraperError('Firecrawl API key is not configured. '
                           'Add it in Scraper Settings.')

    tmpl = (prompt_template or ACCELA_SCRAPER_AGENT_DEFAULT_PROMPT).strip()
    if not tmpl:
        tmpl = ACCELA_SCRAPER_AGENT_DEFAULT_PROMPT
    if len(tmpl) > 8000:
        tmpl = tmpl[:8000]

    mdl = (model or ACCELA_SCRAPER_AGENT_DEFAULT_MODEL).strip()
    if mdl not in ACCELA_SCRAPER_AGENT_VALID_MODELS:
        mdl = ACCELA_SCRAPER_AGENT_DEFAULT_MODEL

    try:
        mc = int(max_credits) if max_credits is not None else ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS
    except (TypeError, ValueError):
        mc = ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS
    mc = max(1, min(mc, ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP))

    safe_url   = (scraper.get('url') or '').strip()
    safe_city  = (scraper.get('city') or '').strip()
    safe_state = (scraper.get('state') or '').strip()
    safe_df    = (date_from or '').strip() or '(no lower bound)'
    safe_dt    = (date_to   or '').strip() or '(no upper bound)'
    try:
        prompt = tmpl.format(url=safe_url, city=safe_city, state=safe_state,
                             date_from=safe_df, date_to=safe_dt)
    except (IndexError, KeyError):
        prompt = (tmpl
                  .replace('{url}',       safe_url)
                  .replace('{city}',      safe_city)
                  .replace('{state}',     safe_state)
                  .replace('{date_from}', safe_df)
                  .replace('{date_to}',   safe_dt))

    # ── Pydantic schema the agent must conform its answer to ──────
    # All fields nullable so the agent can leave gaps rather than
    # hallucinate; the Python normaliser fills sensible defaults.
    class AgentPermit(BaseModel):
        permit_number:    str | None = Field(None, description='Human-readable permit number')
        permit_type:      str | None = Field(None, description='Short type/category')
        description:      str | None = Field(None, description='Work description')
        status:           str | None = Field(None, description='issued / finaled / pending / ...')
        address:          str | None = Field(None, description='Full street address')
        city:             str | None = Field(None)
        state:            str | None = Field(None)
        zip:              str | None = Field(None)
        applied_date:     str | None = Field(None, description='ISO YYYY-MM-DD')
        issued_date:      str | None = Field(None, description='ISO YYYY-MM-DD')
        expires_date:     str | None = Field(None, description='ISO YYYY-MM-DD')
        valuation_cents:  int | None = Field(None, description='Project value in CENTS (USD * 100)')
        square_feet:      int | None = Field(None)
        owner_name:       str | None = Field(None)
        contractor_name:  str | None = Field(None)
        contractor_phone: str | None = Field(None, description='Any format; normalised server-side')
        contractor_email: str | None = Field(None)
        trade:            str | None = Field(None, description='roofing/hvac/plumbing/electrical/solar/general/civil/other')
        detail_url:       str | None = Field(None, description='Absolute CapDetail URL')

    class AgentResponse(BaseModel):
        permits: list[AgentPermit] = Field(default_factory=list,
                                           description='Every permit row found.')

    fc = Firecrawl(api_key=key)
    _t0 = time.monotonic()
    _err = None
    _status = None
    _agent_id = None
    _credits = None
    _data = None
    response_obj = None
    try:
        try:
            response_obj = fc.agent(
                prompt=prompt,
                schema=AgentResponse,
                model=mdl,
                max_credits=mc,
                timeout=timeout,
            )
        except Exception as e:
            _err = f'Firecrawl agent error: {e}'

        if response_obj is not None:
            _status   = getattr(response_obj, 'status', None)
            _agent_id = getattr(response_obj, 'id', None)
            _credits  = getattr(response_obj, 'credits_used', None)
            _data     = getattr(response_obj, 'data', None)
            resp_err  = getattr(response_obj, 'error', None)
            if not _err and resp_err:
                _err = f'Firecrawl agent reported: {resp_err}'

        if _err:
            _err_lc = _err.lower()
            if any(n in _err_lc for n in ACCELA_SCRAPER_AGENT_BUDGET_HINT_NEEDLES):
                _err = (
                    f"Agent ran out of the per-run credit budget "
                    f"(used {mc} credits before finishing). Increase "
                    f"'Max credits / run' in the agent settings card "
                    f"above and re-run. (Original error: {_err})"
                )
    finally:
        try:
            db.record_firecrawl_call(
                scraper_run_id=_current_run_id(),
                source=_current_source(ACCELA_SCRAPER_AGENT_SOURCE),
                mode='agent',
                url=safe_url[:2048] or '(no url)',
                status_code=200 if _status == 'completed' else (500 if _err else None),
                latency_ms=int((time.monotonic() - _t0) * 1000),
                response_bytes=None,
                error=_err,
                city=safe_city or None,
                state=safe_state or None,
            )
        except Exception:
            log.exception('firecrawl scraper-agent usage recording failed')

    # ── Unpack the agent's structured payload into a list[dict] ──
    permits_out: list[dict] = []
    raw_list = None
    if isinstance(_data, dict):
        raw_list = _data.get('permits')
    elif _data is not None:
        try:
            raw_list = getattr(_data, 'permits', None)
            if raw_list is not None and not isinstance(raw_list, list):
                raw_list = list(raw_list)
        except Exception:
            raw_list = None

    if isinstance(raw_list, list):
        for entry in raw_list:
            if isinstance(entry, dict):
                permits_out.append(entry)
            else:
                # Pydantic model instance — convert to plain dict.
                try:
                    permits_out.append(entry.model_dump())
                except Exception:
                    try:
                        permits_out.append(dict(entry))
                    except Exception:
                        continue

    return {
        'ok':      _err is None,
        'permits': permits_out,
        'error':   _err,
        'log': {
            'status':         _status,
            'agent_id':       _agent_id,
            'model':          mdl,
            'credits_used':   _credits,
            'credits_budget': mc,
            'prompt':         prompt[:2000],
            'latency_ms':     int((time.monotonic() - _t0) * 1000),
            'error':          _err,
        },
    }


# ─────────────────────────── Normalisation ────────────────────────────

_PHONE_RE = re.compile(r'\d')
_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')

_ALLOWED_TRADES = {
    'roofing', 'hvac', 'plumbing', 'electrical', 'solar',
    'general', 'civil', 'other',
}
_ALLOWED_TIERS = {'hot', 'warm', 'cool'}


def _clean(v, default=''):
    if v is None:
        return default
    return str(v).strip()


def _to_int(v, default=None):
    if v is None or v == '':
        return default
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def _to_iso_date(v):
    if not v:
        return None
    if isinstance(v, (date, datetime)):
        return v.strftime('%Y-%m-%d')
    s = str(v).strip()
    for fmt in ('%Y-%m-%d', '%m/%d/%Y', '%m-%d-%Y', '%d/%m/%Y',
                '%B %d, %Y', '%b %d, %Y'):
        try:
            return datetime.strptime(s, fmt).strftime('%Y-%m-%d')
        except ValueError:
            continue
    return None


def _norm_phone(v):
    if not v:
        return ''
    digits = ''.join(_PHONE_RE.findall(str(v)))
    if len(digits) == 11 and digits.startswith('1'):
        digits = digits[1:]
    if len(digits) != 10:
        return ''
    return f'({digits[0:3]}) {digits[3:6]}-{digits[6:]}'


def _norm_email(v):
    if not v:
        return ''
    s = str(v).strip().lower()
    return s if _EMAIL_RE.match(s) else ''


def _norm_state(v):
    s = _clean(v).upper()
    if len(s) == 2:
        return s
    # Common full-name → abbr fallback for the most likely Accela states.
    full = {
        'WASHINGTON': 'WA', 'TEXAS': 'TX', 'CALIFORNIA': 'CA',
        'FLORIDA': 'FL', 'GEORGIA': 'GA', 'NEW YORK': 'NY',
        'ARIZONA': 'AZ', 'COLORADO': 'CO', 'OREGON': 'OR',
        'NORTH CAROLINA': 'NC', 'SOUTH CAROLINA': 'SC',
        'TENNESSEE': 'TN', 'NEVADA': 'NV', 'UTAH': 'UT',
    }
    return full.get(s, s[:2])


def _normalise_permit(raw: dict) -> dict:
    """Coerce Claude's JSON into the exact shape ``upsert_permit`` accepts."""
    trade = _clean(raw.get('trade'), 'other').lower()
    if trade not in _ALLOWED_TRADES:
        trade = 'other'
    tier = _clean(raw.get('ai_tier'), 'cool').lower()
    if tier not in _ALLOWED_TIERS:
        tier = 'cool'
    score = _to_int(raw.get('ai_score'), 50) or 50
    score = max(0, min(100, score))
    return {
        'permit_number':    _clean(raw.get('permit_number')),
        'permit_type':      _clean(raw.get('permit_type'), 'Permit'),
        'description':      _clean(raw.get('description')),
        'status':           _clean(raw.get('status'), 'unknown').lower(),
        'applied_date':     _to_iso_date(raw.get('applied_date')),
        'issued_date':      _to_iso_date(raw.get('issued_date')),
        'expires_date':     _to_iso_date(raw.get('expires_date')),
        'address':          _clean(raw.get('address')),
        'city':             _clean(raw.get('city')).title(),
        'state':            _norm_state(raw.get('state')),
        'zip':              _clean(raw.get('zip')),
        'latitude':         raw.get('latitude') if isinstance(raw.get('latitude'), (int, float)) else None,
        'longitude':        raw.get('longitude') if isinstance(raw.get('longitude'), (int, float)) else None,
        'owner_name':       _clean(raw.get('owner_name')),
        'contractor_name':  _clean(raw.get('contractor_name')),
        'contractor_phone': _norm_phone(raw.get('contractor_phone')),
        'contractor_email': _norm_email(raw.get('contractor_email')),
        'valuation_cents':  _to_int(raw.get('valuation_cents'), 0),
        'square_feet':      _to_int(raw.get('square_feet')),
        'trade':            trade,
        'ai_score':         score,
        'ai_grade':         _clean(raw.get('ai_grade'), 'C')[:4],
        'ai_tier':          tier,
        'ai_reasoning':     _clean(raw.get('ai_reasoning'))[:500],
        'ai_model_version': (get_system_setting('claude_model') or DEFAULT_MODEL),
        'ai_scored_at':     datetime.utcnow(),
    }


# ─────────────────────────── City auto-register ───────────────────────

def _validate_and_register_city(city: str, state: str) -> bool:
    """If the (city, state) pair isn't in the supported_cities list,
    add it. Returns True if we just added a new entry."""
    c = _clean(city).title()
    s = _clean(state).upper()
    if not c or not s:
        return False
    existing = get_supported_cities()
    if any(x['city'].lower() == c.lower() and x['state'] == s for x in existing):
        return False
    try:
        added = add_supported_city(c, s)
        if added:
            log.info('scraper auto-registered new supported city: %s, %s', c, s)
        return added
    except Exception:
        log.exception('auto-register city failed for %s, %s', c, s)
        return False


# ─────────────────────────── Orchestration ────────────────────────────

def scrape_one(scraper: dict, url: str | None = None,
               *, run_id: int | None = None) -> dict:
    """Run the full pipeline for one Accela URL.

    Steps:
      1. Firecrawl scrape (markdown + html + Firecrawl-LLM json)
      2. If Firecrawl's `json` is non-empty → use it directly
         (skip the second Claude call — saves time and tokens).
      3. Otherwise → Claude extracts from the markdown.
      4. Normalise → register city → upsert_permit.
    Returns the upserted permit dict on success.
    """
    # If a run_id is provided and the thread isn't already inside a
    # _track_run scope, tag the API calls with it for the duration of
    # this scrape. (The cron worker sets this once for the whole run;
    # ad-hoc sync calls from views go through this branch.)
    if run_id is not None and _current_run_id() is None:
        with _track_run(run_id, source='accela'):
            return _scrape_one_inner(scraper, url, run_id=run_id)
    return _scrape_one_inner(scraper, url, run_id=run_id)


def _scrape_one_inner(scraper: dict, url: str | None = None,
                      *, run_id: int | None = None) -> dict:
    target_url = (url or scraper['url']).strip()
    fc = firecrawl_scrape(target_url)
    fc_json = fc.get('json') or {}
    # Trust Firecrawl's structured output only when it has the bare
    # minimum to be a real permit. Otherwise fall back to Claude on
    # the markdown — slower but more forgiving on weird layouts.
    has_min_fields = bool(
        (fc_json.get('permit_number') or '').strip()
        or (fc_json.get('address') or '').strip()
    )
    if has_min_fields:
        permit = _normalise_permit(fc_json)
    else:
        permit = claude_extract(fc['markdown'], source_url=target_url)
    if not permit.get('permit_number'):
        # Fall back to the URL's capID composite so we don't lose a row
        # — better to upsert with a synthetic id than drop the result.
        parsed = parse_accela_url(target_url)
        composite = '-'.join(filter(None, [
            parsed.get('agency_code', ''),
            parsed.get('cap_id_1', ''),
            parsed.get('cap_id_2', ''),
            parsed.get('cap_id_3', ''),
        ]))
        permit['permit_number'] = composite or f'unknown-{int(time.time())}'

    # Source-id stable across reruns: the agency + cap composite.
    parsed = parse_accela_url(target_url)
    composite = '-'.join(filter(None, [
        parsed.get('agency_code', ''),
        parsed.get('cap_id_1', ''),
        parsed.get('cap_id_2', ''),
        parsed.get('cap_id_3', ''),
    ])) or permit['permit_number']

    permit['source']           = db._scraper_source_tag(scraper['id'])
    permit['source_permit_id'] = composite
    permit['jurisdiction']     = scraper.get('agency_code') or scraper.get('city') or ''
    # Stash a generous chunk of Firecrawl's raw markdown so the
    # admin can hit "View source" later and audit what the LLM saw.
    permit['raw'] = {
        'scraped_url':        target_url,
        'scraper_id':         scraper['id'],
        'scraper_name':       scraper.get('name'),
        'mode':               'detail',
        'fetched_at':         datetime.utcnow().isoformat() + 'Z',
        'markdown':           (fc.get('markdown') or '')[:80000],
        'firecrawl_json':     fc_json,
        'firecrawl_metadata': fc.get('metadata') or {},
    }
    _validate_and_register_city(permit.get('city', ''), permit.get('state', ''))
    # Lineage: tag the permit with the run that created it (if any).
    # Sync paths sometimes call us without a run_id — that's fine,
    # the column is nullable.
    if run_id is not None:
        permit['scraper_run_id'] = int(run_id)
    upsert_permit(permit)
    return permit


def scrape_list(scraper: dict, url: str | None = None,
                *, run_id: int | None = None) -> list[dict]:
    """Scrape an Accela CapHome / search-results LIST URL.

    Fires ONE Firecrawl request that returns the rendered markdown
    PLUS a structured ``{permits: […]}`` JSON extraction. We then
    iterate the rows, upsert each, and return the list of upserted
    permit dicts so the caller (the worker thread) can tick a
    real progress bar.
    """
    if run_id is not None and _current_run_id() is None:
        with _track_run(run_id, source='accela'):
            return _scrape_list_inner(scraper, url, run_id=run_id)
    return _scrape_list_inner(scraper, url, run_id=run_id)


def _scrape_list_inner(scraper: dict, url: str | None = None,
                       *, run_id: int | None = None) -> list[dict]:
    target_url = (url or scraper['url']).strip()
    fc = firecrawl_scrape(target_url, mode='list')
    fc_json = fc.get('json') or {}
    rows = fc_json.get('permits') if isinstance(fc_json, dict) else None
    if not isinstance(rows, list):
        rows = []
    md = (fc.get('markdown') or '')[:80000]

    out: list[dict] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        permit = _normalise_permit(row)
        # The permit_number is the only stable identifier we get from
        # a list row — without it the upsert key collides on
        # empty-string and the row would be dropped silently.
        pnum = (permit.get('permit_number') or '').strip()
        if not pnum:
            continue
        # Required identity tuple — `upsert_permit` keys on
        # (source, source_permit_id) and ALSO requires non-empty
        # state + city; missing any of these and the upsert returns
        # None without writing anything.
        permit['source']           = db._scraper_source_tag(scraper['id'])
        permit['source_permit_id'] = pnum
        permit['jurisdiction']     = scraper.get('agency_code') or scraper.get('city') or ''
        if not (permit.get('state') or '').strip():
            permit['state'] = (scraper.get('state') or '').strip()
        if not (permit.get('city') or '').strip():
            permit['city'] = (scraper.get('city') or '').strip()
        if not (permit.get('state') or '').strip() or not (permit.get('city') or '').strip():
            # We can't satisfy upsert_permit's required fields — skip
            # rather than pretend it succeeded.
            continue
        permit['raw'] = {
            'scraped_url':        target_url,
            'scraper_id':         scraper['id'],
            'scraper_name':       scraper.get('name'),
            'mode':               'list',
            'fetched_at':         datetime.utcnow().isoformat() + 'Z',
            # Save the page markdown ONCE per permit so View-source
            # works on every row of this run. Truncated to 80KB.
            'markdown':           md,
            'list_row':           row,
            'firecrawl_metadata': fc.get('metadata') or {},
        }
        _validate_and_register_city(permit.get('city', ''), permit.get('state', ''))
        if run_id is not None:
            permit['scraper_run_id'] = int(run_id)
        result = upsert_permit(permit)
        if result is None:
            # upsert_permit returns None when required keys are missing
            # — treat as a hard skip, don't add to the success bucket.
            continue
        out.append(permit)
    return out


# ─────────────────────────── Background runner ────────────────────────

# Cap how far the unified list-scrape walks Accela pagination. Even
# when URL increments DO work (rare), we don't want a runaway
# many-page run on the admin's first click — they can re-run with
# a tighter date filter for more pages.
_MAX_LIST_PAGES: int = 5


def _coerce_iso_date(v) -> str:
    """Best-effort ISO-date coercion. Accepts ``date``/``datetime``,
    a YYYY-MM-DD string, or a falsy value (returns '')."""
    if not v:
        return ''
    if isinstance(v, (date, datetime)):
        return v.strftime('%Y-%m-%d')
    s = str(v).strip()
    if not s:
        return ''
    iso = _to_iso_date(s)
    return iso or s[:10]


def _row_in_date_range(row: dict, df: str, dt: str) -> bool:
    """Post-extraction safety net for the date filter. The unified
    prompt asks the LLM to drop out-of-range rows itself, but LLMs
    occasionally include them anyway — so we re-check here on the
    Python side. A row with no parseable applied_date is kept (we
    don't want to silently drop rows just because the LLM missed a
    date column)."""
    if not df and not dt:
        return True
    raw = row.get('applied_date') or row.get('issued_date')
    iso = _to_iso_date(raw) if raw else None
    if not iso:
        return True
    if df and iso < df:
        return False
    if dt and iso > dt:
        return False
    return True


def _accela_paged_url(url: str, page_num: int) -> str:
    """Best-effort URL-based pagination for Accela list pages.

    Real Accela CapHome paging uses ASP.NET ``__doPostBack`` which we
    can't trigger without a real browser. As a fallback we set the
    most common URL parameter Accela honours when paging IS exposed
    in the query string (``PageNumber``). Most production Accela
    instances will simply ignore it and return page 1 again — the
    worker detects that via the dedupe set and stops.
    """
    if page_num <= 1:
        return url
    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    qs['PageNumber'] = [str(page_num)]
    flat = [(k, v[0]) for k, v in qs.items()]
    new_q = urllib.parse.urlencode(flat, doseq=False)
    return urllib.parse.urlunparse(parsed._replace(query=new_q))


def _run_agent_branch(*, scraper: dict, run_id: int,
                      date_from=None, date_to=None) -> None:
    """Branch 0: hand the whole list+detail+extract job to Firecrawl
    Agent in a single SDK call, then upsert each returned permit.

    Reads the admin-saved agent settings (prompt template / model /
    max credits) from system_settings, falling back to the constants
    above. Streams progress to scraper_runs.step_log so the admin
    terminal panel still feels live (the Agent itself is a single
    long-poll call so we can't stream per-row progress *during* the
    fetch — but we always log start, the per-row upsert phase, and a
    final summary).
    """
    df = _coerce_iso_date(date_from)
    dt = _coerce_iso_date(date_to)

    saved_prompt   = (get_system_setting('accela_scraper_agent_prompt_template') or '').strip()
    saved_model    = (get_system_setting('accela_scraper_agent_model') or '').strip()
    saved_credits  = (get_system_setting('accela_scraper_agent_max_credits') or '').strip()
    prompt_template = saved_prompt or ACCELA_SCRAPER_AGENT_DEFAULT_PROMPT
    model = (saved_model
             if saved_model in ACCELA_SCRAPER_AGENT_VALID_MODELS
             else ACCELA_SCRAPER_AGENT_DEFAULT_MODEL)
    try:
        max_credits = int(saved_credits) if saved_credits else ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS
    except (TypeError, ValueError):
        max_credits = ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS
    max_credits = max(1, min(max_credits, ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP))

    date_blurb = ''
    if df or dt:
        date_blurb = f' (date filter: {df or "begin"} → {dt or "today"})'
    append_scraper_run_step(
        run_id,
        f'▶ Starting agent scrape{date_blurb} '
        f'(model={model}, max_credits={max_credits})',
        'info',
    )
    update_scraper_run(
        run_id,
        status='running',
        current_step=f'agent browsing {scraper.get("url") or "the search page"}…',
    )

    # ── Single agent call. The SDK blocks until the agent finishes
    # OR exhausts its credit budget; can take 1-5 minutes for a
    # full city search. firecrawl_agent_scrape_permits() never
    # raises on Firecrawl errors — it returns ok=False with the
    # error string in the envelope.
    envelope = firecrawl_agent_scrape_permits(
        scraper=scraper,
        date_from=df,
        date_to=dt,
        prompt_template=prompt_template,
        model=model,
        max_credits=max_credits,
    )
    permits_raw = envelope.get('permits') or []
    agent_log   = envelope.get('log') or {}
    credits_used = agent_log.get('credits_used')
    latency_ms   = agent_log.get('latency_ms')
    err          = envelope.get('error')

    cu_blurb = ''
    if credits_used is not None:
        cu_blurb = f' · {credits_used} credits used'
    if isinstance(latency_ms, int):
        cu_blurb += f' · {latency_ms / 1000:.1f}s'

    if err:
        append_scraper_run_step(
            run_id,
            f'⚠ Agent reported: {err[:300]}{cu_blurb}',
            'warn',
        )
    if not permits_raw:
        append_scraper_run_step(
            run_id,
            f'ℹ Agent returned 0 permit rows{cu_blurb}.',
            'warn',
        )
        update_scraper_run(
            run_id,
            total_targets=0,
            processed=0,
            succeeded=0,
            failed=0,
            current_step='agent returned no rows',
            error=([{'url':   scraper.get('url') or '',
                     'error': err[:300] if err else 'agent returned no rows',
                     'when':  datetime.utcnow().isoformat() + 'Z'}]
                   if err else None),
        )
        refresh_scraper_total_permits(scraper['id'])
        update_scraper_run(run_id, status='failed',
                           finished_at=datetime.utcnow(),
                           current_step='done — 0 rows')
        update_scraper(scraper['id'], last_run_at=datetime.utcnow(),
                       last_run_status='failed')
        return

    n = len(permits_raw)
    append_scraper_run_step(
        run_id,
        f'📊 Agent returned {n} permit row(s){cu_blurb} — upserting…',
        'ok',
    )
    update_scraper_run(
        run_id,
        total_targets=n,
        processed=0,
        current_step=f'upserting {n} permit(s)…',
    )

    succeeded = 0
    failed = 0
    inserted = 0
    updated = 0
    cross_dup = 0
    errors: list[dict] = []
    seen_local_keys: set[str] = set()

    source_tag = db._scraper_source_tag(scraper['id'])
    base_url   = scraper.get('url') or ''

    for j, raw in enumerate(permits_raw, 1):
        if not isinstance(raw, dict):
            failed += 1
            continue
        try:
            permit = _normalise_permit(raw)
            pnum = (permit.get('permit_number') or '').strip()
            if not pnum:
                raise ScraperError(f'row {j}: missing permit_number')

            # ── Required identity for upsert (fall back to scraper config)
            permit['source']           = source_tag
            permit['source_permit_id'] = pnum
            permit['jurisdiction']     = scraper.get('agency_code') or scraper.get('city') or ''
            if not (permit.get('state') or '').strip():
                permit['state'] = (scraper.get('state') or '').strip()
            if not (permit.get('city') or '').strip():
                permit['city'] = (scraper.get('city') or '').strip()
            if not (permit.get('state') or '').strip():
                raise ScraperError(f'row {j} ({pnum}): missing state '
                                   '(agent + scraper both empty)')
            if not (permit.get('city') or '').strip():
                raise ScraperError(f'row {j} ({pnum}): missing city '
                                   '(agent + scraper both empty)')

            # In-batch dedup so the agent returning the same permit
            # twice (e.g. same row on two pagination pages) doesn't
            # double-count toward succeeded.
            local_key = f'{source_tag}|{pnum}'
            if local_key in seen_local_keys:
                append_scraper_run_step(
                    run_id,
                    f'  · ({j}/{n}) {pnum}: duplicate in agent payload, skipping',
                    'info',
                )
                continue
            seen_local_keys.add(local_key)

            permit['raw'] = {
                'agent_extracted': raw,
                'list_url':        base_url,
                'detail_url':      raw.get('detail_url') or '',
                'scraper_id':      scraper['id'],
                'scraper_name':    scraper.get('name'),
                'mode':            'agent',
                'fetched_at':      datetime.utcnow().isoformat() + 'Z',
                'agent_log': {
                    'model':          agent_log.get('model'),
                    'agent_id':       agent_log.get('agent_id'),
                    'credits_used':   agent_log.get('credits_used'),
                    'credits_budget': agent_log.get('credits_budget'),
                },
            }
            _validate_and_register_city(permit.get('city', ''),
                                        permit.get('state', ''))
            permit['scraper_run_id'] = int(run_id)

            result = upsert_permit(permit)
            if result is None:
                raise ScraperError(
                    f'row {j} ({pnum}): upsert returned None — '
                    'required identity fields not satisfied'
                )
            action, _pid = result
            succeeded += 1
            if action == 'inserted':
                inserted += 1
            else:
                updated += 1

            # Was this an UPDATE that landed on a row owned by a
            # DIFFERENT source? That's a cross-source dedup hit and
            # the admin will want to know about it.
            existing = pg.query_one(
                'SELECT source FROM permits WHERE id = %s', (int(_pid),),
            ) if action == 'updated' else None
            if existing and (existing.get('source') or '') != source_tag:
                cross_dup += 1
                append_scraper_run_step(
                    run_id,
                    f'  ⤳ ({j}/{n}) {pnum}: matched existing row from '
                    f'source={existing.get("source")} — enriched in place',
                    'info',
                )
        except Exception as e:
            failed += 1
            log.exception('agent-row %s upsert failed', j)
            pnum_log = (raw.get('permit_number') or f'row-{j}') if isinstance(raw, dict) else f'row-{j}'
            errors.append({
                'url':   (raw.get('detail_url') if isinstance(raw, dict) else '') or base_url,
                'error': str(e)[:300],
                'when':  datetime.utcnow().isoformat() + 'Z',
            })
            if len(errors) > 50:
                errors = errors[-50:]
            append_scraper_run_step(
                run_id,
                f'  ✗ ({j}/{n}) {pnum_log} failed: {str(e)[:140]}',
                'err',
            )

        update_scraper_run(
            run_id,
            processed=j,
            succeeded=succeeded,
            failed=failed,
            error=errors or None,
        )

    summary = (
        f'🏁 Done — {succeeded} saved '
        f'({inserted} new, {updated} updated, {cross_dup} cross-src dup), '
        f'{failed} failed{cu_blurb}'
    )
    append_scraper_run_step(
        run_id, summary,
        'ok' if failed == 0 and succeeded > 0 else
        ('warn' if succeeded else 'err'),
    )

    refresh_scraper_total_permits(scraper['id'])
    final_status = (
        'success' if failed == 0 and succeeded > 0 else
        'failed'  if succeeded == 0 else
        'partial'
    )
    update_scraper_run(
        run_id,
        status=final_status,
        finished_at=datetime.utcnow(),
        current_step=f'done — {succeeded} ok, {failed} failed',
    )
    update_scraper(
        scraper['id'],
        last_run_at=datetime.utcnow(),
        last_run_status=final_status,
    )


def _run_worker(scraper_id: int, run_id: int, *, mode: str,
                count: int | None = None,
                date_from=None, date_to=None) -> None:
    """The body of the daemon thread. Catches everything so a per-URL
    failure can never bring the process down."""
    with _track_run(run_id, source='accela'):
        return _run_worker_body(
            scraper_id, run_id, mode=mode, count=count,
            date_from=date_from, date_to=date_to,
        )


def _run_worker_body(scraper_id: int, run_id: int, *, mode: str,
                     count: int | None = None,
                     date_from=None, date_to=None) -> None:
    scraper = get_scraper(scraper_id)
    if not scraper:
        update_scraper_run(run_id, status='failed',
                           current_step='scraper not found',
                           finished_at=datetime.utcnow())
        return

    update_scraper_run(run_id, status='running',
                       current_step='preparing targets')

    succeeded = 0
    failed = 0
    errors: list[dict] = []

    def _finalize() -> None:
        refresh_scraper_total_permits(scraper_id)
        final_status = (
            'success' if failed == 0 and succeeded > 0 else
            'failed'  if succeeded == 0 else
            'partial'
        )
        update_scraper_run(
            run_id,
            status=final_status,
            finished_at=datetime.utcnow(),
            current_step=f'done — {succeeded} ok, {failed} failed',
        )
        update_scraper(
            scraper_id,
            last_run_at=datetime.utcnow(),
            last_run_status=final_status,
        )

    # ─── Branch 0: single-mode via the Firecrawl Agent ─────────────
    # New default for the per-scraper "Run now" button. ONE agent
    # call replaces the old list-fetch + per-row Claude pipeline:
    # the agent autonomously paginates, opens each detail page and
    # returns a structured permits[] array we can upsert directly.
    # Set system_setting `accela_scraper_use_agent` = 'off' to fall
    # through to the legacy code path below.
    _agent_pref = (get_system_setting('accela_scraper_use_agent') or 'on').strip().lower()
    if mode == 'single' and _agent_pref != 'off':
        try:
            _run_agent_branch(
                scraper=scraper, run_id=run_id,
                date_from=date_from, date_to=date_to,
            )
        except Exception:
            log.exception('scraper run %s — agent branch crashed', run_id)
            append_scraper_run_step(
                run_id,
                '✗ Fatal: agent branch crashed (see server log) — '
                'finalising the run',
                'err',
            )
            update_scraper_run(
                run_id,
                error=[{'url': scraper.get('url') or '',
                        'error': 'agent branch crashed — see server log',
                        'when':  datetime.utcnow().isoformat() + 'Z'}],
                current_step='agent branch crashed',
            )
            update_scraper(scraper_id, last_run_at=datetime.utcnow(),
                           last_run_status='failed')
            update_scraper_run(run_id, status='failed',
                               finished_at=datetime.utcnow())
            return
        # _run_agent_branch handles its own _finalize-equivalent.
        return

    # ─── Branch 1: single-mode against a LIST URL (CapHome etc.) ───
    # Unified flow: paginate the list (best-effort URL increment) →
    # date-filter rows → per-row open the CapDetail page and have
    # Claude do a full extraction → upsert. Every meaningful step
    # gets appended to step_log so the admin terminal panel renders
    # a CLI-style transcript in real time.
    if mode == 'single' and is_accela_list_url(scraper['url']):
        list_url = scraper['url']
        df = _coerce_iso_date(date_from)
        dt = _coerce_iso_date(date_to)

        date_blurb = ''
        if df or dt:
            date_blurb = f' (date filter: {df or "begin"} → {dt or "today"})'
        append_scraper_run_step(
            run_id,
            f'▶ Starting unified list scrape{date_blurb}', 'info',
        )

        try:
            page_targets, seen_pnums, all_rows = [], set(), []
            for page_num in range(1, _MAX_LIST_PAGES + 1):
                page_url = _accela_paged_url(list_url, page_num) if page_num > 1 else list_url
                append_scraper_run_step(
                    run_id,
                    f'📋 Fetching list page {page_num} via Firecrawl…',
                    'info',
                )
                update_scraper_run(
                    run_id,
                    current_step=f'fetching list page {page_num}…',
                )
                try:
                    fc_list = firecrawl_scrape(
                        page_url, mode='list',
                        date_from=df, date_to=dt,
                    )
                except ScraperError as e:
                    append_scraper_run_step(
                        run_id,
                        f'⚠ Page {page_num} fetch failed: {str(e)[:160]}',
                        'warn',
                    )
                    if page_num == 1:
                        raise
                    break

                fc_json = fc_list.get('json') or {}
                page_rows = fc_json.get('permits') if isinstance(fc_json, dict) else None
                if not isinstance(page_rows, list):
                    page_rows = []
                # Filter: dedupe across pages + drop out-of-date rows.
                # IMPORTANT: pagination decisions MUST be based on raw
                # row counts (true exhaustion vs URL-paginator-ignored),
                # NOT on the post-date-filter count — page 1 might be
                # entirely out-of-range while page 2 contains keepers.
                kept_this_page = []
                dropped_dup, dropped_date = 0, 0
                raw_row_count = 0  # rows we actually saw in the markdown
                new_row_count = 0  # rows whose permit# we hadn't seen
                for row in page_rows:
                    if not isinstance(row, dict):
                        continue
                    raw_row_count += 1
                    pnum = (row.get('permit_number') or '').strip()
                    if pnum and pnum in seen_pnums:
                        dropped_dup += 1
                        continue
                    new_row_count += 1
                    if not _row_in_date_range(row, df, dt):
                        dropped_date += 1
                        # Still mark it seen so we don't re-process the
                        # same row if the URL paginator returns it again.
                        if pnum:
                            seen_pnums.add(pnum)
                        continue
                    if pnum:
                        seen_pnums.add(pnum)
                    kept_this_page.append(row)
                    page_targets.append((page_num, page_url, row, fc_list))
                msg = (f'✓ Page {page_num}: {raw_row_count} row(s), '
                       f'kept {len(kept_this_page)}')
                if dropped_dup:
                    msg += f', {dropped_dup} dup'
                if dropped_date:
                    msg += f', {dropped_date} out-of-range'
                append_scraper_run_step(
                    run_id, msg,
                    'ok' if kept_this_page else 'warn',
                )
                all_rows.extend(kept_this_page)

                # Pagination stop conditions (date filter intentionally
                # NOT consulted here — see comment above):
                #   (a) page returned 0 raw rows → list exhausted
                #   (b) page returned rows but every one was a dup of
                #       a previous page → the URL ?PageNumber=N param
                #       isn't honoured by this Accela instance (some
                #       CapHome screens use POST __doPostBack which we
                #       can't follow without a real browser); no point
                #       fetching another identical page.
                if raw_row_count == 0:
                    append_scraper_run_step(
                        run_id,
                        ('ℹ Page 1 returned 0 rows — stopping.'
                         if page_num == 1
                         else f'ℹ Page {page_num} returned 0 rows — list exhausted.'),
                        'info' if page_num > 1 else 'warn',
                    )
                    break
                if page_num > 1 and new_row_count == 0:
                    append_scraper_run_step(
                        run_id,
                        f'ℹ Page {page_num} repeated page 1 — Accela '
                        'is using JS-only paging which we cannot '
                        'follow. Stopping.',
                        'info',
                    )
                    break

            n = len(page_targets)
            update_scraper_run(
                run_id,
                total_targets=max(n, 1),
                current_step=f'parsing {n} permit(s) across pages…',
            )
            append_scraper_run_step(
                run_id,
                f'📊 Total to process: {n} permit(s) across '
                f'{min(page_num, _MAX_LIST_PAGES)} page(s)',
                'info',
            )

            if n == 0:
                errors.append({
                    'url':   list_url,
                    'error': 'List page parsed but produced 0 rows after '
                             'date filtering. Widen the date range, edit '
                             'the extraction prompt, or open the URL in a '
                             'browser to verify it has visible permits.',
                    'when':  datetime.utcnow().isoformat() + 'Z',
                })
                update_scraper_run(run_id, error=errors)

            for j, (page_num, page_url, row, fc_list) in enumerate(page_targets, 1):
                pnum_log = (row.get('permit_number') or f'row-{j}').strip()
                update_scraper_run(
                    run_id,
                    processed=j - 1,
                    current_step=f'permit {j}/{n}: {pnum_log}',
                )
                try:
                    permit = _normalise_permit(row)
                    pnum = (permit.get('permit_number') or '').strip()
                    if not pnum:
                        raise ScraperError(f'row {j} missing permit_number')

                    # ── Per-row detail follow-up via Firecrawl + Claude ──
                    # If the list extractor surfaced a detail_url, fetch
                    # that page so we can fill in contractor info, dates,
                    # owner, valuation — fields the LIST table never
                    # shows. If anything goes wrong with the detail call
                    # we keep the partial list-row data rather than
                    # failing the whole permit.
                    detail_url = (row.get('detail_url') or '').strip()
                    detail_md = ''
                    detail_used = False
                    if detail_url and detail_url.lower().startswith(('http://', 'https://')):
                        append_scraper_run_step(
                            run_id,
                            f'  → ({j}/{n}) {pnum}: opening detail page…',
                            'info',
                        )
                        try:
                            fc_detail = firecrawl_scrape(detail_url, mode='detail')
                            detail_md = (fc_detail.get('markdown') or '')[:80000]
                            if detail_md:
                                # Prefer Claude's full extraction over the
                                # Firecrawl in-call extraction — Claude is
                                # what we tuned the prompt for.
                                claude_data = claude_extract(
                                    detail_md, source_url=detail_url,
                                )
                                # Merge: detail-page Claude data wins for
                                # any field it returned non-empty; list
                                # row stays as fallback.
                                merged = dict(permit)
                                for k, v in claude_data.items():
                                    if v not in (None, '', [], {}):
                                        merged[k] = v
                                permit = merged
                                detail_used = True
                        except ScraperError as e:
                            append_scraper_run_step(
                                run_id,
                                f'  ⚠ {pnum}: detail fetch failed '
                                f'({str(e)[:100]}) — using list-row data',
                                'warn',
                            )

                    # ── Required identity for upsert_permit ───────────
                    # Without (source, source_permit_id, state, city) the
                    # upsert silently drops the row. Backfill from the
                    # scraper config when the extractor left them blank.
                    permit['source']           = db._scraper_source_tag(scraper['id'])
                    permit['source_permit_id'] = pnum
                    permit['jurisdiction']     = scraper.get('agency_code') or scraper.get('city') or ''
                    if not (permit.get('state') or '').strip():
                        permit['state'] = (scraper.get('state') or '').strip()
                    if not (permit.get('city') or '').strip():
                        permit['city'] = (scraper.get('city') or '').strip()
                    if not (permit.get('state') or '').strip():
                        raise ScraperError(f'row {j} missing state '
                                           '(extractor + scraper both empty)')
                    if not (permit.get('city') or '').strip():
                        raise ScraperError(f'row {j} missing city '
                                           '(extractor + scraper both empty)')
                    permit['raw'] = {
                        'scraped_url':        detail_url or page_url,
                        'list_url':           list_url,
                        'list_page':          page_num,
                        'scraper_id':         scraper['id'],
                        'scraper_name':       scraper.get('name'),
                        'mode':               'detail' if detail_used else 'list',
                        'detail_used':        detail_used,
                        'fetched_at':         datetime.utcnow().isoformat() + 'Z',
                        'markdown':           detail_md or (fc_list.get('markdown') or '')[:80000],
                        'list_row':           row,
                        'firecrawl_metadata': fc_list.get('metadata') or {},
                    }
                    _validate_and_register_city(
                        permit.get('city', ''), permit.get('state', ''),
                    )
                    # Lineage: stamp the run id on every permit this run
                    # creates / updates so the admin can later list or
                    # bulk-delete just this run's output.
                    permit['scraper_run_id'] = int(run_id)
                    result = upsert_permit(permit)
                    if result is None:
                        raise ScraperError(
                            f'row {j} ({pnum}) upsert returned None — '
                            'required identity fields not satisfied'
                        )
                    succeeded += 1
                    grade = permit.get('ai_grade') or '?'
                    score = permit.get('ai_score') or 0
                    src   = 'detail+claude' if detail_used else 'list-only'
                    append_scraper_run_step(
                        run_id,
                        f'  ✓ ({j}/{n}) {pnum} saved · {grade} ({score}) · {src}',
                        'ok',
                    )
                except Exception as e:
                    failed += 1
                    log.exception('list-row %s upsert failed', j)
                    errors.append({
                        'url':   (row.get('detail_url') or page_url) + f'#row-{j}',
                        'error': str(e)[:300],
                        'when':  datetime.utcnow().isoformat() + 'Z',
                    })
                    if len(errors) > 50:
                        errors = errors[-50:]
                    append_scraper_run_step(
                        run_id,
                        f'  ✗ ({j}/{n}) {pnum_log} failed: {str(e)[:140]}',
                        'err',
                    )
                update_scraper_run(run_id,
                                   processed=j,
                                   succeeded=succeeded,
                                   failed=failed,
                                   error=errors)

            append_scraper_run_step(
                run_id,
                f'🏁 Done — {succeeded} saved, {failed} failed',
                'ok' if failed == 0 else ('warn' if succeeded else 'err'),
            )
        except Exception as e:
            failed += 1
            log.exception('scraper run %s — list-page fetch failed', run_id)
            errors.append({
                'url':   scraper['url'],
                'error': str(e)[:300],
                'when':  datetime.utcnow().isoformat() + 'Z',
            })
            append_scraper_run_step(
                run_id,
                f'✗ Fatal: list fetch failed — {str(e)[:200]}',
                'err',
            )
            update_scraper_run(run_id,
                               processed=0,
                               failed=failed,
                               error=errors,
                               current_step=f'list fetch failed: {str(e)[:80]}')
        _finalize()
        return

    # ─── Branch 2: detail URLs (single + backfill + cron) ──────────
    targets: list[str] = []
    if mode == 'single':
        targets = [scraper['url']]
    else:
        # backfill or cron — enumerate cap_id_3 backwards from the
        # template's stored cap_id_3 by `count` steps. Accela CAP IDs
        # are roughly time-ordered so the most recent N IDs are a
        # decent proxy for "the last N permits".
        if is_accela_list_url(scraper['url']):
            failed += 1
            errors.append({
                'url':   scraper['url'],
                'error': 'Backfill walks the cap_id_3 sequence backwards — '
                         'that only works on CapDetail.aspx URLs. Configure '
                         'this scraper with a single-permit URL, or use '
                         '"Run now" to scrape the list page in place.',
                'when':  datetime.utcnow().isoformat() + 'Z',
            })
            update_scraper_run(
                run_id,
                processed=0,
                total_targets=0,
                failed=failed,
                error=errors,
                current_step='backfill needs a CapDetail.aspx URL, not a list URL',
            )
            # Route through _finalize so scraper.last_run_at /
            # last_run_status get refreshed and admin metadata stays
            # consistent with the run row.
            _finalize()
            return
        n = max(1, min(int(count or 20), 500))
        parsed = parse_accela_url(scraper['url'])
        try:
            base = int((parsed.get('cap_id_3') or '0').lstrip('0') or '0')
        except (TypeError, ValueError):
            base = 0
        for offset in range(n):
            cid = base - offset
            if cid <= 0:
                break
            targets.append(build_accela_url(scraper['url'], cap_id_3=cid))

    update_scraper_run(run_id,
                       total_targets=len(targets),
                       current_step=f'fetching {len(targets)} target(s)')

    for i, url in enumerate(targets, 1):
        update_scraper_run(run_id,
                           processed=i - 1,
                           current_step=f'scraping {i}/{len(targets)}…')
        try:
            scrape_one(scraper, url)
            succeeded += 1
        except Exception as e:
            failed += 1
            log.exception('scraper run %s failed for url %s', run_id, url)
            errors.append({
                'url':   url,
                'error': str(e)[:300],
                'when':  datetime.utcnow().isoformat() + 'Z',
            })
            if len(errors) > 50:
                errors = errors[-50:]
        update_scraper_run(run_id,
                           processed=i,
                           succeeded=succeeded,
                           failed=failed,
                           error=errors)
    _finalize()


def run_scraper_async(scraper_id: int, *, mode: str = 'single',
                      kind: str = 'manual',
                      count: int | None = None,
                      date_from=None, date_to=None) -> int:
    """Kick off a scraper run in a daemon thread and return the run_id
    immediately so the UI can begin polling the progress endpoint."""
    if mode not in ('single', 'backfill', 'cron'):
        raise ScraperError(f'unknown mode: {mode}')
    targets_estimate = 1 if mode == 'single' else max(1, int(count or 20))
    run_id = create_scraper_run(
        scraper_id,
        kind=kind,
        mode=mode,
        total_targets=targets_estimate,
        date_from=date_from,
        date_to=date_to,
    )
    t = threading.Thread(
        target=_run_worker,
        kwargs={
            'scraper_id': scraper_id,
            'run_id':     run_id,
            'mode':       mode,
            'count':      count,
            'date_from':  date_from,
            'date_to':    date_to,
        },
        daemon=True,
        name=f'scraper-run-{run_id}',
    )
    t.start()
    return run_id


def run_scraper_sync(scraper_id: int, *, kind: str = 'manual') -> dict:
    """Synchronous single-URL run — used by the 'Run now' admin button
    when the admin wants the result immediately rather than polling.
    Returns {run_id, status, succeeded, failed}."""
    scraper = get_scraper(scraper_id)
    if not scraper:
        raise ScraperError('scraper not found')
    run_id = create_scraper_run(scraper_id, kind=kind, mode='single',
                                total_targets=1)
    update_scraper_run(run_id, status='running',
                       current_step='scraping single URL')
    try:
        scrape_one(scraper, run_id=run_id)
        update_scraper_run(run_id, status='success',
                           processed=1, succeeded=1,
                           finished_at=datetime.utcnow(),
                           current_step='done — 1 ok, 0 failed')
        update_scraper(scraper_id,
                       last_run_at=datetime.utcnow(),
                       last_run_status='success')
        refresh_scraper_total_permits(scraper_id)
        return {'run_id': run_id, 'status': 'success',
                'succeeded': 1, 'failed': 0}
    except Exception as e:
        update_scraper_run(
            run_id, status='failed',
            processed=1, failed=1,
            finished_at=datetime.utcnow(),
            current_step=f'error: {e}'[:200],
            error=[{'url': scraper['url'], 'error': str(e)[:300],
                    'when': datetime.utcnow().isoformat() + 'Z'}],
        )
        update_scraper(scraper_id,
                       last_run_at=datetime.utcnow(),
                       last_run_status='failed')
        raise
