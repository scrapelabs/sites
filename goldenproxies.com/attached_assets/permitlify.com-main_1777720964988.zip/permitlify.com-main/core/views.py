from django.shortcuts import render, redirect
from django.http import Http404, JsonResponse, HttpResponse, HttpResponseForbidden, HttpResponseBadRequest
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import os
import json
import csv
import logging
import re
import secrets
import urllib.parse
import psycopg
from datetime import date, datetime
from .db import (authenticate_user, create_user, seed_initial_data,
                  get_user_by_google_sub, link_google_to_user, create_user_from_google,
                  get_system_setting, set_system_setting,
                  get_all_users, get_users_by_ids, delete_user, bulk_delete_users, get_user_by_id, update_user, hash_password,
                  get_user_by_api_key,
                  ban_email, unban_email, is_email_banned, get_all_banned,
                  get_user_by_email, set_reset_token, get_user_by_reset_token, clear_reset_token,
                  increment_user_field,
                  total_user_count, count_users_by_plan,
                  count_users_joined_in_month, aggregate_user_cities,
                  create_session, delete_session_by_id, delete_sessions_for_user,
                  get_sessions_for_user, touch_session,
                  record_login_event, get_login_history_for_user, clear_login_history_for_user,
                  set_totp_secret, enable_totp, disable_totp,
                  get_supported_cities, add_supported_city, remove_supported_city,
                  bulk_remove_supported_cities,
                  create_ticket, get_ticket, get_tickets_for_user, get_all_tickets,
                  get_ticket_status_counts,
                  add_ticket_message, update_ticket_status, update_ticket_priority,
                  delete_ticket,
                  get_notifications_for_user, get_all_notifications_for_user,
                  count_notifications_for_user, mark_notification_opened,
                  get_notification_stats, get_notif_prefs, save_notif_prefs,
                  get_user_invoices, upsert_invoice, get_invoice_by_id,
                  get_notif_channels, save_notif_channel, seed_demo_notifications,
                  bulk_upsert_permits,
                  query_permits_view, query_permits_for_dashboard, get_permit_by_number,
                  get_recent_permits_for_cities, ensure_demo_permits_seeded,
                  create_notification,
                  list_blog_posts, get_blog_post, get_featured_blog_post, get_related_blog_posts,
                  upsert_blog_post, delete_blog_post, slug_exists,
                  get_crm_integrations, set_crm_oauth_tokens,
                  update_crm_provider_field, save_zapier_webhook,
                  disconnect_crm_provider, CRM_PROVIDERS,
                  ensure_referral_code, get_user_by_referral_code,
                  bind_referrer_for_user, credit_referral_first_payment,
                  get_referral_stats_for_user, get_referees_for_user,
                  get_all_referrers_with_stats, get_total_affiliate_stats)
from .decorators import login_required, subscription_required, admin_required, ADMIN_EMAILS as _DEC_ADMIN_EMAILS
from .cache import cached_admin_html
from .blog_articles import BLOG_ARTICLES
from . import whop as wp
from . import integrations as _integrations

# Module-level logger. Previously this was bound only inside one admin
# function, which meant every other ``log.warning(...)`` / ``log.exception(...)``
# callsite in this file (login transport-failure paths, Whop sync error
# fallbacks, password-reset session-revoke errors, ...) would raise
# ``NameError`` at runtime in cold-path branches, masking the real failure
# with a 500.
log = logging.getLogger(__name__)

DEMO_API_KEY = 'pl_test_k7x2m9n4p8q1r5s3v6w0'

PLAN_PRICE       = {'starter': 29,  'pro': 99,  'agency': 249}
# Maps 2-letter state abbreviation → full name (for city-add modal)
_FULL_STATE_NAMES = {
    'AL':'Alabama','AK':'Alaska','AZ':'Arizona','AR':'Arkansas','CA':'California',
    'CO':'Colorado','CT':'Connecticut','DE':'Delaware','FL':'Florida','GA':'Georgia',
    'HI':'Hawaii','ID':'Idaho','IL':'Illinois','IN':'Indiana','IA':'Iowa',
    'KS':'Kansas','KY':'Kentucky','LA':'Louisiana','ME':'Maine','MD':'Maryland',
    'MA':'Massachusetts','MI':'Michigan','MN':'Minnesota','MS':'Mississippi',
    'MO':'Missouri','MT':'Montana','NE':'Nebraska','NV':'Nevada','NH':'New Hampshire',
    'NJ':'New Jersey','NM':'New Mexico','NY':'New York','NC':'North Carolina',
    'ND':'North Dakota','OH':'Ohio','OK':'Oklahoma','OR':'Oregon','PA':'Pennsylvania',
    'RI':'Rhode Island','SC':'South Carolina','SD':'South Dakota','TN':'Tennessee',
    'TX':'Texas','UT':'Utah','VT':'Vermont','VA':'Virginia','WA':'Washington',
    'WV':'West Virginia','WI':'Wisconsin','WY':'Wyoming',
}

PLAN_CITY_LIMITS = {'Starter':  1,  'Pro':  5,  'Agency':  15,
                    'starter':  1,  'pro':  5,  'agency':  15}

PLAN_USAGE_LIMITS = {
    'Starter': {'cities': 1,  'alerts': 30,   'api': 0,     'history_days': 7},
    'Pro':     {'cities': 5,  'alerts': 300,  'api': 0,     'history_days': 90},
    'Agency':  {'cities': 15, 'alerts': None, 'api': None,  'history_days': None},  # None = unlimited
}

PLAN_FEATURES = {
    'Starter': {'csv_export': False, 'trade_filter': False, 'full_score': False},
    'Pro':     {'csv_export': True,  'trade_filter': True,  'full_score': True},
    'Agency':  {'csv_export': True,  'trade_filter': True,  'full_score': True},
}

def _usage_pct(used, limit):
    if limit is None: return min(40, max(5, used // 50))
    if limit == 0:    return 0
    return min(100, round(used * 100 / limit))


# ── Billing / Invoice sync helper ──────────────────────────────────────────

# Lower number = lower tier. Used by the downgrade-protection logic in
# _whop_login_sync so a stale per-id Whop lookup can never silently bump
# an Agency/Pro user back down to Starter.
_PLAN_RANK = {'starter': 0, 'pro': 1, 'agency': 2}


def _is_plan_downgrade(detected: str, current: str) -> bool:
    """True iff `detected` is strictly a lower tier than `current`."""
    d = (detected or '').lower()
    c = (current or '').lower()
    if d not in _PLAN_RANK or c not in _PLAN_RANK:
        return False
    return _PLAN_RANK[d] < _PLAN_RANK[c]


def _find_active_membership_for_plan(email: str, plan_hint: str = '',
                                     timeout: int = 15):
    """Single-pass email lookup. If `plan_hint` is given, returns the
    first active membership whose detected plan matches; otherwise the
    highest-tier active membership Whop returns. Falls back to
    `(None, '')` when there are no active memberships at all.

    Pass a tight ``timeout`` (e.g. 3) when calling on the user hot path
    so a slow Whop response cannot wedge the request.
    """
    try:
        mems = wp.get_memberships_by_email(email, timeout=timeout)
    except Exception:
        return None, ''
    active = [m for m in mems if m.get('valid')]
    if not active:
        return None, ''
    if plan_hint in ('starter', 'pro', 'agency'):
        for m in active:
            d = wp.plan_from_membership(m, default='')
            if d == plan_hint:
                return m, d
    # No hint or no exact match — return the HIGHEST-TIER active
    # membership rather than just the newest. During an upgrade
    # transition (Pro → Agency) both are valid for a few minutes, and
    # the user's "real" plan is the higher one.
    best_m, best_plan, best_rank = None, '', -1
    for m in active:
        d = wp.plan_from_membership(m, default='')
        r = _PLAN_RANK.get(d, -1)
        if r > best_rank:
            best_m, best_plan, best_rank = m, d, r
    if best_m is not None:
        return best_m, best_plan
    # All active memberships had undetectable plans — return newest.
    m = active[0]
    return m, wp.plan_from_membership(m, default='')


def _wait_for_paid_membership(email: str, plan_hint: str,
                              max_attempts: int = 4):
    """After a successful checkout, retry Whop's email lookup until a
    membership matching `plan_hint` shows up.

    Whop's email-filter API is eventually consistent — a brand-new
    membership often takes 1-5s to appear. If we don't wait, the
    "newest active" membership returned can still be the user's OLD
    (about-to-cancel) one, which is exactly how we used to bind the
    wrong ``whop_membership_id`` and then auto-downgrade the user on
    their next login.

    Backoff: 0s, 1s, 2s, 4s — total worst-case wait ~7s. Returns the
    matching membership dict, or ``None`` if no exact-tier match
    surfaced. Callers MUST NOT bind whop_membership_id when this
    returns None; they should keep the plan hint, mark the account as
    pending-resync, and let the webhook (or the next login_sync) bind
    the right membership when Whop catches up.
    """
    import time
    if not email:
        return None
    for attempt in range(max_attempts):
        if attempt > 0:
            time.sleep(2 ** (attempt - 1))  # 1s, 2s, 4s
        # 5s per Whop call is generous for the success page; user is
        # already waiting on the post-payment redirect.
        m, detected = _find_active_membership_for_plan(
            email, plan_hint=plan_hint, timeout=5,
        )
        if m and detected == plan_hint:
            return m
    return None


def _whop_login_sync(user_id: int, user: dict) -> dict:
    """No-op as of the bind-from-redirect change.

    We no longer hit the Whop API on every login. Plan / membership
    state is bound exactly once at checkout time — `ls_success` reads
    the `?membership_id=` query param that Whop fills into the
    redirect URL via the `{membership_id}` placeholder, and that ID is
    deterministic (it can never race with a stale older membership).

    State is kept current after that by:
      * the Whop webhook (`ls_webhook`) for cancel / expire / payment
        events — incoming, not outgoing, so it does not rely on us
        polling Whop;
      * `admin_whop_resync_user` and `admin_bulk_whop_sync` for the
        admin's manual fix-it-up tools.

    Returns the cached state so callers that read the dict (the login
    handlers populate the session from these values) keep working
    unchanged.
    """
    return {
        'plan':      (user.get('plan') or 'starter'),
        'cancelled': bool(user.get('whop_cancelled')),
        'updated':   False,
    }


def _snapshot_whop_to_user(user_id: int, membership: dict) -> None:
    """Cache the Whop membership snapshot into the user JSONB doc so the
    settings page can render billing info from DB only — no live API call.

    Writes: whop_status, whop_renews_at, whop_paused, whop_cancelled,
    last_whop_sync_at. Idempotent. Safe to call from ls_success, ls_sync,
    and webhook handlers. Never raises — Whop hiccups must not break the
    caller's flow — but DOES log so we can debug stale-snapshot bugs."""
    try:
        ui = wp.format_membership_for_ui(membership)
        if not ui:
            return
        from datetime import datetime, timezone
        update_user(user_id,
            whop_status     = ui.get('status', ''),
            whop_renews_at  = ui.get('renews_at', ''),
            whop_paused     = bool(ui.get('paused')),
            whop_cancelled  = bool(ui.get('cancelled')),
            last_whop_sync_at = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        )
    except Exception:
        import logging
        logging.getLogger(__name__).exception(
            "_snapshot_whop_to_user failed for user %s membership %s",
            user_id, (membership or {}).get('id', '?'),
        )


def _build_whop_info_from_user(user: dict) -> dict:
    """Reconstruct the dict shape that ``format_membership_for_ui`` returns,
    using cached fields on the user record. Lets us render the settings
    billing card without a live Whop API call."""
    if not user.get('whop_membership_id'):
        return {}
    return {
        'id':         user.get('whop_membership_id', ''),
        'plan':       (user.get('plan') or '').title(),
        'status':     user.get('whop_status', 'active') or 'active',
        'renews_at':  user.get('whop_renews_at', '') or '',
        'portal_url': 'https://whop.com/hub/',
        'update_url': 'https://whop.com/hub/',
        'cancelled':  bool(user.get('whop_cancelled')),
        'paused':     bool(user.get('whop_paused')),
        'trial_ends': '',
        'annual':     False,
        'card_brand': '',
        'card_last4': '',
    }


def _sync_billing_and_invoice(user_id: int, membership: dict) -> None:
    """
    Save billing period dates to user record and upsert an invoice for the
    current billing period. Called after any successful Whop membership sync.
    """
    import hashlib
    from datetime import datetime, timezone

    dates = wp.get_billing_dates(membership)
    if not dates.get('period_start_ts'):
        return

    update_user(user_id,
                subscription_start=dates['subscription_start'],
                billing_period_start=dates['period_start'],
                billing_period_end=dates['period_end'])

    period_start_ts = dates['period_start_ts']
    period_end_ts   = dates['period_end_ts']
    if not period_end_ts:
        return

    plan = wp.plan_from_membership(membership)

    # Determine if monthly or annual based on period length (>60 days = annual)
    period_days = (period_end_ts - period_start_ts) // 86400
    is_annual   = period_days > 60
    period_key  = 'annual' if is_annual else 'monthly'

    # Mode-aware: pull the displayed price for the *user's* active mode
    # (prod or dev), not the global mode — otherwise a PROD user's invoice
    # row shows $1 because the site happens to be running in dev globally
    # (or vice-versa for a DEV-flagged tester).
    _u_for_mode = get_user_by_id(user_id) or {}
    user_mode = wp.mode_for_user(_u_for_mode)
    monthly_equiv = wp.get_plan_price(plan, period_key, user_mode)
    # For annual subs the user is charged 12× the monthly-equivalent price up front.
    amount_dollars = monthly_equiv * 12 if is_annual else monthly_equiv
    amount_cents   = amount_dollars * 100
    amount_str     = f'${amount_dollars}.00'

    def fmt_ts(ts):
        try:
            return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime('%b %d, %Y')
        except Exception:
            return ''

    # Stable invoice ID: user + billing period start timestamp
    inv_key = f"{user_id}_{period_start_ts}"
    inv_id  = 'INV-' + hashlib.md5(inv_key.encode()).hexdigest()[:8].upper()

    upsert_invoice({
        'invoice_id':          inv_id,
        'user_id':             int(user_id),
        'number':              inv_id,
        'plan':                plan,
        'plan_label':          plan.title() + (' Annual' if is_annual else ' Monthly'),
        'date':                fmt_ts(period_start_ts),
        'period':              f"{fmt_ts(period_start_ts)} – {fmt_ts(period_end_ts)}",
        'period_start':        dates['period_start'],
        'period_end':          dates['period_end'],
        'period_start_ts':     period_start_ts,
        'period_end_ts':       period_end_ts,
        'amount':              amount_str,
        'amount_cents':        amount_cents,
        'status':              'paid',
        'payment':             'Whop',
        'billing_reason':      'Annual' if is_annual else 'Monthly',
        'url':                 membership.get('manage_url', ''),
        'whop_membership_id':  membership.get('id', ''),
    })

def _fmt_num(n):
    if n is None: return '∞'
    if n >= 1_000_000: return f'{n/1_000_000:.1f}'.rstrip('0').rstrip('.') + 'M'
    if n >= 1000:      return f'{n/1000:.1f}'.rstrip('0').rstrip('.') + 'k'
    return f'{n:,}'

ADMIN_EMAILS = _DEC_ADMIN_EMAILS  # single source of truth lives in decorators.py


def _parse_device(ua: str) -> str:
    u = ua.lower()
    if 'iphone' in u:  return 'Safari on iPhone'
    if 'ipad'   in u:  return 'Safari on iPad'
    if 'android' in u and 'mobile' in u: return 'Chrome on Android'
    if 'android' in u: return 'Chrome on Android Tablet'
    if 'mac' in u and 'chrome' in u:  return 'Chrome on macOS'
    if 'mac' in u and 'firefox' in u: return 'Firefox on macOS'
    if 'mac' in u and 'safari' in u:  return 'Safari on macOS'
    if 'windows' in u and 'edg' in u:    return 'Edge on Windows'
    if 'windows' in u and 'chrome' in u: return 'Chrome on Windows'
    if 'windows' in u and 'firefox' in u: return 'Firefox on Windows'
    if 'windows' in u: return 'Browser on Windows'
    if 'linux' in u:   return 'Browser on Linux'
    return 'Unknown Device'


# ── Lifecycle email dispatch helpers ──────────────────────────────────
#
# Thin wrappers around `core.email_notifications` that resolve absolute
# URLs from the live ``request`` object before spawning the worker
# thread (the worker has no request context). Every helper is wrapped
# in try/except so an email problem can never block a redirect or a
# checkout.
#
# All three helpers are *fire-and-forget*. They never raise. The email
# send itself runs in a daemon thread inside `email_notifications`.

def _abs_base(request) -> str:
    """Absolute origin of the current request (no trailing slash)."""
    try:
        b = request.build_absolute_uri('/')
        return b[:-1] if b.endswith('/') else b
    except Exception:
        return 'https://permitlify.com'


def _send_login_alert_if_new_device(*, user, request, method_label: str,
                                    device: str, ip: str, ua: str) -> None:
    """Fire a "new sign-in detected" email iff this (device, ip) pair
    has never been seen on this user's account before. Must be called
    BEFORE ``record_login_event`` so the current login isn't already
    in ``login_history`` when we run the check (otherwise it would
    always look "seen" and we'd never alert)."""
    try:
        from .db import is_new_device_for_user
        uid = int(user.get('id') or 0)
        if uid <= 0:
            return
        if not is_new_device_for_user(uid, device, ip):
            return
        from .email_notifications import send_login_alert_email_async
        send_login_alert_email_async(
            user         = user,
            method_label = method_label,
            device       = device,
            ip           = ip,
            ua           = ua,
            security_url = _abs_base(request) + '/settings/security/',
        )
    except Exception:
        log.exception("login-alert dispatch failed for user_id=%s", user.get('id'))


def _fire_welcome_email(user, request) -> None:
    """Fire the post-signup welcome email. Best-effort, never raises."""
    try:
        from .email_notifications import send_welcome_email_async
        base = _abs_base(request)
        send_welcome_email_async(
            user          = user,
            dashboard_url = base + '/dashboard/',
            pricing_url   = base + '/pricing/',
            support_url   = base + '/support/',
        )
    except Exception:
        log.exception("welcome dispatch failed for user_id=%s", user.get('id'))


def _fire_payment_success_email(user, plan, mem, request) -> None:
    """Fire the payment-success / activation receipt email after a
    successful Whop membership bind. Best-effort, never raises.

    ``mem`` is the raw Whop membership dict from the redirect-time bind
    (``ls_success``) — used only to derive the next-charge timestamp
    and the membership reference shown on the receipt."""
    try:
        from datetime import timezone as _tz
        from .email_notifications import send_payment_success_email_async
        next_charge_pretty = ''
        if mem:
            ts_raw = (mem.get('renewal_period_end')
                      or mem.get('expires_at')
                      or mem.get('current_period_end')
                      or 0)
            try:
                ts_int = int(ts_raw)
                if ts_int > 0:
                    next_charge_pretty = datetime.fromtimestamp(
                        ts_int, tz=_tz.utc
                    ).strftime('%b %d, %Y').replace(' 0', ' ')
            except Exception:
                pass
        send_payment_success_email_async(
            user               = user,
            plan               = plan or 'starter',
            membership_id      = (mem or {}).get('id', '') if mem else '',
            next_charge_pretty = next_charge_pretty,
            billing_url        = _abs_base(request) + '/billing/portal/',
        )
    except Exception:
        log.exception("payment-success dispatch failed for user_id=%s", user.get('id'))


def _maybe_fire_payment_success_email(user_id, mem_id, plan, mem_data, request) -> bool:
    """Fire the payment-success receipt at most once per
    (user, membership_id, plan) tuple. Returns True iff an email was
    dispatched.

    The same successful checkout can fire from two race-y paths:

      * ``ls_success`` — synchronous post-checkout redirect, runs the
        moment Whop bounces the user back with ``?membership_id=…``.
      * ``ls_webhook`` (``action == 'membership.went_valid'``) — async
        POST from Whop. Can land before, after, or *instead of* the
        redirect when the user closes the browser tab, the redirect
        verification fails, the upgrade happens off-platform from the
        Whop dashboard, or a plan switch is initiated from the billing
        portal.

    Whichever path wins the race fires the receipt and stamps the
    user JSONB with ``payment_email_last_membership`` /
    ``payment_email_last_plan``. The other path sees the matching
    stamps and silently no-ops.

    We stamp on (mem_id, plan) — not just mem_id — so a real plan
    change (e.g. Pro → Agency on the same membership_id) still
    triggers a fresh "Payment received" receipt, while a routine
    Whop renewal (same mem + same plan, sent as another went_valid
    every billing cycle) does not spam the user.

    Best-effort: any exception is logged and swallowed; never raises
    so a Whop webhook (which retries on non-2xx) can't loop on a
    template hiccup.
    """
    if not user_id:
        return False
    try:
        user = get_user_by_id(user_id) or {}
        new_plan = (plan or '').strip().lower()
        new_mem  = (mem_id or '').strip()
        last_mem  = (user.get('payment_email_last_membership') or '').strip()
        last_plan = (user.get('payment_email_last_plan')       or '').strip().lower()

        # Same (mem_id, plan) we already emailed about → duplicate (race
        # winner already sent) or routine renewal (Whop fires went_valid
        # every billing cycle) — skip. Empty new_mem means we couldn't
        # identify the membership at all; in that edge case fall through
        # and send (better one extra email than miss the activation).
        if new_mem and last_mem == new_mem and last_plan == new_plan:
            return False

        _fire_payment_success_email(user, new_plan, mem_data, request)

        try:
            update_user(
                user_id,
                payment_email_last_membership=new_mem,
                payment_email_last_plan=new_plan,
            )
        except Exception:
            log.exception(
                "could not stamp payment-email dedup keys for user_id=%s",
                user_id,
            )
        return True
    except Exception:
        log.exception(
            "maybe-payment-success dispatch failed for user_id=%s", user_id,
        )
        return False


def _time_ago(iso_str: str) -> str:
    try:
        delta = datetime.now() - datetime.fromisoformat(iso_str)
        s = delta.total_seconds()
        if s < 60:       return 'Just now'
        if s < 3600:     return f'{int(s//60)}m ago'
        if s < 86400:    return f'{int(s//3600)}h ago'
        if s < 172800:   return 'Yesterday'
        return f'{int(s//86400)}d ago'
    except Exception:
        return ''

# ── Scraper / script definitions ────────────────────────────────
# days_history: leads per day for the last 7 days (newest first)
SAMPLE_SCRAPERS = [
    {'id':  1, 'name': 'Fort Worth Permits',     'city': 'Fort Worth, TX',   'url': 'https://permits.fortworthtexas.gov',            'last_run': '2026-04-19 06:01', 'days_history': [13,11, 8,14,12,10, 9]},
    {'id':  2, 'name': 'Arlington Dev Portal',   'city': 'Arlington, TX',    'url': 'https://aca.arlington-tx.gov',                  'last_run': '2026-04-19 06:04', 'days_history': [ 8, 9, 7, 6,11, 8,10]},
    {'id':  3, 'name': 'Dallas DAPS Scraper',    'city': 'Dallas, TX',       'url': 'https://dallaspermits.dallascityhall.com',      'last_run': '2026-04-19 06:07', 'days_history': [31,28,24,33,29,27,25]},
    {'id':  4, 'name': 'Austin Dev Services',    'city': 'Austin, TX',       'url': 'https://abc.austintexas.gov',                   'last_run': '2026-04-19 06:09', 'days_history': [22,19,17,21,18,20,16]},
    {'id':  5, 'name': 'San Antonio CSS',        'city': 'San Antonio, TX',  'url': 'https://saepermits.sanantonio.gov',             'last_run': '2026-04-19 06:12', 'days_history': [18,16,14,17,15,13,19]},
    {'id':  6, 'name': 'Houston e-Permits',      'city': 'Houston, TX',      'url': 'https://permits.houstontx.gov',                 'last_run': '2026-04-19 06:14', 'days_history': [ 0, 0, 0, 0,22,19,21]},  # 4 days broken — DANGER
    {'id':  7, 'name': 'Plano ICA Portal',       'city': 'Plano, TX',        'url': 'https://permits.plano.gov',                    'last_run': '2026-04-19 06:17', 'days_history': [ 5, 6, 0, 0, 0, 7, 8]},  # 1 day no leads — warning
    {'id':  8, 'name': 'Irving Permit Scraper',  'city': 'Irving, TX',       'url': 'https://www.cityofirving.org/permits',          'last_run': '2026-04-18 06:01', 'days_history': [ 0, 0, 0, 9, 8, 6, 7]},  # 3 days broken — DANGER
    {'id':  9, 'name': 'Denton Permits',         'city': 'Denton, TX',       'url': 'https://permits.cityofdenton.com',              'last_run': '2026-04-19 06:21', 'days_history': [ 4, 5, 3, 4, 6, 5, 4]},
    {'id': 10, 'name': 'Garland Permits RSS',    'city': 'Garland, TX',      'url': 'https://permits.garlandtx.gov',                 'last_run': '2026-04-19 06:23', 'days_history': [ 0, 0, 8, 9, 7, 8, 9]},  # 2 days — warning
    {'id': 11, 'name': 'Frisco Dev Portal',      'city': 'Frisco, TX',       'url': 'https://permits.friscotexas.gov',               'last_run': '2026-04-19 06:25', 'days_history': [ 7, 8, 6, 9, 7, 8, 6]},
    {'id': 12, 'name': 'McKinney Permits API',   'city': 'McKinney, TX',     'url': 'https://permits.mckinneytexas.org',             'last_run': '2026-04-19 06:27', 'days_history': [ 6, 5, 7, 6, 8, 5, 7]},
    {'id': 13, 'name': 'Lubbock City Scraper',   'city': 'Lubbock, TX',      'url': 'https://permits.mylubbock.us',                  'last_run': '2026-04-18 06:01', 'days_history': [ 0, 0, 0, 0, 0, 5, 6]},  # 5 days — DANGER
    {'id': 14, 'name': 'El Paso Permits',        'city': 'El Paso, TX',      'url': 'https://permits.elpasotexas.gov',               'last_run': '2026-04-19 06:31', 'days_history': [ 9, 8,10, 7, 9, 8,10]},
    {'id': 15, 'name': 'Corpus Christi CDP',     'city': 'Corpus Christi, TX','url': 'https://permits.cctexas.com',                  'last_run': '2026-04-19 06:33', 'days_history': [ 5, 6, 4, 5, 6, 5, 4]},
]

def _enrich_scrapers(scrapers):
    result = []
    for s in scrapers:
        h = s['days_history']
        consecutive_zero = 0
        for v in h:
            if v == 0:
                consecutive_zero += 1
            else:
                break
        if consecutive_zero >= 3:
            status = 'danger'
        elif consecutive_zero >= 1:
            status = 'warning'
        else:
            status = 'ok'
        avg_7d = round(sum(h) / len(h), 1) if h else 0
        total_7d = sum(h)
        result.append({
            **s,
            'leads_today':     h[0] if h else 0,
            'leads_yesterday': h[1] if len(h) > 1 else 0,
            'avg_7d':          avg_7d,
            'total_7d':        total_7d,
            'days_no_leads':   consecutive_zero,
            'status':          status,
        })
    # Sort: danger first, then warning, then ok; within each group by days_no_leads desc
    order = {'danger': 0, 'warning': 1, 'ok': 2}
    result.sort(key=lambda x: (order[x['status']], -x['days_no_leads']))
    return result

seed_initial_data()
# Seed the 30 sample permits into the production `permits` table on
# first deploy after this migration. Subsequent process starts hit a
# single indexed `EXISTS` query → fast no-op.
ensure_demo_permits_seeded()

SAMPLE_PERMITS = [
    {'score': 92, 'tier': 'hot', 'address': '4821 Ridgemont Dr', 'number': 'FW-2026-04192', 'trade': 'Roofing',    'value': '$18,500', 'city': 'Fort Worth',   'filed': 'Today, 8:14 AM'},
    {'score': 87, 'tier': 'hot', 'address': '211 Lakeside Blvd', 'number': 'AR-2026-04112', 'trade': 'HVAC',       'value': '$9,200',  'city': 'Arlington',    'filed': 'Today, 7:52 AM'},
    {'score': 74, 'tier': 'warm','address': '6690 Westpark Ave', 'number': 'AU-2026-04048', 'trade': 'Electrical', 'value': '$6,750',  'city': 'Austin',       'filed': 'Today, 7:30 AM'},
    {'score': 68, 'tier': 'warm','address': '338 Maple Creek Rd','number': 'DA-2026-04033', 'trade': 'Plumbing',   'value': '$4,100',  'city': 'Dallas',       'filed': 'Today, 6:45 AM'},
    {'score': 55, 'tier': 'cool','address': '990 Sunflower Dr',  'number': 'SA-2026-03981', 'trade': 'Roofing',    'value': '$12,000', 'city': 'San Antonio',  'filed': 'Yesterday, 4:10 PM'},
    {'score': 61, 'tier': 'cool','address': '115 Birchwood Ct',  'number': 'FW-2026-04188', 'trade': 'Electrical', 'value': '$3,800',  'city': 'Fort Worth',   'filed': 'Yesterday, 2:30 PM'},
    {'score': 79, 'tier': 'warm','address': '730 Canyon Ridge',  'number': 'AR-2026-04099', 'trade': 'Roofing',    'value': '$21,000', 'city': 'Arlington',    'filed': 'Yesterday, 1:15 PM'},
]

# Full permit datasets used by the dashboard and permits history pages.
# The view filters these to the user's subscribed cities before sending to the template.
DASHBOARD_PERMITS = [
    {"id":"PW26-12701","type":"Residential Roofing","desc":"Full shingle replacement","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(817) 542-9900","email":"mike@texasroof.com","project":"3421 Magnolia Ave","owner":"Sarah T. Monroe","score":96,"grade":"A+","trade":"roofing","city":"Fort Worth","state":"TX"},
    {"id":"PW26-12702","type":"HVAC Replacement","desc":"4-ton split system install","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(817) 290-4411","email":"james@cooltech.com","project":"907 Westbrook Dr","owner":"David Okonkwo","score":82,"grade":"A-","trade":"hvac","city":"Fort Worth","state":"TX"},
    {"id":"PW26-12703","type":"Solar Installation","desc":"20-panel grid-tie system","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(817) 880-0012","email":"solar@sunnytx.com","project":"2002 Wedgwood Dr","owner":"Amanda Foster","score":95,"grade":"A+","trade":"solar","city":"Fort Worth","state":"TX"},
    {"id":"PW26-12704","type":"Plumbing Repair","desc":"Water main replacement","status":"pending","issuedIso":"2026-04-20","expiresIso":"2026-07-19","phone":"(817) 445-7730","email":"dan@dplumbing.net","project":"2218 Oak Hill Ln","owner":"Greg Fischer","score":74,"grade":"B+","trade":"plumbing","city":"Fort Worth","state":"TX"},
    {"id":"PW26-12705","type":"Commercial Electric","desc":"Panel upgrade 400A","status":"review","issuedIso":"2026-04-20","expiresIso":"2026-08-19","phone":"(214) 980-3355","email":"info@voltmaster.com","project":"5560 Commerce St","owner":"Vault Storage LLC","score":67,"grade":"B","trade":"electrical","city":"Fort Worth","state":"TX"},
    {"id":"AR26-09301","type":"Residential Roofing","desc":"Hail damage full replacement","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(817) 329-4422","email":"roof@arlingtontx.net","project":"5519 Pioneer Pkwy","owner":"Maria Delgado","score":89,"grade":"A","trade":"roofing","city":"Arlington","state":"TX"},
    {"id":"AR26-09302","type":"HVAC Replacement","desc":"Variable speed heat pump","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(817) 554-2233","email":"hvac@coolaire.com","project":"2210 Lamar Blvd","owner":"Robert Nwachukwu","score":77,"grade":"B+","trade":"hvac","city":"Arlington","state":"TX"},
    {"id":"AR26-09303","type":"Solar Installation","desc":"14-panel carport array","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(817) 665-4422","email":"solar@arlingtonsun.com","project":"6603 Matlock Rd","owner":"Priya Shah","score":88,"grade":"A","trade":"solar","city":"Arlington","state":"TX"},
    {"id":"DA26-33501","type":"Residential Roofing","desc":"Storm damage repair","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(214) 333-8877","email":"claims@stormfix.com","project":"4812 Mockingbird Ln","owner":"Linda Osei","score":92,"grade":"A","trade":"roofing","city":"Dallas","state":"TX"},
    {"id":"DA26-33502","type":"Commercial HVAC","desc":"Rooftop unit replacement","status":"review","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(214) 555-0110","email":"maint@dallashq.com","project":"7400 Greenville Ave","owner":"Greenville Office Park","score":86,"grade":"A","trade":"hvac","city":"Dallas","state":"TX"},
    {"id":"DA26-33503","type":"New Commercial Build","desc":"5,000 sqft retail shell","status":"pending","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(214) 778-9900","email":"proj@dallasbuild.com","project":"11200 Inwood Rd","owner":"Nexgen Properties","score":58,"grade":"C+","trade":"civil","city":"Dallas","state":"TX"},
    {"id":"AU26-55901","type":"Residential Roofing","desc":"Tile roof full replacement","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(512) 444-2211","email":"roof@atxroof.com","project":"2910 Enfield Rd","owner":"Patricia Kwon","score":94,"grade":"A","trade":"roofing","city":"Austin","state":"TX"},
    {"id":"AU26-55902","type":"Solar Installation","desc":"Tesla Powerwall + 18 panels","status":"approved","issuedIso":"2026-04-20","expiresIso":"2026-10-19","phone":"(512) 600-1234","email":"solar@greentx.io","project":"811 W 6th St","owner":"Natasha Patel","score":90,"grade":"A","trade":"solar","city":"Austin","state":"TX"},
    {"id":"AU26-55903","type":"Commercial Electric","desc":"EV charging station install","status":"pending","issuedIso":"2026-04-20","expiresIso":"2026-08-19","phone":"(512) 775-3310","email":"ev@chargeup.com","project":"900 S Congress Ave","owner":"Tesla Retail LLC","score":68,"grade":"B","trade":"electrical","city":"Austin","state":"TX"},
]

# (PERMIT_HISTORY removed — moved to Postgres `permits` table; see core/db.py)

SAMPLE_CITIES = [
    {'name': 'Fort Worth',    'state': 'TX', 'selected': True,  'count': 13},
    {'name': 'Arlington',     'state': 'TX', 'selected': True,  'count': 8},
    {'name': 'Austin',        'state': 'TX', 'selected': False, 'count': 22},
    {'name': 'Dallas',        'state': 'TX', 'selected': False, 'count': 31},
    {'name': 'San Antonio',   'state': 'TX', 'selected': False, 'count': 18},
    {'name': 'Houston',       'state': 'TX', 'selected': False, 'count': 22},
    {'name': 'Plano',         'state': 'TX', 'selected': False, 'count': 5},
    {'name': 'Irving',        'state': 'TX', 'selected': False, 'count': 0},
    {'name': 'Denton',        'state': 'TX', 'selected': False, 'count': 4},
    {'name': 'Garland',       'state': 'TX', 'selected': False, 'count': 0},
    {'name': 'Frisco',        'state': 'TX', 'selected': False, 'count': 7},
    {'name': 'McKinney',      'state': 'TX', 'selected': False, 'count': 6},
    {'name': 'Lubbock',       'state': 'TX', 'selected': False, 'count': 0},
    {'name': 'El Paso',       'state': 'TX', 'selected': False, 'count': 9},
    {'name': 'Corpus Christi','state': 'TX', 'selected': False, 'count': 5},
]

# ── Supported cities (must have an active scraper) ─────────────────────────
# Only these cities can be added by users. Any city not in this list is
# rejected by the city-add endpoint.
def _city_state(name: str) -> str:
    """Look up state abbreviation for a city name from the DB-backed supported cities list."""
    mapping = {c['city'].lower(): c['state'] for c in get_supported_cities()}
    return mapping.get(name.lower().strip(), '')

# ── Public views ──────────────────────────────────────────────

def our_story(request):
    return render(request, 'core/our_story.html')

def how_it_works(request):
    return render(request, 'core/how_it_works.html')

def blog(request):
    """Public blog index with case-insensitive search and 10-per-page pagination.

    Query params:
        q     — substring matched against title / excerpt / content / tag
        page  — 1-indexed; out-of-range values clamp to the last page
    """
    q_raw = (request.GET.get('q') or '').strip()
    try:
        page = int(request.GET.get('page') or 1)
    except (TypeError, ValueError):
        page = 1

    PER_PAGE = 10
    articles, total, total_pages, page = list_blog_posts(
        query=q_raw, page=page, per_page=PER_PAGE,
    )

    # Featured card only renders on the first unfiltered page so search
    # results aren't mixed with a marketing banner.
    featured = None
    if not q_raw and page == 1:
        featured = get_featured_blog_post()
        # Hide the featured row from the grid below to avoid showing the
        # same article twice on page 1.
        if featured:
            articles = [a for a in articles if a['slug'] != featured['slug']]

    # Compact "Page 2 of 5" + prev/next + numeric link list. Surface a 5-page
    # window so the bar stays narrow on long blogs.
    window = []
    if total_pages > 1:
        start = max(1, page - 2)
        end   = min(total_pages, start + 4)
        start = max(1, end - 4)
        window = list(range(start, end + 1))

    ctx = {
        'articles':    articles,
        'featured':    featured,
        'q':           q_raw,
        'page':        page,
        'per_page':    PER_PAGE,
        'total':       total,
        'total_pages': total_pages,
        'has_prev':    page > 1,
        'has_next':    page < total_pages,
        'page_window': window,
    }
    return render(request, 'core/blog.html', ctx)


def blog_post(request, slug):
    article = get_blog_post(slug)
    if not article:
        raise Http404
    # Defensive: if the body was authored or rewritten as markdown (legacy
    # posts, AI responses that ignored the HTML-only rule), convert it to
    # HTML at render-time so the page never displays raw ``## headings`` or
    # ``**bold**`` literals. ``md_to_html`` is idempotent — already-HTML
    # bodies pass through unchanged.
    from .blog_ai import md_to_html
    article['content'] = md_to_html(article.get('content') or '')
    related_slugs = article.get('related') or []
    related_articles = get_related_blog_posts(related_slugs)
    return render(request, 'core/blog_post.html', {
        'article': article,
        'related_articles': related_articles,
    })

def careers(request):
    return render(request, 'core/careers.html')

def press(request):
    return render(request, 'core/press.html')

def contact(request):
    return render(request, 'core/contact.html')

def _get_session_user(request) -> dict:
    """Return the current logged-in user dict (with 'id' key) or empty dict."""
    user_id = request.session.get('user_id')
    if not user_id:
        return {}
    user = get_user_by_id(user_id) or {}
    if user and 'id' not in user:
        user['id'] = user_id
    return user

@login_required
def support(request):
    user    = _get_session_user(request)
    tickets = get_tickets_for_user(user['id'])
    # Enrich with human-readable dates
    for t in tickets:
        try:
            t['created_fmt'] = datetime.fromisoformat(t['created_at']).strftime('%b %d, %Y')
            t['updated_fmt'] = datetime.fromisoformat(t['updated_at']).strftime('%b %d, %Y')
        except Exception:
            t['created_fmt'] = t.get('created_at', '')[:10]
            t['updated_fmt'] = t.get('updated_at', '')[:10]
    open_count = sum(1 for t in tickets if t.get('status') in ('open', 'in_progress'))
    faq_items = [
        {'q': 'How long does it take to get a response?',
         'a': 'We typically respond within a few hours during business days. Urgent billing or account issues are usually resolved within 1–2 hours.'},
        {'q': 'How do I add or remove cities from my plan?',
         'a': 'Go to Settings → City Coverage. You can add cities up to your plan limit and remove them at any time. Changes take effect immediately.'},
        {'q': 'Can I change my subscription plan?',
         'a': 'Yes! Visit Settings → Billing to upgrade, downgrade, or cancel your plan. Downgrades are scheduled for the end of your billing cycle.'},
        {'q': 'What does the AI permit score mean?',
         'a': 'Each permit is scored 0–100 based on project size, homeowner contact availability, proximity to your coverage area, and historical conversion signals. Higher scores indicate stronger leads.'},
        {'q': 'Why am I not seeing permits for a city I added?',
         'a': 'Permit data is refreshed daily. If you just added a city, new permits will appear on the next data refresh. If the issue persists, please open a ticket.'},
    ]
    ctx = _user_ctx(request)
    ctx.update({'tickets': tickets, 'open_count': open_count, 'faq_items': faq_items})
    response = render(request, 'core/support.html', ctx)
    response['Cache-Control'] = 'no-store'
    return response


@login_required
def support_ticket_detail(request, ticket_id: int):
    user   = _get_session_user(request)
    ticket = get_ticket(ticket_id)
    if ticket is None or ticket['user_id'] != user['id']:
        raise Http404
    if request.method == 'POST':
        action = request.POST.get('action', 'message')
        if action == 'priority':
            p = request.POST.get('priority', 'normal')
            if p in ('urgent', 'normal', 'low'):
                update_ticket_priority(ticket_id, p)
            return redirect('support_ticket_detail', ticket_id=ticket_id)
        if action == 'status':
            new_status = request.POST.get('status', '')
            if new_status in ('resolved', 'closed'):
                fresh = get_ticket(ticket_id)
                if new_status == 'closed' and fresh and fresh.get('status') == 'resolved':
                    add_ticket_message(ticket_id, 'system', 'System',
                        '✓ This ticket was resolved and is now closed. Both parties confirmed the issue was resolved.')
                update_ticket_status(ticket_id, new_status)
            return redirect('support_ticket_detail', ticket_id=ticket_id)
        text = request.POST.get('message', '').strip()
        if text:
            add_ticket_message(ticket_id, 'user', user.get('name') or user['email'], text)
            # Re-read fresh status before deciding — avoids stale-snapshot bugs
            fresh = get_ticket(ticket_id)
            if fresh and fresh.get('status') in ('open', 'resolved', 'closed'):
                update_ticket_status(ticket_id, 'in_progress')
        return redirect('support_ticket_detail', ticket_id=ticket_id)
    # Refresh ticket after possible mutations
    ticket = get_ticket(ticket_id)
    try:
        ticket['created_fmt'] = datetime.fromisoformat(ticket['created_at']).strftime('%b %d, %Y at %I:%M %p')
    except Exception:
        ticket['created_fmt'] = ticket.get('created_at', '')[:10]
    ctx = _user_ctx(request)
    ctx['ticket'] = ticket
    response = render(request, 'core/support_ticket.html', ctx)
    response['Cache-Control'] = 'no-store'
    return response


@login_required
def support_new_ticket(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user    = _get_session_user(request)
    subject  = request.POST.get('subject', '').strip()
    message  = request.POST.get('message', '').strip()
    category = request.POST.get('category', 'general').strip()
    if not subject or not message:
        return JsonResponse({'ok': False, 'error': 'Subject and message are required'}, status=400)
    priority = request.POST.get('priority', 'normal')
    ticket = create_ticket(
        user_id    = user['id'],
        user_email = user['email'],
        user_name  = user.get('name') or user['email'],
        subject    = subject,
        message    = message,
        category   = category,
        priority   = priority,
    )
    return JsonResponse({'ok': True, 'ticket_id': ticket['id'], 'ticket_ref': ticket['ticket_id']})


# ── Support widget JSON API (used by floating chat bubble) ─────

def _fmt_ts(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso)
    except Exception:
        return ''
    now = datetime.now()
    delta = now - dt
    if delta.total_seconds() < 60:
        return 'just now'
    if delta.total_seconds() < 3600:
        m = int(delta.total_seconds() // 60)
        return f'{m}m ago'
    if delta.days < 1:
        h = int(delta.total_seconds() // 3600)
        return f'{h}h ago'
    if delta.days < 7:
        return f'{delta.days}d ago'
    return dt.strftime('%b %d')


def _ticket_summary(t: dict, read_marks: dict | None = None) -> dict:
    msgs = t.get('messages') or []
    last = msgs[-1] if msgs else None
    last_text = (last.get('text', '') if last else '')[:90]
    last_name = (last.get('name', '') if last else '')
    updated_at = t.get('updated_at', '')
    # A ticket counts as "read" when the user has marked it read at-or-after
    # the ticket's last update timestamp. ISO-8601 strings compare lexically.
    rm = read_marks or {}
    mark = rm.get(str(t['id']))
    is_read = bool(mark and updated_at and mark >= updated_at)
    return {
        'id':         t['id'],
        'ticket_id':  t.get('ticket_id', ''),
        'subject':    t.get('subject', ''),
        'status':     t.get('status', 'open'),
        'priority':   t.get('priority', 'normal'),
        'category':   t.get('category', 'general'),
        'msg_count':  len(msgs),
        'last_sender': last.get('sender', '') if last else '',
        'last_name':  last_name,
        'last_text':  last_text,
        'updated_at': updated_at,
        'updated_fmt': _fmt_ts(updated_at),
        'is_read':    is_read,
    }


def _get_user_read_marks(user: dict) -> dict:
    rm = user.get('support_read_marks') or {}
    return rm if isinstance(rm, dict) else {}


def _get_admin_read_marks(user: dict) -> dict:
    """Per-admin map of {ticket_id_str: ISO timestamp} tracking which user
    replies the admin has acknowledged. Stored under ``admin_read_marks``
    on the admin's own user document so it never collides with the
    customer-facing ``support_read_marks``."""
    rm = user.get('admin_read_marks') or {}
    return rm if isinstance(rm, dict) else {}


def _admin_ticket_summary(t: dict, read_marks: dict | None = None) -> dict:
    """Lightweight summary of a ticket for the admin notification bell.

    Mirrors :func:`_ticket_summary` but flips the unread semantics: a ticket
    is "unread for the admin" when the customer (sender='user') replied
    last AND the admin hasn't yet marked it acknowledged. Closed tickets
    can never be unread.
    """
    msgs = t.get('messages') or []
    last = msgs[-1] if msgs else None
    last_text = (last.get('text', '') if last else '')[:90]
    last_name = (last.get('name', '') if last else '')
    updated_at = t.get('updated_at', '')
    rm = read_marks or {}
    mark = rm.get(str(t['id']))
    is_read = bool(mark and updated_at and mark >= updated_at)
    return {
        'id':          t['id'],
        'ticket_id':   t.get('ticket_id', ''),
        'subject':     t.get('subject', ''),
        'status':      t.get('status', 'open'),
        'priority':    t.get('priority', 'normal'),
        'category':    t.get('category', 'general'),
        'msg_count':   len(msgs),
        'last_sender': last.get('sender', '') if last else '',
        'last_name':   last_name,
        'last_text':   last_text,
        'user_name':   t.get('user_name', ''),
        'user_email':  t.get('user_email', ''),
        'updated_at':  updated_at,
        'updated_fmt': _fmt_ts(updated_at),
        'is_read':     is_read,
    }


@login_required
@require_http_methods(['GET'])
def support_widget_tickets(request):
    user    = _get_session_user(request)
    tickets = get_tickets_for_user(user['id'])
    rm      = _get_user_read_marks(user)
    return JsonResponse({'ok': True, 'tickets': [_ticket_summary(t, rm) for t in tickets]})


@login_required
@require_http_methods(['POST'])
def support_widget_mark_read(request):
    """
    Mark one ticket (or all of the user's tickets) as read for the
    notification bell. Stores per-ticket ISO timestamps under
    `support_read_marks` on the user JSONB doc.
    POST params:
      - ticket_id: int (mark a single ticket read up to its current updated_at)
      - all: '1' (mark every ticket the user owns)
    """
    user = _get_session_user(request)
    rm   = dict(_get_user_read_marks(user))
    now_iso = datetime.utcnow().isoformat()

    mark_all = request.POST.get('all') in ('1', 'true', 'yes')
    if mark_all:
        tickets = get_tickets_for_user(user['id'])
        for t in tickets:
            rm[str(t['id'])] = t.get('updated_at') or now_iso
    else:
        try:
            tid = int(request.POST.get('ticket_id') or 0)
        except (TypeError, ValueError):
            tid = 0
        if not tid:
            return JsonResponse({'ok': False, 'error': 'ticket_id required'}, status=400)
        ticket = get_ticket(tid)
        if ticket is None or ticket['user_id'] != user['id']:
            return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
        rm[str(tid)] = ticket.get('updated_at') or now_iso

    update_user(user['id'], support_read_marks=rm)
    return JsonResponse({'ok': True})


@login_required
@require_http_methods(['GET'])
def support_widget_ticket(request, ticket_id: int):
    user   = _get_session_user(request)
    ticket = get_ticket(ticket_id)
    if ticket is None or ticket['user_id'] != user['id']:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
    msgs_out = []
    for m in ticket.get('messages') or []:
        msgs_out.append({
            'sender': m.get('sender', 'user'),
            'name':   m.get('name', ''),
            'text':   m.get('text', ''),
            'ts':     m.get('ts', ''),
            'ts_fmt': _fmt_ts(m.get('ts', '')),
        })
    return JsonResponse({'ok': True, 'ticket': {
        'id':        ticket['id'],
        'ticket_id': ticket.get('ticket_id', ''),
        'subject':   ticket.get('subject', ''),
        'status':    ticket.get('status', 'open'),
        'priority':  ticket.get('priority', 'normal'),
        'category':  ticket.get('category', 'general'),
        'created_at': ticket.get('created_at', ''),
        'messages':  msgs_out,
    }})


@login_required
@require_http_methods(['POST'])
def support_widget_reply(request, ticket_id: int):
    user   = _get_session_user(request)
    ticket = get_ticket(ticket_id)
    if ticket is None or ticket['user_id'] != user['id']:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
    text = (request.POST.get('message') or '').strip()
    if not text:
        return JsonResponse({'ok': False, 'error': 'Message is required'}, status=400)
    add_ticket_message(ticket_id, 'user', user.get('name') or user['email'], text)
    fresh = get_ticket(ticket_id)
    if fresh and fresh.get('status') in ('open', 'resolved', 'closed'):
        update_ticket_status(ticket_id, 'in_progress')
    return JsonResponse({'ok': True})


@login_required
@require_http_methods(['POST'])
def support_widget_delete(request, ticket_id: int):
    user   = _get_session_user(request)
    ticket = get_ticket(ticket_id)
    if ticket is None or ticket['user_id'] != user['id']:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
    delete_ticket(ticket_id)
    return JsonResponse({'ok': True})


# ── Admin support views ────────────────────────────────────────

@admin_required
def admin_support_view(request):
    status_filter = request.GET.get('status', '')
    tickets = get_all_tickets(status_filter=status_filter)
    admin_user = _get_session_user(request)
    rm = _get_admin_read_marks(admin_user)
    for t in tickets:
        try:
            t['created_fmt'] = datetime.fromisoformat(t['created_at']).strftime('%b %d, %Y')
            t['updated_fmt'] = datetime.fromisoformat(t['updated_at']).strftime('%b %d, %Y %H:%M')
        except Exception:
            t['created_fmt'] = t.get('created_at', '')[:10]
            t['updated_fmt'] = t.get('updated_at', '')[:10]
        msgs = t.get('messages') or []
        t['msg_count'] = len(msgs)
        t['last_msg']  = msgs[-1] if msgs else None
        # Per-row "needs your attention" flag for the admin queue: customer
        # replied last AND this admin hasn't acked it yet AND ticket is live.
        last_sender = (t['last_msg'] or {}).get('sender', '') if t['last_msg'] else ''
        mark = rm.get(str(t['id']))
        updated_at = t.get('updated_at', '')
        is_read = bool(mark and updated_at and mark >= updated_at)
        t['admin_unread'] = (
            last_sender == 'user'
            and t.get('status') in ('open', 'in_progress')
            and not is_read
        )
    # Single GROUP BY query instead of five sequential full-table scans.
    counts = get_ticket_status_counts()
    ctx = _admin_base_ctx(request, 'support')
    ctx.update({'tickets': tickets, 'counts': counts, 'status_filter': status_filter})
    response = render(request, 'core/admin_support.html', ctx)
    response['Cache-Control'] = 'no-store'
    return response


# ── Admin notifications API (mirrors /support/api/notifications/) ──

@admin_required
@require_http_methods(['GET'])
def admin_support_notifications(request):
    """Return every ticket with admin-side unread state attached. Used by
    the bell badge poll + dropdown in the admin top-bar."""
    admin = _get_session_user(request)
    rm    = _get_admin_read_marks(admin)
    tickets = get_all_tickets()
    return JsonResponse({
        'ok': True,
        'tickets': [_admin_ticket_summary(t, rm) for t in tickets],
    })


@admin_required
@require_http_methods(['POST'])
def admin_support_mark_read(request):
    """Mark one ticket (or all admin-side tickets) as acknowledged by this
    admin. Stores per-ticket ISO timestamps in ``admin_read_marks`` on the
    admin's own user document.

    POST params:
      - ticket_id: int (single)
      - all: '1'   (every ticket)
    """
    admin   = _get_session_user(request)
    rm      = dict(_get_admin_read_marks(admin))
    now_iso = datetime.utcnow().isoformat()

    if request.POST.get('all') in ('1', 'true', 'yes'):
        for t in get_all_tickets():
            rm[str(t['id'])] = t.get('updated_at') or now_iso
    else:
        try:
            tid = int(request.POST.get('ticket_id') or 0)
        except (TypeError, ValueError):
            tid = 0
        if not tid:
            return JsonResponse({'ok': False, 'error': 'ticket_id required'}, status=400)
        ticket = get_ticket(tid)
        if ticket is None:
            return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
        rm[str(tid)] = ticket.get('updated_at') or now_iso

    update_user(admin['id'], admin_read_marks=rm)
    return JsonResponse({'ok': True})


def _notify_user_ticket_update(*, ticket: dict, kind: str,
                               ticket_url: str,
                               body_snippet: str = '',
                               actor_name: str = '',
                               new_status: str = '') -> None:
    """Email the ticket owner when an admin reply or status change happens.

    ``kind`` is one of:
      - ``'reply'``         — agent posted a new message (``body_snippet`` = the message)
      - ``'status_change'`` — admin changed ticket status (``new_status`` = new value)

    Failures are caught and logged — the support email pipeline must never
    block the admin's save. If transport is misconfigured the admin still
    saves their reply / status change, the email is just skipped.
    """
    # All actual rendering + transport happens inside `email_notifications`
    # so this function is now just a thin dispatcher: pull the recipient
    # off the ticket dict, normalize the fields, hand off to the right
    # branded async helper. Both helpers are fire-and-forget (daemon
    # thread) so the admin's save returns instantly even if Resend is
    # slow/down.
    ref = ticket.get('ticket_id') or f"#{ticket.get('id')}"
    try:
        to_email = (ticket.get('user_email') or '').strip()
        if not to_email or '@' not in to_email:
            return

        subject_topic = (ticket.get('subject') or 'your support ticket').strip()
        recipient     = ticket.get('user_name') or 'there'
        agent         = (actor_name or 'Permitlify Support').strip()

        if kind == 'reply':
            from .email_notifications import send_support_reply_email_async
            send_support_reply_email_async(
                to_email      = to_email,
                recipient     = recipient,
                agent         = agent,
                ref           = ref,
                subject_topic = subject_topic,
                snippet       = (body_snippet or '').strip(),
                link          = ticket_url,
            )
        elif kind == 'status_change':
            from .email_notifications import send_support_status_email_async
            send_support_status_email_async(
                to_email      = to_email,
                recipient     = recipient,
                ref           = ref,
                subject_topic = subject_topic,
                new_status    = new_status,
                link          = ticket_url,
            )
        # else: unknown kind — silently no-op (forward-compat with future kinds).
    except Exception:
        # Belt-and-suspenders — never let an email problem bubble up.
        log.exception('support_email: unexpected error while notifying user for ticket %s', ref)


@admin_required
def admin_support_ticket_view(request, ticket_id: int):
    ticket = get_ticket(ticket_id)
    if ticket is None:
        raise Http404
    if request.method == 'POST':
        action = request.POST.get('action', '')
        if action == 'reply':
            text = request.POST.get('message', '').strip()
            agent_name = _get_session_user(request).get('name') or 'Support Team'
            if text:
                # Only notify when the message actually persisted — guards
                # against stale ticket IDs / deleted tickets / DB hiccups.
                msg_saved = add_ticket_message(ticket_id, 'agent', agent_name, text)
                # Re-read fresh status to avoid stale-snapshot bugs.
                # Agent reply on open/resolved/closed → in_progress.
                fresh = get_ticket(ticket_id)
                if fresh and fresh.get('status') in ('open', 'resolved', 'closed'):
                    update_ticket_status(ticket_id, 'in_progress')
                # Email the customer about the new agent reply. Uses the
                # customer-facing /support/ticket/<id>/ URL (NOT the admin
                # one) — built to match the support_ticket_detail route.
                if msg_saved:
                    _notify_user_ticket_update(
                        ticket       = fresh or ticket,
                        kind         = 'reply',
                        ticket_url   = request.build_absolute_uri(f'/support/ticket/{ticket_id}/'),
                        body_snippet = text,
                        actor_name   = agent_name,
                    )
        elif action == 'status':
            new_status  = request.POST.get('status', '')
            prev_status = ticket.get('status')
            if new_status == 'closed':
                fresh = get_ticket(ticket_id)
                if fresh and fresh.get('status') == 'resolved':
                    add_ticket_message(ticket_id, 'system', 'System',
                        '✓ This ticket was resolved and is now closed. Both parties confirmed the issue was resolved.')
            status_saved = update_ticket_status(ticket_id, new_status)
            # Notify the customer when the ticket reaches a milestone they
            # care about (resolved / closed). Skip the internal "back to
            # in_progress" bumps, those aren't user-facing news. Also gate
            # on the DB write actually succeeding so we never email about a
            # change that didn't persist.
            if (status_saved
                    and new_status in ('resolved', 'closed')
                    and new_status != prev_status):
                _notify_user_ticket_update(
                    ticket     = get_ticket(ticket_id) or ticket,
                    kind       = 'status_change',
                    ticket_url = request.build_absolute_uri(f'/support/ticket/{ticket_id}/'),
                    new_status = new_status,
                )
        elif action == 'priority':
            update_ticket_priority(ticket_id, request.POST.get('priority', ''))
        return redirect('admin_support_ticket', ticket_id=ticket_id)
    ticket = get_ticket(ticket_id)
    try:
        ticket['created_fmt'] = datetime.fromisoformat(ticket['created_at']).strftime('%b %d, %Y at %I:%M %p')
    except Exception:
        ticket['created_fmt'] = ticket.get('created_at', '')[:10]
    ctx = _admin_base_ctx(request, 'support')
    ctx['ticket'] = ticket
    response = render(request, 'core/admin_support_ticket.html', ctx)
    response['Cache-Control'] = 'no-store'
    return response

def privacy(request):
    return render(request, 'core/privacy.html')

def terms(request):
    return render(request, 'core/terms.html')

def pricing(request):
    return render(request, 'core/pricing.html', {
        'pricing': wp.get_pricing_dict(),
    })

def api_docs(request):
    return render(request, 'core/api_docs.html', {'demo_key': DEMO_API_KEY})

# ── Affiliate / referral helpers ───────────────────────────────

def _capture_referral_from_request(request) -> None:
    """If the URL has ?ref=CODE, stash it on the session so it survives the
    user clicking around the marketing site before they actually sign up.

    Called from the public landing page and from the dedicated /r/<code>/
    redirect view. Idempotent — silent no-op if no code is present, and
    won't overwrite a code already in the session (first attribution wins,
    which is the common SaaS convention).
    """
    code = (request.GET.get('ref') or '').strip().upper()
    if not code:
        return
    if request.session.get('referral_code'):
        return
    # Sanity: only persist codes that look like our format (alnum, 6-32 chars)
    # so a junk querystring can't bloat the session.
    if 6 <= len(code) <= 32 and code.isalnum():
        request.session['referral_code'] = code


def referral_redirect_view(request, code: str):
    """Public referral landing: /r/<code>/ → store the code and bounce to
    the signup page (or dashboard if the visitor is already logged in).
    """
    code = (code or '').strip().upper()
    if 6 <= len(code) <= 32 and code.isalnum():
        request.session['referral_code'] = code
        request.session.save()
    if request.session.get('user_id'):
        return redirect('dashboard')
    # Pass ref through to the signup form's URL too so the signup template
    # can show "you were invited" if it wants, and so social previews keep
    # the attribution in the URL bar.
    return redirect(f'/signup/?ref={code}')


def index(request):
    _capture_referral_from_request(request)
    _supported    = get_supported_cities()
    _city_count   = len(_supported)
    _state_count  = len({c['state'] for c in _supported})
    return render(request, 'core/index.html', {
        'user_logged_in': bool(request.session.get('user_id')),
        'city_count':  _city_count,
        'state_count': _state_count,
        'pricing':     wp.get_pricing_dict(),
    })

@require_http_methods(['GET', 'POST'])
def login_view(request):
    _capture_referral_from_request(request)
    if request.session.get('user_id'):
        return redirect('dashboard')
    from .google_auth import is_google_oauth_ready as _g_ready
    error = None
    email_val = ''
    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        email_val = email
        if is_email_banned(email):
            error = 'This account has been suspended. Please contact support.'
        else:
            ua  = request.META.get('HTTP_USER_AGENT', '')
            ip  = request.META.get('REMOTE_ADDR', '')
            dev = _parse_device(ua)
            user = authenticate_user(email, password)
            if user:
                if user.get('totp_enabled'):
                    request.session['totp_pending_user_id']   = user['id']
                    request.session['totp_pending_name']      = user['name']
                    request.session['totp_pending_email']     = user['email']
                    request.session['totp_pending_initials']  = user.get('avatar_initials', user['name'][:2].upper())
                    request.session['totp_pending_plan']      = user.get('plan', 'starter').title()
                    request.session['totp_pending_ua']        = ua
                    request.session['totp_pending_ip']        = ip
                    request.session['totp_pending_dev']       = dev
                    return redirect('login_2fa')

                # ── Email-code verification step ────────────────────────
                # Every non-TOTP login must enter a one-time 6-digit code
                # we just emailed them. The send is dispatched on a daemon
                # thread (300-2000 ms saved on the redirect — the user
                # waits on their inbox, not on our SMTP roundtrip). If
                # email transport is not configured AT ALL we still fall
                # back to direct login so a fresh-deploy admin can get
                # in to wire up Resend in the first place. We do NOT
                # fall back on transient transport failures — that path
                # used to silently bypass 2FA whenever the email provider
                # hiccupped.
                from .auth_codes import (
                    generate_code, hash_code, expiry_iso,
                    send_login_code_email_async, is_email_transport_configured,
                    CODE_TTL_MINUTES, CODE_MAX_ATTEMPTS,
                )
                code = generate_code()
                # Cheap static check (no network) BEFORE we touch the
                # session so we still fall back to direct login on a
                # fresh deploy with no Resend / SMTP wired up. Doing
                # this first lets us write the pending session state
                # atomically before the worker thread is dispatched —
                # if anything between the write and the dispatch were
                # to crash, the user just retries /login/ rather than
                # ending up with a code in their inbox tied to no
                # pending state.
                #
                # ALSO honour the per-user `email_code_disabled` flag
                # (default False = code required). Admins flip this
                # from /admin-panel/users/ when a customer can't
                # receive our codes (corporate spam filter, ESP
                # deliverability issue, etc.) — opting that single
                # user out of the email-code gate without disabling
                # the feature site-wide. Defense-in-depth: TOTP-
                # enabled users were already redirected above, so
                # they keep their second factor regardless of this
                # flag.
                _user_email_code_disabled = bool(user.get('email_code_disabled'))
                if is_email_transport_configured() and not _user_email_code_disabled:
                    from datetime import datetime as _dt, timezone as _tz
                    request.session['email_code_pending_user_id']      = user['id']
                    request.session['email_code_pending_name']         = user['name']
                    request.session['email_code_pending_email']        = user['email']
                    request.session['email_code_pending_initials']     = user.get('avatar_initials', user['name'][:2].upper())
                    request.session['email_code_pending_plan']         = user.get('plan', 'starter').title()
                    request.session['email_code_pending_ua']           = ua
                    request.session['email_code_pending_ip']           = ip
                    request.session['email_code_pending_dev']          = dev
                    request.session['email_code_pending_code_hash']    = hash_code(code)
                    request.session['email_code_pending_expires_at']   = expiry_iso()
                    request.session['email_code_pending_attempts']     = CODE_MAX_ATTEMPTS
                    # Also stamp the cooldown clock on initial dispatch
                    # so the 60-second resend cooldown applies to the
                    # FIRST manual resend too, not just resend-after-
                    # resend. Without this, a user could click "Resend"
                    # the instant they land on the verify page and
                    # email-bomb the recipient.
                    request.session['email_code_pending_last_send_at'] = _dt.now(_tz.utc).isoformat()
                    # Now actually send. Pre-flight already passed so
                    # we expect (True, '') back; on the off chance the
                    # transport status flipped between the check and
                    # the dispatch the worker logs the failure and the
                    # user falls back to "Resend code".
                    send_login_code_email_async(
                        to_email   = user['email'],
                        to_name    = user.get('name', ''),
                        code       = code,
                        request_ip = ip,
                        request_ua = ua,
                    )
                    return redirect('login_verify_code')
                # No transport configured at all — preserve the long-
                # standing safety valve so a fresh-deploy admin can get
                # in. Transient transport failures (Resend down, network
                # hiccup) no longer hit this branch; they happen inside
                # the worker thread now and the user discovers them by
                # not receiving the code.
                # Differentiate the two reasons we land here so ops
                # logs distinguish "config gap" from "admin opted this
                # specific user out". Only the former is a deploy
                # warning; the latter is expected per-user behaviour.
                if _user_email_code_disabled:
                    log.info(
                        "email-code login: skipped — admin disabled "
                        "email-code verification for user %s",
                        user.get('email'),
                    )
                else:
                    log.warning(
                        "email-code login: no email transport configured "
                        "(set RESEND_API_KEY or SMTP env vars) — direct login for %s",
                        user.get('email'),
                    )
                # Refresh Whop state before minting the session so the
                # plan badge/banner everywhere reflects the latest billing
                # reality (cancellations, plan switches done outside our
                # checkout) without waiting for the next webhook delivery.
                # 3s timeout per call. Wrapped: a Whop / detection bug
                # must never block login — fall back to the existing
                # user.plan so the session is still consistent.
                try:
                    _whop = _whop_login_sync(user['id'], user)
                except Exception:
                    log.exception("_whop_login_sync failed for user %s (email login)", user.get('id'))
                    _whop = {'plan': (user.get('plan') or 'starter')}
                request.session['user_id']       = user['id']
                request.session['user_name']     = user['name']
                request.session['user_email']    = user['email']
                request.session['user_initials'] = user.get('avatar_initials', user['name'][:2].upper())
                request.session['user_plan']     = (_whop['plan'] or 'starter').title()
                request.session.save()
                create_session(user_id=user['id'], session_key=request.session.session_key,
                               device=dev, ip=ip, ua=ua)
                # Fire login-alert BEFORE record_login_event so this very
                # session isn't already in login_history when the new-
                # device check runs (otherwise it would always look "seen"
                # and we'd never alert). Method label notes the lack of
                # email transport for ops triage.
                _send_login_alert_if_new_device(
                    user=user, request=request,
                    method_label='Email + password (no email transport)',
                    device=dev, ip=ip, ua=ua,
                )
                record_login_event(user_id=user['id'], status='success',
                                   device=dev, ip=ip, ua=ua)
                return redirect('dashboard')
            # Record failed attempt if the email exists
            maybe = get_user_by_email(email)
            if maybe:
                record_login_event(user_id=maybe['id'], status='failed',
                                   device=dev, ip=ip, ua=ua)
            error = 'Invalid email or password. Please try again or use "Forgot password" if you need to reset it.'
    # Translate ?google_error=… / ?google_unavailable=1 into a friendly message
    if not error:
        ge = request.GET.get('google_error', '')
        if ge:
            _msgs = {
                'state_mismatch':         'Google sign-in expired or was blocked. Please try again.',
                'token_exchange_failed':  'We couldn\'t complete Google sign-in (token exchange failed).',
                'no_access_token':        'Google didn\'t return a valid access token.',
                'userinfo_failed':        'We couldn\'t reach Google to verify your account.',
                'missing_profile':        'Your Google profile was missing required fields.',
                'email_unverified':       'Your Google account email isn\'t verified — verify it with Google first.',
                'banned':                 'This account has been suspended. Please contact support.',
                'create_failed':          'We couldn\'t create your account from Google. Try again or use email signup.',
                'access_denied':          'Google sign-in was cancelled.',
                'email_already_linked':   'An account with this email is already linked to a different Google account. Sign in with your password and unlink it from Settings first.',
            }
            error = _msgs.get(ge, 'Google sign-in failed. Please try again.')
        elif request.GET.get('google_unavailable'):
            error = 'Google sign-in isn\'t configured yet. Please use email and password.'
    return render(request, 'core/login.html', {
        'error': error,
        'email_val': email_val,
        'google_oauth_ready': _g_ready(),
    })

@require_http_methods(['GET', 'POST'])
def signup_view(request):
    _capture_referral_from_request(request)
    if request.session.get('user_id'):
        return redirect('dashboard')
    from .google_auth import is_google_oauth_ready as _g_ready
    errors = {}
    vals = {}
    if request.method == 'POST':
        name     = request.POST.get('name', '').strip()
        email    = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        confirm  = request.POST.get('confirm', '')
        vals = {'name': name, 'email': email}
        if not name:
            errors['name'] = 'Full name is required.'
        if not email or '@' not in email:
            errors['email'] = 'A valid email address is required.'
        if len(password) < 8:
            errors['password'] = 'Password must be at least 8 characters.'
        elif password != confirm:
            errors['confirm'] = 'Passwords do not match.'
        if not errors and is_email_banned(email):
            errors['email'] = 'This email address is not permitted to create an account.'
        if not errors:
            user = create_user(email=email, password=password, name=name, plan='starter')
            if user is None:
                errors['email'] = 'An account with this email already exists.'
            else:
                # Bind to the referrer captured from ?ref= (if any) before
                # creating the auth session, so the very first ledger event
                # is recorded as part of the signup transaction window.
                # Only pop after a successful create — otherwise a validation
                # error (mismatched passwords, etc.) would silently strip the
                # referral attribution before the user fixed the form.
                _ref = (request.session.get('referral_code', '') or '').strip().upper()
                if _ref:
                    try:
                        bind_referrer_for_user(user['id'], _ref)
                    except Exception:
                        pass
                request.session.pop('referral_code', None)
                request.session['user_id']       = user['id']
                request.session['user_name']     = user['name']
                request.session['user_email']    = user['email']
                request.session['user_initials'] = user.get('avatar_initials', name[:2].upper())
                request.session['user_plan']     = user.get('plan', 'starter').title()
                request.session.save()
                ua  = request.META.get('HTTP_USER_AGENT', '')
                ip  = request.META.get('REMOTE_ADDR', '')
                dev = _parse_device(ua)
                create_session(user_id=user['id'], session_key=request.session.session_key,
                               device=dev, ip=ip, ua=ua)
                record_login_event(user_id=user['id'], status='success',
                                   device=dev, ip=ip, ua=ua)
                # Brand-new account → fire welcome email. Skip the
                # login-alert email here on purpose: a "new sign-in
                # detected" message immediately after signup would be
                # disorienting for the user.
                _fire_welcome_email(user, request)
                return redirect('onboarding')
    return render(request, 'core/signup.html', {
        'errors': errors,
        'vals': vals,
        'google_oauth_ready': _g_ready(),
    })


# ── Google OAuth (Sign in / Sign up with Google) ─────────────────────────

@require_http_methods(['GET'])
def google_oauth_start(request):
    """Step 1 of the Google sign-in flow: stash a CSRF state in the session
    and redirect the user to Google's authorize endpoint. Same entry point is
    used for both login and signup — the callback decides which based on
    whether the user already exists."""
    if request.session.get('user_id'):
        return redirect('dashboard')
    from .google_auth import (get_google_settings, is_google_oauth_ready,
                              build_authorize_url, build_redirect_uri, new_state)
    if not is_google_oauth_ready():
        return redirect('/login/?google_unavailable=1')
    cfg = get_google_settings()
    state = new_state()
    request.session['google_oauth_state']  = state
    request.session['google_oauth_intent'] = request.GET.get('intent', 'login')
    request.session.save()
    redirect_uri = build_redirect_uri(request)
    return redirect(build_authorize_url(cfg['client_id'], redirect_uri, state))


@require_http_methods(['GET'])
def google_oauth_callback(request):
    """Step 2: Google redirects the user back here with ``code`` + ``state``.
    We validate the state against the session, exchange the code for tokens,
    look up the user by Google's stable ``sub``, falling back to email
    matching, and finally create a fresh account if nothing matches."""
    from .google_auth import (is_google_oauth_ready, get_google_settings,
                              exchange_code_for_token, fetch_userinfo,
                              build_redirect_uri)
    import urllib.parse as _urlparse

    if not is_google_oauth_ready():
        return redirect('/login/?google_unavailable=1')
    if request.GET.get('error'):
        err = _urlparse.quote(request.GET.get('error', ''))[:64]
        return redirect(f'/login/?google_error={err}')

    code  = request.GET.get('code', '')
    state = request.GET.get('state', '')
    expected = request.session.pop('google_oauth_state', None)
    intent   = request.session.pop('google_oauth_intent', 'login') or 'login'

    if not code or not state or not expected or state != expected:
        return redirect('/login/?google_error=state_mismatch')

    cfg = get_google_settings()
    redirect_uri = build_redirect_uri(request)
    try:
        tokens = exchange_code_for_token(code, cfg['client_id'],
                                         cfg['client_secret'], redirect_uri)
    except Exception:
        return redirect('/login/?google_error=token_exchange_failed')

    access_token = tokens.get('access_token')
    if not access_token:
        return redirect('/login/?google_error=no_access_token')

    try:
        info = fetch_userinfo(access_token)
    except Exception:
        return redirect('/login/?google_error=userinfo_failed')

    sub   = info.get('sub')
    email = (info.get('email') or '').lower().strip()
    name  = info.get('name') or ''
    email_verified = bool(info.get('email_verified'))

    if not sub or not email:
        return redirect('/login/?google_error=missing_profile')
    if not email_verified:
        return redirect('/login/?google_error=email_unverified')
    if is_email_banned(email):
        return redirect('/login/?google_error=banned')

    # Resolve the user: by linked Google sub first, then by matching email
    # (auto-link), then create a brand-new account.
    #
    # Auto-link safety: if an account with the same email is already linked to
    # a *different* google_sub we refuse rather than silently overwriting that
    # link — otherwise an attacker who controls a recycled email at Google
    # could quietly hijack the local account. Recovery in that case has to go
    # through the existing password / 2FA flow.
    user = get_user_by_google_sub(sub)
    is_new_account = False
    if user is None:
        existing = get_user_by_email(email)
        if existing is not None:
            existing_sub = (existing.get('google_sub') or '').strip()
            if existing_sub and existing_sub != str(sub):
                return redirect('/login/?google_error=email_already_linked')
            if not existing_sub:
                link_google_to_user(existing['id'], sub, email)
            user = get_user_by_email(email)
        else:
            user = create_user_from_google(email=email, name=name, google_sub=sub)
            is_new_account = True
            if user is not None:
                # Same referral binding as the email-signup path. Read first,
                # bind, then pop — so we never strip attribution on a failed
                # creation path, but always clear it after a successful one
                # to avoid leaking it to a later visitor sharing this browser.
                _ref = (request.session.get('referral_code', '') or '').strip().upper()
                if _ref:
                    try:
                        bind_referrer_for_user(user['id'], _ref)
                    except Exception:
                        pass
                request.session.pop('referral_code', None)
            if user is None:
                # Lost a creation race with a concurrent callback for the same
                # email — re-fetch by email/sub before giving up.
                user = get_user_by_google_sub(sub) or get_user_by_email(email)
                is_new_account = False
                if user is None:
                    return redirect('/login/?google_error=create_failed')

    # Defend against session-fixation: rotate the session id at the moment we
    # mark the session as authenticated, so any pre-login session id an
    # attacker may have observed is invalidated.
    request.session.cycle_key()

    # Refresh Whop state on every successful Google login. Does an
    # email-based lookup against Whop (no plan-check throttle, 3-second
    # timeout), picks the highest-tier active membership as source of
    # truth, and writes plan/billing to the user record. For brand-new
    # accounts with no Whop subscription yet, this is a safe no-op.
    # Wrapped: a Whop / detection bug must never break Google login —
    # fall back to the existing user.plan so the session still mints.
    try:
        _whop = _whop_login_sync(user['id'], user)
    except Exception:
        log.exception("_whop_login_sync failed for user %s (google login)", user.get('id'))
        _whop = {'plan': (user.get('plan') or 'starter')}

    # Mint the session — same shape as login_view / signup_view.
    request.session['user_id']       = user['id']
    request.session['user_name']     = user.get('name', '') or email
    request.session['user_email']    = user.get('email', email)
    request.session['user_initials'] = (user.get('avatar_initials')
                                        or (user.get('name', email) or email)[:2].upper())
    request.session['user_plan']     = (_whop['plan'] or 'starter').title()
    request.session.save()

    ua  = request.META.get('HTTP_USER_AGENT', '')
    ip  = request.META.get('REMOTE_ADDR', '')
    dev = _parse_device(ua)
    create_session(user_id=user['id'], session_key=request.session.session_key,
                   device=dev, ip=ip, ua=ua)
    # Login-alert email (only for returning users — brand-new Google
    # signups get the welcome email instead, fired below). Must run
    # BEFORE record_login_event so the new-device check doesn't see
    # this very session as already-known.
    if not is_new_account:
        _send_login_alert_if_new_device(
            user=user, request=request,
            method_label='Google sign-in',
            device=dev, ip=ip, ua=ua,
        )
    record_login_event(user_id=user['id'], status='success',
                       device=dev, ip=ip, ua=ua)

    if is_new_account:
        # First-time Google signup → welcome email + onboarding flow.
        _fire_welcome_email(user, request)
        return redirect('onboarding')
    if not user.get('onboarding_complete'):
        return redirect('onboarding')
    return redirect('dashboard')


@login_required
@require_http_methods(['GET', 'POST'])
def onboarding_view(request):
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}

    if user.get('onboarding_complete') is True:
        return redirect('dashboard')

    supported_cities = get_supported_cities()
    states_map = {}
    for c in supported_cities:
        s = c['state']
        states_map.setdefault(s, []).append(c['city'])
    states_sorted = sorted(states_map.keys())

    step = request.session.get('onboarding_step', 1)
    error = None

    # Onboarding ordering (as of the plan-first refactor):
    #   step 1 = Choose Plan      (stash plan+period in session, advance)
    #   step 2 = Service Area     (city/state, save city to user, advance)
    #   step 3 = Terms of Service (record acceptance, then redirect to
    #                              embedded Whop checkout using the
    #                              plan+period stashed in step 1)
    # On checkout success (ls_success) the user is auto-redirected to the
    # dashboard, so the post-pay landing is their logged-in session.

    if request.method == 'GET' and request.GET.get('sync_error'):
        # Coming back from a failed checkout — drop the user on the Terms
        # step so they can re-accept and re-trigger payment.
        error = 'No active subscription found yet. Please complete payment and try again.'
        step = 3
        request.session['onboarding_step'] = 3

    if request.method == 'GET' and request.GET.get('back'):
        try:
            back_to = max(1, int(request.GET.get('back', 1)))
            request.session['onboarding_step'] = back_to
            step = back_to
        except (ValueError, TypeError):
            pass

    if request.method == 'POST':
        posted_step = int(request.POST.get('step', 1))

        if posted_step == 1:
            # Plan selection — stash, do not charge yet.
            plan   = request.POST.get('plan', 'starter').lower()
            period = request.POST.get('period', 'monthly').lower()
            if plan not in ('starter', 'pro', 'agency'):
                plan = 'starter'
            if period not in ('monthly', 'annual'):
                period = 'monthly'
            request.session['onboarding_plan']   = plan
            request.session['onboarding_period'] = period
            step = 2
            request.session['onboarding_step'] = 2

        elif posted_step == 2:
            # City selection — capped by the selected plan's city limit.
            # The user can also skip and configure cities later from
            # Settings → City Coverage.
            _plan_for_step2 = (request.session.get('onboarding_plan') or 'starter').lower()
            _city_limit     = PLAN_CITY_LIMITS.get(_plan_for_step2, 1)

            if request.POST.get('skip') == '1':
                # Skip: don't write any cities to the user; they'll add them
                # from Settings → City Coverage after activation. Clear any
                # previously-stashed onboarding city so the next step doesn't
                # imply they picked one.
                request.session.pop('onboarding_city',  None)
                request.session.pop('onboarding_state', None)
                step = 3
                request.session['onboarding_step'] = 3
            else:
                # Repeated name="city" fields → list. Strip + de-dupe (case
                # insensitive) while preserving order. Validate each against
                # the supported-city list.
                valid_cities = {c['city'].lower() for c in supported_cities}
                raw_cities   = [c.strip() for c in request.POST.getlist('city') if c.strip()]
                seen = set()
                cities = []
                for c in raw_cities:
                    cl = c.lower()
                    if cl in seen:
                        continue
                    if cl not in valid_cities:
                        continue
                    seen.add(cl)
                    cities.append(c)

                if not cities:
                    error = 'Please pick at least one city, or use “Skip for now” to set this up later.'
                    step = 2
                elif len(cities) > _city_limit:
                    _label = _plan_for_step2.title()
                    _word  = 'city' if _city_limit == 1 else 'cities'
                    error = f'Your {_label} plan supports up to {_city_limit} {_word}. Please remove the extras.'
                    step = 2
                else:
                    # Stash the first city in the session so step 3 has
                    # something to reference; persist the full list to the
                    # user record.
                    request.session['onboarding_city'] = cities[0]
                    update_user(user_id, cities=cities)
                    step = 3
                    request.session['onboarding_step'] = 3

        elif posted_step == 3:
            # Terms acceptance + redirect into embedded Whop checkout
            # using whatever plan/period was selected in step 1.
            agreed = request.POST.get('agreed') == '1'
            if not agreed:
                error = 'You must accept the Terms of Service to continue.'
                step = 3
            else:
                from datetime import timezone as _tz
                ts = datetime.now(_tz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
                update_user(user_id, terms_accepted_at=ts)
                plan   = (request.session.get('onboarding_plan')   or 'starter').lower()
                period = (request.session.get('onboarding_period') or 'monthly').lower()
                if plan not in ('starter', 'pro', 'agency'):
                    plan = 'starter'
                if period not in ('monthly', 'annual'):
                    period = 'monthly'
                return redirect(f'/billing/embed/?plan={plan}&period={period}&back=/onboarding/')

    # City limit on step 2 derives from whatever plan was picked on step 1.
    _ob_plan_session = (request.session.get('onboarding_plan') or 'starter').lower()
    _ob_city_limit   = PLAN_CITY_LIMITS.get(_ob_plan_session, 1)

    ctx = {
        'step':            step,
        'error':           error,
        'states_map':      states_map,
        'states_sorted':   states_sorted,
        'states_map_json': json.dumps(states_map),
        'onboarding_city':   request.session.get('onboarding_city', ''),
        'onboarding_state':  request.session.get('onboarding_state', ''),
        'onboarding_plan':   request.session.get('onboarding_plan',   ''),
        'onboarding_period': request.session.get('onboarding_period', 'monthly'),
        # City-coverage cap for the multi-city picker on step 2.
        'city_limit':       _ob_city_limit,
        'city_limit_label': 'city' if _ob_city_limit == 1 else 'cities',
        'user_name':    user.get('name', ''),
        'user_email':   user.get('email', ''),
        # Pricing for the plan cards in step 1 — resolved in this user's
        # own Whop mode so a PROD-flagged user never sees $1 dev prices
        # just because the global mode is currently 'dev' (and vice-versa).
        # Without this the template's {{ pricing.starter_monthly }} etc.
        # would either render blank or render the wrong amount.
        'pricing':      wp.get_pricing_dict(wp.mode_for_user(user)),
    }
    return render(request, 'core/onboarding.html', ctx)


@login_required
def paywall_view(request):
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}

    if user.get('subscription_active') is True:
        return redirect('dashboard')

    # "New" = never had a Whop membership; "renew" = had one that lapsed.
    is_new_user = not (user.get('whop_membership_id') or '').strip()

    sync_error    = request.GET.get('sync_error')
    missing_plan  = request.GET.get('missing_plan', '').strip()
    missing_label = ''
    if missing_plan and '_' in missing_plan:
        plan, period = missing_plan.split('_', 1)
        missing_label = f'{plan.title()} ({period})'

    # Build pricing dict for the user's *own* Whop mode — otherwise a PROD
    # account hits checkout against $29/$99/$249 plan IDs while the paywall
    # itself rendered $1 prices because the global mode happened to be 'dev'
    # (or vice-versa). Each user sees the prices they'll actually be billed.
    user_mode = wp.mode_for_user(user)
    pricing   = wp.get_pricing_dict(user_mode)

    # Build the available_plans map so the template can disable any button
    # whose Whop plan_id isn't configured yet (instead of letting the user
    # click into a silent redirect loop back to the paywall). Resolved in
    # the user's own mode so a PROD user isn't blocked because a DEV plan
    # ID happens to be missing (or vice-versa).
    available = {}
    for plan in ('starter', 'pro', 'agency'):
        for period in ('monthly', 'annual'):
            available[f'{plan}_{period}'] = bool(wp.get_plan_id(plan, period, user_mode))

    ctx = {
        'user_name':     user.get('name', ''),
        'user_email':    user.get('email', ''),
        'sync_error':    sync_error,
        'missing_label': missing_label,
        'is_new_user':   is_new_user,
        'pricing':       pricing,
        'available':     available,
    }
    return render(request, 'core/paywall.html', ctx)


def logout_view(request):
    session_key = request.session.session_key
    user_id = request.session.get('user_id')
    if session_key and user_id:
        try:
            from .pg import execute as _pg_execute
            _pg_execute("DELETE FROM sessions WHERE session_key = %s", (session_key,))
        except Exception:
            pass
    request.session.flush()
    return render(request, 'core/logout.html')

import secrets as _secrets
from datetime import timedelta

@require_http_methods(['GET', 'POST'])
def forgot_password(request):
    if request.session.get('user_id'):
        return redirect('dashboard')
    sent    = False
    error   = None
    email_val = ''
    reset_link = None
    if request.method == 'POST':
        # ── IP rate limit ───────────────────────────────────────────
        # 5 reset requests per IP per 5-minute window. Stops the form
        # from being weaponised to (a) flood a victim's inbox and
        # (b) burn through the Resend quota. Uses Django's default
        # cache backend — per-process LocMemCache is fine here, the
        # goal is friction, not perfect distributed throttling.
        from django.core.cache import cache
        rl_ip  = request.META.get('REMOTE_ADDR', 'unknown')
        rl_key = f'forgot_pw_rl:{rl_ip}'
        rl_n   = int(cache.get(rl_key) or 0)
        if rl_n >= 5:
            error = 'Too many reset requests from this address. Please wait a few minutes and try again.'
            return render(request, 'core/forgot_password.html', {
                'sent': False, 'error': error,
                'email_val': request.POST.get('email', '').strip().lower(),
                'reset_link': None,
            })
        cache.set(rl_key, rl_n + 1, timeout=300)

        email = request.POST.get('email', '').strip().lower()
        email_val = email
        if not email or '@' not in email:
            error = 'Please enter a valid email address.'
        else:
            user = get_user_by_email(email)
            if user and not is_email_banned(email):
                from datetime import timezone as _tz
                token  = _secrets.token_urlsafe(32)
                # Aware UTC on both sides — stored as ISO-8601 with
                # tzinfo so the comparison in ``reset_password`` (also
                # aware) doesn't trip on naive-vs-aware TypeErrors and
                # token TTLs are exactly 1h regardless of server TZ.
                expiry = (datetime.now(_tz.utc) + timedelta(hours=1)).isoformat()
                set_reset_token(email, token, expiry)
                reset_link = request.build_absolute_uri(
                    '/reset-password/' + token + '/'
                )
                # ── Send the beautiful HTML reset email ────────────
                # If the email transport is configured, deliver the link
                # over email and never echo it back to the page (account
                # enumeration prevention + don't leak reset tokens to
                # whoever happens to have typed in someone else's email).
                # If transport is DOWN, we keep ``reset_link`` set so the
                # template's amber "Demo mode — reset link" panel shows
                # it on screen — that way the admin can recover their
                # own password before they've finished wiring up Resend.
                from .auth_codes import send_reset_password_email
                ok, msg = send_reset_password_email(
                    to_email   = user['email'],
                    to_name    = user.get('name', ''),
                    reset_link = reset_link,
                    request_ip = request.META.get('REMOTE_ADDR', ''),
                    request_ua = request.META.get('HTTP_USER_AGENT', ''),
                )
                if ok:
                    reset_link = None   # delivered — keep it private
                else:
                    log.warning(
                        "forgot-password: transport down for %s (%s) — "
                        "falling back to on-screen link",
                        email, msg,
                    )
            # ── account-enumeration protection ─────────────────────
            # Always show the "if that email is registered, a link is on
            # its way" success state regardless of whether the email
            # actually exists. The attacker can't tell from the response
            # whether they've found a real user.
            sent = True
    return render(request, 'core/forgot_password.html', {
        'sent': sent, 'error': error, 'email_val': email_val,
        'reset_link': reset_link,
    })

@csrf_exempt
@require_http_methods(['GET', 'POST'])
def reset_password(request, token):
    """
    The URL token IS the security mechanism here:

      • cryptographic random (``secrets.token_urlsafe(32)``)
      • single-use (cleared on successful reset)
      • expires after 1 hour
      • only ever sent to the verified account email

    Whoever holds the URL is, by construction, the legitimate owner of
    the account — that's the entire point of a "reset password" link.
    Layering CSRF on top adds zero protection (an attacker who has the
    URL can already POST it themselves; they don't need to trick the
    user) and was causing real production failures for users coming
    from Gmail / Outlook / Apple Mail because of stale csrftoken
    cookies, cross-tab cookie state, and corporate-proxy quirks. So
    we ``@csrf_exempt`` this view explicitly.
    """
    if request.session.get('user_id'):
        return redirect('dashboard')
    user = get_user_by_reset_token(token)
    if not user:
        return render(request, 'core/reset_password.html', {'invalid': True})
    from datetime import timezone
    expiry_str = user.get('reset_expiry') or ''
    try:
        expiry_dt = datetime.fromisoformat(expiry_str)
        # Tokens minted before the timezone-fix shipped were saved as
        # naive UTC. Promote naive → aware UTC so the comparison below
        # (always aware) doesn't crash with "can't compare offset-naive
        # and offset-aware datetimes" on legacy tokens.
        if expiry_dt.tzinfo is None:
            expiry_dt = expiry_dt.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > expiry_dt:
            clear_reset_token(user['id'])
            return render(request, 'core/reset_password.html', {'expired': True})
    except Exception:
        return render(request, 'core/reset_password.html', {'invalid': True})
    error = None
    if request.method == 'POST':
        pw1 = request.POST.get('password', '')
        pw2 = request.POST.get('confirm', '')
        if len(pw1) < 8:
            error = 'Password must be at least 8 characters.'
        elif pw1 != pw2:
            error = 'Passwords do not match.'
        else:
            update_user(user['id'], password=hash_password(pw1))
            clear_reset_token(user['id'])
            # ── invalidate all existing sessions ───────────────────
            # If the account was compromised, the attacker's session
            # would survive the password change. Nuke every session
            # for this user — they (and any attacker) must sign in
            # fresh with the new password.
            try:
                delete_sessions_for_user(user['id'])
            except Exception:
                log.exception("password-reset: failed to revoke sessions for user %s", user['id'])
            return render(request, 'core/reset_password.html', {'success': True})
    return render(request, 'core/reset_password.html', {
        'token': token, 'user_email': user.get('email', ''), 'error': error,
    })

# ── Protected views ───────────────────────────────────────────

@login_required
@subscription_required
def dashboard(request):
    ctx     = _user_ctx(request)
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}

    # ── Sync plan from DB — trust DB over stale session ────────
    _db_plan = user.get('plan', 'starter').title()
    if _db_plan != ctx.get('user_plan'):
        ctx['user_plan'] = _db_plan
        request.session['user_plan'] = _db_plan

    # Count each dashboard visit as one alert digest delivered
    increment_user_field(user_id, 'alerts_sent', 1)
    raw     = user.get('cities', [])
    plan_cities, plan_states = [], set()
    for c in raw:
        c = c.strip()
        name, st = (c.rsplit(', ', 1) + [''])[:2] if ', ' in c else (c, _city_state(c))
        plan_cities.append({'name': name.strip(), 'state': st.strip()})
        if st: plan_states.add(st.strip())
    plan_states = sorted(plan_states)
    ctx['plan_cities_json'] = json.dumps(plan_cities)
    ctx['plan_states']      = plan_states
    # City freeze check
    plan       = user.get('plan', 'starter')
    city_limit = PLAN_CITY_LIMITS.get(plan, 1)
    ctx['cities_frozen']  = user.get('cities_frozen', False)
    ctx['city_limit']     = city_limit
    ctx['city_count']     = len(raw)
    ctx['city_excess']    = max(0, len(raw) - city_limit)
    # Pending downgrade banner — validate it is truly a downgrade
    _RANK = {'starter': 0, 'pro': 1, 'agency': 2}
    pending_dg   = user.get('pending_downgrade') or {}
    current_rank = _RANK.get(ctx['user_plan'].lower(), 0)
    if pending_dg:
        pending_rank = _RANK.get(pending_dg.get('plan', '').lower(), 0)
        if pending_rank >= current_rank:
            # Stale / invalid state — clear it silently
            update_user(user_id, pending_downgrade=None)
            pending_dg = {}
    ctx['pending_downgrade'] = pending_dg if pending_dg else None
    if pending_dg:
        from datetime import datetime, timezone
        try:
            sched_dt  = datetime.strptime(pending_dg['date'], '%Y-%m-%d')
            today_dt  = datetime.now(timezone.utc).replace(tzinfo=None)
            days_left = (sched_dt - today_dt).days
        except Exception:
            days_left = 0
        ctx['days_until_downgrade'] = max(0, days_left)
    else:
        ctx['days_until_downgrade'] = None
    # Filter dashboard permits to the user's subscribed cities only
    _user_city_set = {pc['name'].lower() for pc in plan_cities}
    _db_permits = [p for p in DASHBOARD_PERMITS if p['city'].lower() in _user_city_set] if _user_city_set else []
    ctx['all_permits_json'] = json.dumps(_db_permits)
    response = render(request, 'core/dashboard.html', ctx)
    response['Cache-Control'] = 'no-store'
    return response

@login_required
@subscription_required
def permits_data_view(request):
    """DataTables-compatible JSON endpoint backing /permits/.

    Replaces the legacy approach of dumping every matching row into the
    HTML as a giant inline JSON blob. The browser now asks for the
    visible page only (DataTables server-side processing) and re-asks
    on every sort / filter / page change. The same authorisation gate
    used by `permits()` applies here — `query_permits_for_dashboard`
    enforces the user's city subscription set + per-plan history window
    as the first WHERE clause on every query, so a hand-crafted GET
    cannot leak permits in cities the caller doesn't pay for.

    DataTables sends the standard params (`draw`, `start`, `length`,
    `order[0][column]`, `order[0][dir]`, `search[value]`) plus our
    custom panel filters as flat GET params (`f_state`, `f_city`,
    `f_type`, `f_status`, `f_score_min`, `f_score_max`, `f_owner`,
    `f_phone`, `f_email`, `f_issued_after`, `f_expires_before`,
    `f_keyword`, `f_tier`). All filtering, sorting, and pagination
    happens in SQL — Postgres returns exactly the visible page so a
    single account with thousands of permits stays as fast as one
    with a handful, and there's no upstream cap to silently truncate
    the result.
    """
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    raw     = user.get('cities', [])
    plan_cities = []
    for c in raw:
        c = c.strip()
        name, st = (c.rsplit(', ', 1) + [''])[:2] if ', ' in c else (c, _city_state(c))
        plan_cities.append({'name': name.strip(), 'state': st.strip()})
    _user_city_set = {pc['name'].lower() for pc in plan_cities}

    plan = user.get('plan', 'starter')
    if user.get('cities_frozen', False) or not _user_city_set:
        # Frozen accounts see an empty table — same UX as the page
        # render, where the table is hidden and a banner shown instead.
        return JsonResponse({
            'draw': int(request.GET.get('draw', 1) or 1),
            'recordsTotal': 0, 'recordsFiltered': 0, 'data': [],
        })

    _plan_title  = plan.title() if plan.lower() in ('starter', 'pro', 'agency') else 'Starter'
    _plan_limits = PLAN_USAGE_LIMITS.get(_plan_title, PLAN_USAGE_LIMITS['Starter'])
    _history_days = _plan_limits.get('history_days')
    _feats = PLAN_FEATURES.get(_plan_title, PLAN_FEATURES['Starter'])

    g = request.GET
    f_state   = (g.get('f_state', '') or '').strip()
    f_city    = (g.get('f_city', '') or '').strip()
    # Trade filter is gated to plans that have the feature flag — a
    # Starter user spoofing `?f_type=hvac` shouldn't be able to filter
    # by trade because the panel control isn't rendered for them.
    f_type    = (g.get('f_type', '') or '').strip() if _feats['trade_filter'] else ''
    f_status  = (g.get('f_status', '') or '').strip()
    try:    f_score_min = max(0,   int(g.get('f_score_min') or 0))
    except (TypeError, ValueError): f_score_min = 0
    try:    f_score_max = min(100, int(g.get('f_score_max') or 100))
    except (TypeError, ValueError): f_score_max = 100
    f_owner   = (g.get('f_owner', '') or '').strip()
    f_phone_d = ''.join(ch for ch in (g.get('f_phone', '') or '') if ch.isdigit())
    f_email   = (g.get('f_email', '') or '').strip()
    # Date filters are handed to Postgres as bind params. The browser's
    # <input type="date"> control always sends ISO `YYYY-MM-DD`, but a
    # crafted GET could send `;` or `2026-13-99` and turn a benign
    # filter into a 500. Validate the shape here and silently drop the
    # filter on anything that isn't a real calendar date.
    def _iso_date_or_empty(raw):
        s = (raw or '').strip()
        if not s:
            return ''
        try:
            from datetime import date as _date
            _date.fromisoformat(s)
            return s
        except (TypeError, ValueError):
            return ''
    f_iafter  = _iso_date_or_empty(g.get('f_issued_after'))
    f_ebefore = _iso_date_or_empty(g.get('f_expires_before'))
    f_kw      = (g.get('f_keyword', '') or '').strip()
    f_tier    = (g.get('f_tier', 'all') or 'all').strip().lower()
    g_search  = (g.get('search[value]', '') or '').strip()

    # ── Sort: map the JS column index DataTables sends to the legacy
    #    view-key the SQL helper whitelists. An out-of-range index
    #    silently falls back to the default (score DESC) — same as
    #    the old in-Python pipeline.
    # Mirrors the on-page column order in templates/core/permits.html.
    # The visible Expires + Project Value columns were retired so the
    # table fits the page; expiresIso / valueCents stayed in filters
    # and CSV export but no longer appear in this index → score is
    # now col 8 instead of col 10. Anything out of range silently
    # falls back to the score-DESC default.
    _SORT_KEYS = ['id', 'city', 'type', 'status', 'issuedIso',
                  'phone', 'email', 'owner', 'score']
    try:    col_idx = int(g.get('order[0][column]', '8') or 8)
    except (TypeError, ValueError): col_idx = 8
    sort_dir = (g.get('order[0][dir]', 'desc') or 'desc').lower()
    sort_key = _SORT_KEYS[col_idx] if 0 <= col_idx < len(_SORT_KEYS) else 'score'

    # ── Paginate: clamp `length` to 500 so DataTables' `length=-1`
    #    "show all" sentinel (or a crafted `length=99999`) can't
    #    stream every row. 500 matches the largest option in the
    #    permits.html `lengthMenu` and the CSV-export request, so
    #    every honest caller already lands inside the cap.
    try:    start = max(0, int(g.get('start', 0) or 0))
    except (TypeError, ValueError): start = 0
    try:
        length = int(g.get('length', 25) or 25)
    except (TypeError, ValueError):
        length = 25
    _MAX_PAGE = 500
    if length < 0 or length > _MAX_PAGE:
        length = _MAX_PAGE

    page, records_total, records_filtered = query_permits_for_dashboard(
        city_set         = _user_city_set,
        history_days     = _history_days,
        f_state          = f_state,
        f_city           = f_city,
        f_trade          = f_type,
        f_status         = f_status,
        f_score_min      = f_score_min,
        f_score_max      = f_score_max,
        f_owner          = f_owner,
        f_phone_digits   = f_phone_d,
        f_email          = f_email,
        f_issued_after   = f_iafter,
        f_expires_before = f_ebefore,
        f_keyword        = f_kw,
        f_tier           = f_tier,
        f_search         = g_search,
        sort_key         = sort_key,
        sort_dir         = sort_dir,
        start            = start,
        length           = length,
    )

    try:    draw = int(g.get('draw', 1) or 1)
    except (TypeError, ValueError): draw = 1

    # `recordsFiltered` is the true post-filter total from Postgres,
    # never `len(page)` — that's how DataTables learns the request
    # was clamped (500 rows of N) and renders pagination correctly
    # instead of treating the first 500 as the full result set.
    return JsonResponse({
        'draw': draw,
        'recordsTotal':    records_total,
        'recordsFiltered': records_filtered,
        'data':            page,
    })


@login_required
@subscription_required
def permits(request):
    ctx     = _user_ctx(request)
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    raw     = user.get('cities', [])
    plan_cities, plan_states = [], set()
    for c in raw:
        c = c.strip()
        name, st = (c.rsplit(', ', 1) + [''])[:2] if ', ' in c else (c, _city_state(c))
        plan_cities.append({'name': name.strip(), 'state': st.strip()})
        if st: plan_states.add(st.strip())
    plan_states = sorted(plan_states)
    ctx['plan_cities_json'] = json.dumps(plan_cities)
    ctx['plan_states']      = plan_states
    # City freeze check
    plan       = user.get('plan', 'starter')
    city_limit = PLAN_CITY_LIMITS.get(plan, 1)
    cities_frozen = user.get('cities_frozen', False)
    ctx['cities_frozen'] = cities_frozen
    ctx['city_limit']    = city_limit
    ctx['city_excess']   = max(0, len(raw) - city_limit)
    # The /permits/ table is now loaded dynamically via DataTables AJAX
    # (`permits_data_view`) so the page render no longer needs to embed
    # the full permit list in the HTML — saves bandwidth and lets the
    # browser ask for one page at a time. We still resolve per-plan
    # feature flags + the history-window label here because the filter
    # panel and the "showing the last N days" banner are server-rendered.
    _plan_title    = plan.title() if plan.lower() in ('starter', 'pro', 'agency') else 'Starter'
    _plan_limits   = PLAN_USAGE_LIMITS.get(_plan_title, PLAN_USAGE_LIMITS['Starter'])
    _history_days  = _plan_limits.get('history_days')

    # Per-plan feature flags
    _feats = PLAN_FEATURES.get(_plan_title, PLAN_FEATURES['Starter'])
    ctx['can_export_csv']   = _feats['csv_export']
    ctx['can_filter_trade'] = _feats['trade_filter']
    ctx['history_days']     = _history_days

    response = render(request, 'core/permits.html', ctx)
    response['Cache-Control'] = 'no-store'
    return response

def _build_user_cities(raw: list) -> list:
    result = []
    for i, entry in enumerate(raw):
        entry = entry.strip()
        if ', ' in entry:
            parts2 = entry.rsplit(', ', 1)
            city_name, state_abbr = parts2[0].strip(), parts2[1].strip()
        else:
            city_name  = entry
            state_abbr = _city_state(entry)
        result.append({
            'name':     city_name,
            'state':    state_abbr,
            'entry':    entry,
            'count':    max(3, 15 - i * 2),
            'selected': True,
        })
    return result


@login_required
@subscription_required
def settings_view(request):
    ctx     = _user_ctx(request)
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}

    # ── Sync plan from DB — trust DB over stale session ────────
    _db_plan = user.get('plan', 'starter').title()
    if _db_plan != ctx.get('user_plan'):
        ctx['user_plan'] = _db_plan
        request.session['user_plan'] = _db_plan

    raw_cities  = user.get('cities', [])
    user_cities = _build_user_cities(raw_cities)

    _user_plan   = ctx['user_plan']
    _city_limit  = PLAN_CITY_LIMITS.get(_user_plan, 1)
    _city_count  = len(user_cities)
    _cities_frozen = user.get('cities_frozen', False)
    # Mark which cities are over the limit (the ones beyond index city_limit-1)
    for i, c in enumerate(user_cities):
        c['overflow'] = _cities_frozen and i >= _city_limit

    ctx['cities']          = user_cities
    ctx['city_count']      = _city_count
    ctx['city_limit']      = _city_limit
    ctx['cities_remaining']= max(0, _city_limit - _city_count)
    ctx['cities_frozen']   = _cities_frozen
    ctx['city_excess']     = max(0, _city_count - _city_limit)

    # ── Usage stats (sync from DB, default if missing) ────────────
    _limits     = PLAN_USAGE_LIMITS.get(_user_plan, PLAN_USAGE_LIMITS['Starter'])
    _alerts     = user.get('alerts_sent', 0)
    _api        = user.get('api_calls',   0)
    _city_lim   = _limits['cities']
    _alert_lim  = _limits['alerts']
    _api_lim    = _limits['api']

    ctx['alerts_sent']      = f'{_alerts:,}'
    ctx['alerts_limit']     = _fmt_num(_alert_lim)
    ctx['alerts_pct']       = _usage_pct(_alerts, _alert_lim)
    ctx['alerts_used_pct']  = f'{_usage_pct(_alerts, _alert_lim)}%' if _alert_lim else '—'

    ctx['api_calls']        = _fmt_num(_api)
    ctx['api_limit']        = _fmt_num(_api_lim)
    ctx['api_pct']          = _usage_pct(_api, _api_lim)
    ctx['api_included']     = _api_lim != 0

    ctx['city_pct']         = _usage_pct(_city_count, _city_lim)
    ctx['city_names_preview'] = ', '.join(
        c.split(',')[0].strip() for c in user.get('cities', [])[:2]
    ) or '—'

    name  = user.get('name', '').strip()
    parts = name.split(' ', 1)
    ctx['first_name']     = parts[0] if parts else ''
    ctx['last_name']      = parts[1] if len(parts) > 1 else ''
    ctx['company']        = user.get('company', '')
    ctx['bill_company']   = user.get('bill_company',   user.get('company', ''))
    ctx['bill_tax_id']    = user.get('bill_tax_id',    '')
    ctx['bill_street']    = user.get('bill_street',    '')
    ctx['bill_city']      = user.get('bill_city',      '')
    ctx['bill_state_zip'] = user.get('bill_state_zip', '')

    # ── Active sessions ────────────────────────────────────────
    raw_sessions = get_sessions_for_user(user_id)
    current_key  = request.session.session_key
    session_list = []
    for s in sorted(raw_sessions, key=lambda x: x.get('last_seen', ''), reverse=True):
        session_list.append({
            'id':       s['id'],
            'device':   s.get('device', 'Unknown Device'),
            'ip':       s.get('ip', '—'),
            'last_seen_raw': s.get('last_seen', ''),
            'last_seen': _time_ago(s.get('last_seen', '')),
            'created_at': _time_ago(s.get('created_at', '')),
            'is_current': s.get('session_key') == current_key,
        })
    ctx['user_sessions']   = session_list
    ctx['session_count']   = len(session_list)

    # ── Login history ──────────────────────────────────────────
    raw_history = get_login_history_for_user(user_id, limit=20)
    login_history = []
    for h in raw_history:
        ts_raw = h.get('ts', '') or ''
        ts_display = ts_raw  # safe fallback
        # Strip trailing 'Z' that some legacy rows may have, then drop the
        # microseconds tail so ``fromisoformat`` works on every Python.
        clean = ts_raw.rstrip('Z')
        if '.' in clean:
            clean = clean.split('.', 1)[0]
        try:
            dt = datetime.fromisoformat(clean)
            # ``%-I`` is GNU-only — manually strip the leading zero so the
            # format works the same on every libc (Alpine, musl, BSD, etc).
            hour_12 = dt.hour % 12 or 12
            ampm    = 'AM' if dt.hour < 12 else 'PM'
            ts_display = dt.strftime('%b %d, %Y · ') + f"{hour_12}:{dt.minute:02d} {ampm}"
        except Exception:
            pass
        login_history.append({
            'ts':     ts_display,
            'device': h.get('device', 'Unknown'),
            'ip':     h.get('ip', '—'),
            'status': h.get('status', 'success'),
        })
    ctx['login_history'] = login_history

    ctx['totp_enabled'] = bool(user.get('totp_enabled'))

    # ── Whop membership data (DB-cached, no live API call) ───────
    # Snapshot is kept fresh by _snapshot_whop_to_user, called from
    # ls_success (after payment) and the Whop webhook (membership.went_*).
    # This used to make a live wp.get_membership() call here that cost
    # 300-800ms on every settings page load.
    whop_mem_id = user.get('whop_membership_id')
    whop_info   = _build_whop_info_from_user(user)
    ctx['ls_info']    = whop_info        # keep template key for compatibility
    ctx['ls_sub_id']  = whop_mem_id or ''
    # `whop_membership_id` is intentionally retained as a historical
    # breadcrumb after cancel/expire (so admins can audit what the user
    # used to have). The settings billing card must therefore gate on
    # `subscription_active`, otherwise a deactivated user would still
    # see the "active subscription" controls (Cancel / Update payment /
    # Downgrade) for a subscription that no longer exists.
    ctx['has_ls_sub'] = bool(whop_mem_id and whop_info
                             and user.get('subscription_active'))

    # ── Affiliate / referral context ─────────────────────────────
    # Lazily mint a referral code the first time the user opens Settings,
    # so we never burn codes on accounts that never visit the page.
    try:
        _ref_code = ensure_referral_code(user_id)
    except Exception:
        _ref_code = ''
    _ref_stats   = get_referral_stats_for_user(user_id) if _ref_code else \
                   {'signups': 0, 'paid': 0, 'earnings_cents': 0}
    _ref_list    = get_referees_for_user(user_id)       if _ref_code else []
    _ref_pct_raw = get_system_setting('affiliate_commission_pct', 20)
    try:
        _ref_pct = int(_ref_pct_raw)
    except (TypeError, ValueError):
        _ref_pct = 20
    # Use only Django's validated host (vetted against ALLOWED_HOSTS) — never
    # the raw Origin header, which is attacker-controlled and would let a
    # crafted request poison every share link rendered in the affiliate tab.
    _origin = (('https://' if request.is_secure() else 'http://') +
               request.get_host()).rstrip('/')
    ctx['referral_code']         = _ref_code
    ctx['referral_link']         = f'{_origin}/r/{_ref_code}/' if _ref_code else ''
    ctx['referral_signups']      = _ref_stats['signups']
    ctx['referral_paid']         = _ref_stats['paid']
    ctx['referral_earnings']     = f"${_ref_stats['earnings_cents']/100:,.2f}"
    ctx['referral_commission_pct'] = _ref_pct
    # Render-friendly per-referee list for the table
    _ref_rows = []
    for r in _ref_list:
        em = (r.get('email') or '').strip()
        local, _, domain = em.partition('@')
        masked = (local[:1] + '***@' + domain) if local and domain else em
        _ref_rows.append({
            'masked_email':  masked,
            'plan':          (r.get('plan') or 'starter').title(),
            'paid':          bool(r.get('first_paid_at')),
            'earnings':      f"${r.get('earnings_cents', 0)/100:,.2f}",
            'signed_up_at':  (r.get('signed_up_at').strftime('%b %d, %Y')
                              if r.get('signed_up_at') else '—'),
        })
    ctx['referral_rows'] = _ref_rows

    # ── Cross-check: if Whop plan differs from DB plan, Whop wins ──────────
    # …but never let an apparent DOWNGRADE win silently. Same reasoning
    # as in `_whop_login_sync`: when the bound membership detects a
    # lower tier than what we have stored, it's almost always because
    # we're bound to the user's OLD membership during an upgrade
    # transition. Only the webhook (went_invalid / scheduled
    # pending_downgrade) is allowed to actually downgrade the plan.
    if whop_info:
        wp_detected = whop_info.get('plan', '').lower()
        db_plan     = user.get('plan', '').lower()
        if (wp_detected and wp_detected != db_plan
                and not _is_plan_downgrade(wp_detected, db_plan)):
            update_user(user_id, plan=wp_detected)
            ctx['user_plan']             = wp_detected.title()
            request.session['user_plan'] = wp_detected.title()

    # ── Invoices ──────────────────────────────────────────────
    # No live wp.get_membership() / billing-sync call here — billing
    # rows are written by the webhook on renewal and by ls_success on
    # initial purchase. Settings page just renders whatever's already
    # in the DB so it costs ~one cached query, not a 300-800 ms Whop
    # round-trip on every load.
    ctx['ls_invoices'] = get_user_invoices(user_id)

    # ── Billing period progress for UI ─────────────────────────
    from datetime import timezone as _tz
    _bps = user.get('billing_period_start') or ''
    _bpe = user.get('billing_period_end')   or ''
    _ss  = user.get('subscription_start')   or ''
    ctx['billing_period_start']   = _bps
    ctx['billing_period_end']     = _bpe
    ctx['subscription_start']     = _ss

    # Compute % through current billing period
    _bp_pct = 0
    _bp_days_left = ''
    if _bps and _bpe:
        try:
            from datetime import datetime
            _s = datetime.fromisoformat(_bps)
            _e = datetime.fromisoformat(_bpe)
            _n = datetime.now(_tz.utc).replace(tzinfo=None)
            _total = (_e - _s).days or 1
            _elapsed = max(0, min(_total, (_n - _s).days))
            _bp_pct = round(_elapsed * 100 / _total)
            _left   = max(0, (_e - _n).days)
            _bp_days_left = f'{_left} day{"s" if _left != 1 else ""} left'
        except Exception:
            pass
    ctx['billing_period_pct']      = _bp_pct
    ctx['billing_period_days_left'] = _bp_days_left

    # Pass supported cities as JSON for the city-add modal STATE_CITIES object
    _supported = get_supported_cities()
    _state_cities: dict = {}
    for _sc in _supported:
        _state_cities.setdefault(_sc['state'], []).append(_sc['city'])
    ctx['state_cities_json'] = json.dumps({
        _FULL_STATE_NAMES.get(st, st): sorted(cities)
        for st, cities in _state_cities.items()
    })

    # Validate pending_downgrade is truly a downgrade from current plan
    _RANK = {'starter': 0, 'pro': 1, 'agency': 2}
    _pd   = user.get('pending_downgrade') or {}
    _cur_rank = _RANK.get(ctx['user_plan'].lower(), 0)
    if _pd:
        _pd_rank = _RANK.get(_pd.get('plan', '').lower(), 0)
        if _pd_rank >= _cur_rank:
            update_user(user_id, pending_downgrade=None)
            _pd = {}
    ctx['pending_downgrade'] = _pd if _pd else None

    # ── Alert preferences ──────────────────────────────────────
    _default_prefs = {'daily_digest': True, 'hot_lead_alerts': True,
                      'slack_alerts': False, 'weekly_report': True,
                      'new_city_alerts': True}
    saved_prefs = user.get('alert_prefs', {})
    ctx['alert_prefs'] = {k: saved_prefs.get(k, v) for k, v in _default_prefs.items()}

    # ── CRM integrations (OAuth + Zapier) ──────────────────────
    crm = get_crm_integrations(user_id)
    ctx['crm_integrations'] = {
        'hubspot': {
            'connected':       bool(crm.get('hubspot', {}).get('access_token')),
            'configured':      _integrations.oauth_provider_configured('hubspot'),
            'connected_at':    crm.get('hubspot', {}).get('connected_at'),
            'account_label':   crm.get('hubspot', {}).get('account_label') or crm.get('hubspot', {}).get('hub_id') or '',
        },
        'ghl': {
            'connected':       bool(crm.get('ghl', {}).get('access_token')),
            'configured':      _integrations.oauth_provider_configured('ghl'),
            'connected_at':    crm.get('ghl', {}).get('connected_at'),
            'account_label':   crm.get('ghl', {}).get('account_label') or crm.get('ghl', {}).get('locationId') or '',
        },
        'zapier': {
            'webhook_url':     crm.get('zapier', {}).get('webhook_url') or '',
            'connected':       bool(crm.get('zapier', {}).get('webhook_url')),
        },
    }

    # Mode-aware pricing on the settings/billing page so the user always
    # sees the prices that match what their checkout will actually charge.
    ctx['pricing'] = wp.get_pricing_dict(wp.mode_for_user(user))

    return render(request, 'core/settings.html', ctx)


@login_required
def clear_login_history(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user_id = request.session.get('user_id')
    removed = clear_login_history_for_user(user_id)
    return JsonResponse({'ok': True, 'removed': removed})


@login_required
def save_alert_prefs(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user_id = request.session.get('user_id')
    prefs = {
        'daily_digest':    request.POST.get('daily_digest') == '1',
        'hot_lead_alerts': request.POST.get('hot_lead_alerts') == '1',
        'slack_alerts':    request.POST.get('slack_alerts') == '1',
        'weekly_report':   request.POST.get('weekly_report') == '1',
        'new_city_alerts': request.POST.get('new_city_alerts') == '1',
    }
    update_user(user_id, alert_prefs=prefs)
    return JsonResponse({'ok': True})


# ── Whop checkout / membership views ─────────────────────────────────────

@login_required
@require_http_methods(['GET'])
def ls_checkout(request):
    """
    Returns JSON {url} for the frontend to open a new tab to Whop checkout.
    Guards against duplicate memberships — if the user already has an active
    Whop membership, block new checkout and redirect to Whop Hub instead.
    """
    plan   = request.GET.get('plan', 'starter').lower()
    period = request.GET.get('period', 'monthly').lower()
    if plan not in ('starter', 'pro', 'agency'):
        return JsonResponse({'ok': False, 'error': 'Invalid plan'}, status=400)
    if period not in ('monthly', 'annual'):
        period = 'monthly'
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    email   = user.get('email', '')

    # Guard: block new checkout if an active membership already exists
    if email and user.get('whop_membership_id'):
        try:
            mem = wp.get_membership(user['whop_membership_id'])
            if mem and mem.get('valid'):
                return JsonResponse({
                    'ok':      False,
                    'has_sub': True,
                    'error':   'You already have an active subscription. Use the plan switcher or Manage Billing to make changes.',
                    'portal':  True,
                })
        except Exception:
            pass

    # Use embedded checkout page instead of redirecting to Whop
    embed_url = f'/billing/embed/?plan={plan}&period={period}&back=/settings/%23billing'
    if request.GET.get('redirect'):
        return redirect(embed_url)
    return JsonResponse({'ok': True, 'url': embed_url})


_PLAN_META = {
    ('starter', 'monthly'): {'label': 'Starter', 'period_label': 'Monthly · 1 city',
                              'features': ['Daily permit alerts for 1 city', 'Up to 30 alerts/month', 'AI lead score (grade tier)', '7-day permit history', 'Email delivery']},
    ('starter', 'annual'):  {'label': 'Starter', 'period_label': 'Annual · 1 city',
                              'features': ['Daily permit alerts for 1 city', 'Up to 30 alerts/month', 'AI lead score (grade tier)', '7-day permit history', 'Email delivery', 'Save 20% vs monthly']},
    ('pro',     'monthly'): {'label': 'Pro',     'period_label': 'Monthly · up to 5 cities',
                              'features': ['Everything in Starter', 'Up to 5 cities', 'Up to 300 alerts/month', 'Full AI score (0–100)', '90-day permit history', 'Trade filtering + CSV export', 'Priority support']},
    ('pro',     'annual'):  {'label': 'Pro',     'period_label': 'Annual · up to 5 cities',
                              'features': ['Everything in Starter', 'Up to 5 cities', 'Up to 300 alerts/month', 'Full AI score (0–100)', '90-day permit history', 'Trade filtering + CSV export', 'Priority support', 'Save 20% vs monthly']},
    ('agency',  'monthly'): {'label': 'Agency',  'period_label': 'Monthly · up to 15 cities',
                              'features': ['Everything in Pro', '15 cities (add more at $20/city)', 'Unlimited alerts', 'Full permit history archive', 'REST API + webhook integration', 'Slack, SMS & webhook alert channels', 'White-label export', 'Dedicated onboarding call']},
    ('agency',  'annual'):  {'label': 'Agency',  'period_label': 'Annual · up to 15 cities',
                              'features': ['Everything in Pro', '15 cities (add more at $20/city)', 'Unlimited alerts', 'Full permit history archive', 'REST API + webhook integration', 'Slack, SMS & webhook alert channels', 'White-label export', 'Dedicated onboarding call', 'Save 20% vs monthly']},
}


def _get_plan_pricing(plan: str, period: str, mode: str = None) -> dict:
    """Build mode-aware pricing dict for the embed checkout view.

    ``mode`` defaults to the global setting when omitted; pass the
    user's ``whop_mode`` so admins-flagged-as-dev see $1 / mo on the
    embed page (matching the dev plan_id they're being routed to).
    """
    key = (plan, period)
    meta = _PLAN_META.get(key, _PLAN_META[('starter', 'monthly')])
    price  = wp.get_plan_price(plan, period, mode)
    if period == 'annual':
        billed = f'Billed ${price * 12:,} today · save 20%'
    else:
        billed = 'Billed monthly · cancel anytime'
    return {
        'price':        price,
        'unit':         'mo',
        'billed':       billed,
        'label':        meta['label'],
        'period_label': meta['period_label'],
        'features':     meta['features'],
    }


@login_required
@require_http_methods(['GET'])
def ls_embed_checkout(request):
    """Render an embedded Whop checkout page using the Whop loader script."""
    plan   = request.GET.get('plan', 'starter').lower()
    period = request.GET.get('period', 'monthly').lower()
    if plan not in ('starter', 'pro', 'agency'):
        plan = 'starter'
    if period not in ('monthly', 'annual'):
        period = 'monthly'

    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    email   = user.get('email', '')

    # Per-user Whop billing mode: an admin-flagged 'dev' user gets routed
    # to the $1 dev plan_id (and dev pricing display) without flipping
    # the global mode for everybody else. See core/whop.mode_for_user().
    user_mode = wp.mode_for_user(user)
    plan_id   = wp.get_plan_id(plan, period, user_mode)
    if not plan_id:
        # Whop plan_id for this plan/period isn't configured in admin yet.
        # Bounce to the paywall and surface a clear, actionable banner
        # there (instead of silently looping back).
        return redirect(f'/paywall/?missing_plan={plan}_{period}')

    dev_domain = os.environ.get('REPLIT_DEV_DOMAIN', '')
    domain  = f'https://{dev_domain}' if dev_domain else request.build_absolute_uri('/').rstrip('/')
    return_url = domain + f'/billing/success/?plan={plan}&period={period}'

    pricing = _get_plan_pricing(plan, period, user_mode)
    # Validate back_url — only allow same-origin paths to prevent XSS via javascript:/data: URLs
    raw_back = request.GET.get('back', '') or ''
    back_url = raw_back if (raw_back.startswith('/') and not raw_back.startswith('//')) else '/settings/#billing'

    ctx = {
        'plan_id':       plan_id,
        'plan':          plan,
        'period':        period,
        'plan_label':    pricing['label'],
        'period_label':  pricing['period_label'],
        'price_display': pricing['price'],
        'price_unit':    pricing['unit'],
        'billed_text':   pricing['billed'],
        'features':      pricing['features'],
        'return_url':    return_url,
        'email':         email,
        'user_id':       user_id or '',
        'back_url':      back_url,
    }
    return render(request, 'core/embed_checkout.html', ctx)


@login_required
@require_http_methods(['GET'])
def ls_success(request):
    """Post-checkout landing page.

    Whop redirects the customer here with `?membership_id={id}` filled
    in from the per-plan checkout-link redirect URL configured in the
    Whop dashboard. We fetch THAT specific membership by id (one
    deterministic API call, no eventual-consistency race) and bind it
    to the user. Email-lookup fallback is preserved for any legacy
    checkout link that still doesn't carry the placeholder.
    """
    plan      = request.GET.get('plan', '').lower()
    mem_id_qs = (request.GET.get('membership_id') or '').strip()
    user_id   = request.session.get('user_id')
    user      = get_user_by_id(user_id) or {}
    email     = user.get('email', '')

    # NOTE: we deliberately do NOT call `update_user(user_id, plan=plan)`
    # here. The URL `?plan=` is attacker-controlled — anyone can land on
    # `/billing/success/?plan=agency` without paying a cent. The plan
    # field is only updated below, and only after we've verified the
    # membership against the user's email via Whop.

    # ── Fast path: Whop sent us the exact membership_id in the redirect.
    # `wp.get_membership(id)` is a single API call and the id can never
    # be a stale-older membership — Whop minted it for THIS checkout.
    #
    # SECURITY: the membership_id is attacker-controlled (it sits in a
    # URL query param). We MUST verify the membership actually belongs
    # to the currently-logged-in user before binding it, otherwise any
    # user could send themselves to
    #   /billing/success/?membership_id=mem_someone_elses_agency_sub
    # and inherit a paid Agency subscription. We also require the
    # membership to be `valid` so a known-but-cancelled id can't
    # reactivate the account.
    chosen = None
    if mem_id_qs and email:
        try:
            candidate = wp.get_membership(mem_id_qs)
        except Exception:
            candidate = None
        if candidate:
            mem_email = (candidate.get('email') or '').strip().lower()
            user_email_lc = email.strip().lower()
            if mem_email and mem_email == user_email_lc and candidate.get('valid'):
                chosen = candidate
            else:
                import logging
                logging.getLogger(__name__).warning(
                    "ls_success: rejected membership_id=%r for user_id=%s "
                    "(mem_email=%r vs user_email=%r, valid=%r)",
                    mem_id_qs, user_id, mem_email, user_email_lc,
                    candidate.get('valid'),
                )

    # ── Fallback: legacy checkout links that don't carry the
    # `{membership_id}` placeholder yet. Same email-lookup-with-retry
    # path the previous implementation used. Once all 6 Whop checkout
    # links have the placeholder this branch never executes.
    #
    # SECURITY: `get_memberships_by_email()` intentionally keeps rows
    # with a blank `email` field because Whop's v2 search is fuzzy.
    # That means we can't trust the lookup as proof of ownership on
    # its own — re-verify the returned membership's email matches the
    # logged-in user (same guard as the fast path) before activating.
    if chosen is None and email and plan in ('starter', 'pro', 'agency'):
        try:
            candidate = _wait_for_paid_membership(email, plan_hint=plan)
        except Exception:
            candidate = None
        if candidate:
            mem_email = (candidate.get('email') or '').strip().lower()
            user_email_lc = email.strip().lower()
            if mem_email and mem_email == user_email_lc and candidate.get('valid'):
                chosen = candidate
            else:
                import logging
                logging.getLogger(__name__).warning(
                    "ls_success: rejected fallback membership for user_id=%s "
                    "(mem_email=%r vs user_email=%r, valid=%r)",
                    user_id, mem_email, user_email_lc, candidate.get('valid'),
                )

    if chosen:
        # Detect plan from the membership; fall back to the URL hint if
        # detection fails (e.g. a brand-new plan_id the admin hasn't
        # added to /admin-panel/whop-settings/ yet).
        detected = wp.plan_from_membership(chosen, default='') or plan
        if detected not in ('starter', 'pro', 'agency'):
            detected = plan or 'starter'
        update_user(user_id,
                    whop_membership_id=chosen.get('id', ''),
                    plan=detected,
                    whop_cancelled=chosen.get('cancel_at_period_end', False),
                    subscription_active=True,
                    onboarding_complete=True,
                    whop_resync_pending=False)
        request.session['user_plan'] = detected.title()
        try:
            _snapshot_whop_to_user(user_id, chosen)
        except Exception:
            pass
        try:
            _sync_billing_and_invoice(user_id, chosen)
        except Exception:
            pass
        # Branded payment-success / activation receipt — fires on every
        # successful Whop bind, including upgrades and re-activations.
        # The dedup helper stamps (membership_id, plan) on the user so
        # the matching ``membership.went_valid`` webhook (which also
        # calls this helper) becomes a no-op — guarantees exactly one
        # receipt across the redirect/webhook race. If the user closes
        # the browser before this redirect runs, the webhook still
        # delivers the email from its own call site below.
        try:
            _maybe_fire_payment_success_email(
                user_id, chosen.get('id', ''), detected, chosen, request,
            )
        except Exception:
            log.exception("payment-success dispatch failed for user_id=%s", user_id)
    else:
        # Couldn't verify a membership against Whop. Do NOT grant
        # `subscription_active=True` from the URL plan hint alone —
        # `?plan=` is attacker-controlled and the previous code path
        # would silently upgrade anyone who landed here. Mark the
        # account as awaiting verification; the Whop webhook (or an
        # admin sync from `/admin-panel/users/`) will activate the
        # subscription when Whop catches up. Worst case: the user
        # sees a "we're confirming your payment" state for a few
        # seconds until the webhook fires.
        update_user(user_id, whop_resync_pending=True)
        import logging
        logging.getLogger(__name__).warning(
            "ls_success: could not verify membership for user_id=%s "
            "(mem_id_qs=%r, plan_hint=%r). Awaiting webhook.",
            user_id, mem_id_qs, plan,
        )

    return render(request, 'core/ls_success.html', {'plan': (plan or 'your').title()})


@login_required
@require_http_methods(['POST', 'GET'])
def ls_sync(request):
    """No-op as of the bind-from-redirect change.

    The user-facing "Sync Now" button no longer hits the Whop API.
    Membership binding now happens deterministically at checkout time
    (`ls_success` reads `?membership_id=` from the Whop redirect) and
    is updated by the webhook for downstream state changes.

    If a customer genuinely needs a manual Whop refresh, an admin can
    run it from `/admin-panel/users/` via the per-user resync action
    or the bulk Whop sync — those endpoints still call Whop directly.
    Keeping this route as a no-op (instead of removing it) so the
    settings UI's existing Sync button and any external scripts keep
    returning a 200 instead of a 404.
    """
    next_url = request.GET.get('next', '')
    user_id  = request.session.get('user_id')
    user     = get_user_by_id(user_id) or {}
    plan     = (user.get('plan') or 'starter').title()
    active   = bool(user.get('subscription_active'))
    if next_url and next_url.startswith('/'):
        return redirect(next_url)
    # `ok` reflects the actual cached subscription state so the
    # post-checkout polling page on `ls_success.html` only shows
    # "Subscription connected" when the user really is connected.
    # If the membership couldn't be verified at checkout, the page
    # keeps polling (max 5 attempts) until the webhook flips
    # subscription_active=True or the timeout message appears.
    return JsonResponse({
        'ok':   active,
        'plan': plan,
        'msg':  (f'Plan: {plan}.' if active else
                 'Still confirming your payment with Whop\u2026'),
    })


@login_required
@require_http_methods(['GET'])
def ls_portal(request):
    return redirect('https://whop.com/hub/')


@login_required
@require_http_methods(['POST'])
def ls_cancel(request):
    """Cancel-at-period-end. The user keeps access until the next renewal
    date (which they've already paid for) and is then dropped.

    We only mark the local DB as ``whop_cancelled`` AFTER the Whop API
    confirms the cancel. Previously this view caught every exception and
    flipped the local flag regardless — so a 404/500 from Whop would
    leave the subscription active in Whop while the UI told the user
    "you're cancelled", causing surprise renewals next month.
    """
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    email   = (user.get('email') or '').strip()
    mem_id  = user.get('whop_membership_id')

    # Loop over EVERY active membership tied to this email — not just the
    # one we have on file — so historical orphans (from past flows that
    # left a stale active sub in Whop) get swept up too. Otherwise the
    # user keeps getting billed for memberships they never see in our UI.
    result = wp.cancel_all_active_for_email(
        email,
        immediate=False,
        extra_membership_ids=[mem_id] if mem_id else None,
    )

    # Nothing was active anywhere → nothing to cancel.
    if result['discovered'] == 0:
        return JsonResponse({'ok': False, 'error': 'No active subscription found.'})

    # Some (or all) cancellations failed → surface to the user, do not
    # flip the local flag. Whatever DID succeed is reported in the body
    # so they can see partial progress.
    if result['errors']:
        return JsonResponse({
            'ok':       False,
            'error':    "We couldn't cancel one or more of your subscriptions. Please try again or contact support.",
            'cancelled': result['cancelled'],
            'failed':    list(result['errors'].keys()),
            'detail':    ' | '.join(f'{k}: {v}' for k, v in result['errors'].items()),
        }, status=502)

    # Every active membership cancelled cleanly.
    update_user(user_id, whop_cancelled=True)
    n = len(result['cancelled'])
    msg = ('Subscription cancelled. Access continues until the end of your billing period.'
           if n == 1 else
           f'{n} subscriptions cancelled. Access continues until the end of each billing period.')
    return JsonResponse({'ok': True, 'msg': msg, 'cancelled_count': n, 'cancelled': result['cancelled']})


@login_required
@require_http_methods(['POST'])
def ls_pause(request):
    return JsonResponse({'ok': False, 'error': 'Pausing is not supported with Whop. Please cancel and resubscribe when ready.'}, status=400)


@login_required
@require_http_methods(['POST'])
def ls_change_plan(request):
    """Switch plans by terminating the old subscription, then routing
    the user to a fresh Whop checkout for the new plan.

    Same code path for upgrade, downgrade, and period switch — keeps
    the state machine simple and avoids "two memberships at once" or
    "Whop says one thing, our DB says another" race conditions.

    Steps:
      1. Cancel the user's current Whop membership (best-effort —
         if it's already cancelled or missing, we still proceed).
      2. Reset local billing state so the user has no entitlement
         until the new payment is confirmed.
      3. Return the embedded-checkout URL for the new plan. The
         frontend redirects the browser to it. ``ls_success`` then
         binds the brand-new membership_id from Whop's redirect.

    The frontend confirmation modal warns the user this is
    irreversible and that any unused time on the old plan is
    forfeited.
    """
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}

    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    new_plan = (data.get('plan') or '').lower()
    period   = (data.get('period') or 'monthly').lower()
    if new_plan not in ('starter', 'pro', 'agency'):
        return JsonResponse({'ok': False, 'error': 'Invalid plan.'})
    if period not in ('monthly', 'annual'):
        period = 'monthly'

    # 1) Terminate EVERY active membership tied to this email — not just
    #    the one we have on file. We use immediate=True because the user
    #    is paying for a new plan in the next step; leaving any old
    #    membership renewing would double-bill them. Sweeping by email
    #    also catches orphans created by past flows that left an active
    #    sub in Whop our DB never knew about.
    #
    #    If ANY cancellation fails we MUST stop here — forfeiting the
    #    user's plan locally while it stays active in Whop is exactly
    #    the bug the user originally reported.
    email  = (user.get('email') or '').strip()
    mem_id = user.get('whop_membership_id')
    sweep  = wp.cancel_all_active_for_email(
        email, immediate=True,
        extra_membership_ids=[mem_id] if mem_id else None,
    )
    if sweep['errors']:
        return JsonResponse({
            'ok':       False,
            'error':    "We couldn't cancel your current plan with our payment provider. No changes were made — please try again or contact support.",
            'cancelled': sweep['cancelled'],
            'failed':    list(sweep['errors'].keys()),
            'detail':    ' | '.join(f'{k}: {v}' for k, v in sweep['errors'].items()),
        }, status=502)

    # 2) Reset local entitlement. The user is "in transit" until
    #    they finish the new checkout. ls_success will populate
    #    everything correctly when the new membership lands.
    update_user(
        user_id,
        subscription_active=False,
        whop_cancelled=True,
        pending_downgrade=None,
    )

    # 3) Hand them off to the embedded checkout page for the new plan.
    checkout_url = (
        f'/billing/embed/?plan={new_plan}&period={period}'
        f'&back=/settings/%23billing'
    )
    return JsonResponse({
        'ok':            True,
        'checkout_url':  checkout_url,
        'old_cancelled': bool(mem_id),
    })


@login_required
@csrf_exempt
@require_http_methods(['POST'])
def ls_cancel_downgrade(request):
    """Undo the scheduled downgrade — user stays on their current plan."""
    is_ajax  = request.headers.get('Content-Type', '').startswith('application/json')
    user_id  = request.session.get('user_id')
    user     = get_user_by_id(user_id) or {}
    pd       = user.get('pending_downgrade')
    if not pd:
        if is_ajax:
            return JsonResponse({'ok': False, 'error': 'No pending downgrade found.'})
        return redirect('/settings/#billing')
    update_user(user_id, pending_downgrade=None)
    current_plan = (user.get('plan') or 'starter').title()
    if is_ajax:
        return JsonResponse({'ok': True, 'msg': f"Schedule removed — you're staying on {current_plan}."})
    return redirect('/dashboard/')


@login_required
@csrf_exempt
@require_http_methods(['POST'])
def ls_apply_downgrade(request):
    """Apply the scheduled downgrade immediately — switches plan right now."""
    is_ajax  = request.headers.get('Content-Type', '').startswith('application/json')
    user_id  = request.session.get('user_id')
    user     = get_user_by_id(user_id) or {}
    pd       = user.get('pending_downgrade')
    if not pd:
        if is_ajax:
            return JsonResponse({'ok': False, 'error': 'No pending downgrade found.'})
        return redirect('/settings/#billing')
    new_plan = pd.get('plan', '').lower()
    period   = pd.get('period', 'monthly').lower()
    if new_plan not in ('starter', 'pro', 'agency'):
        if is_ajax:
            return JsonResponse({'ok': False, 'error': 'Invalid pending plan.'})
        return redirect('/settings/#billing')

    # For Whop: just apply the local plan change — Whop billing handled on next renewal
    update_user(user_id, plan=new_plan, pending_downgrade=None)
    request.session['user_plan'] = new_plan.title()

    refreshed  = get_user_by_id(user_id) or {}
    city_count = len(refreshed.get('cities', []))
    city_limit = PLAN_CITY_LIMITS.get(new_plan, 1)
    frozen     = city_count > city_limit
    update_user(user_id, cities_frozen=frozen)

    if is_ajax:
        resp = {'ok': True, 'plan': new_plan,
                'msg': f'Switched to {new_plan.title()} immediately.'}
        if frozen:
            resp['frozen']     = True
            resp['city_limit'] = city_limit
            resp['city_count'] = city_count
            resp['excess']     = city_count - city_limit
        return JsonResponse(resp)

    # Form POST from dashboard — redirect appropriately
    if frozen:
        return redirect('/settings/#coverage')
    return redirect('/dashboard/')


@csrf_exempt
@require_http_methods(['POST'])
def ls_webhook(request):
    """Whop webhook handler."""
    sig = request.META.get('HTTP_X_WHOP_SIGNATURE', '') or request.META.get('HTTP_X_SIGNATURE', '')
    if not wp.verify_webhook_signature(request.body, sig):
        return HttpResponse('Invalid signature', status=403)
    try:
        event = json.loads(request.body)
    except Exception:
        return HttpResponse('Bad JSON', status=400)

    action   = event.get('action', '')
    data     = event.get('data', {})
    mem_id   = data.get('id', '')
    status   = data.get('status', '')
    valid    = data.get('valid', False)
    metadata = data.get('metadata') or {}
    user_obj = data.get('user') or {}
    email    = user_obj.get('email', '')
    cancel_at_end = data.get('cancel_at_period_end', False)

    # Try to find user_id from metadata first, then fall back to email lookup
    user_id_str = metadata.get('user_id', '')

    from datetime import datetime, timezone

    def _get_uid():
        if user_id_str:
            try:
                return int(user_id_str)
            except Exception:
                pass
        if email:
            u = get_user_by_email(email)
            if u:
                return u.get('id')
        return None

    uid = _get_uid()

    # SECURITY: when uid was resolved from custom metadata user_id, verify
    # the membership's email actually matches that user's stored email.
    # Without this, a user could pay at checkout with a different email
    # while we still bind the resulting membership to their account via
    # metadata — or worse, someone could pay with metadata pointing at
    # *another* user's account. The embedded-checkout page already shows
    # a "Paying as <email>" lock notice, but Whop's iframe is cross-origin
    # so the email field is not strictly disable-able from our side; this
    # webhook check is the actual enforcement layer.
    if uid and user_id_str:
        target_user  = get_user_by_id(uid) or {}
        target_email = (target_user.get('email') or '').strip().lower()
        paid_email   = (email or '').strip().lower()
        if target_email and paid_email and target_email != paid_email:
            import logging
            logging.warning(
                "ls_webhook: refusing to bind membership %s to user %s — "
                "paid email %r does not match account email %r",
                mem_id, uid, paid_email, target_email,
            )
            uid = None

    if uid:
        try:
            # default='' so the keyword/id fallback path returns "" when
            # it cannot identify the plan, instead of silently returning
            # 'starter'. This is the root-cause fix for the "I paid for
            # Agency but got Starter" upgrade bug — when the agency
            # plan_id wasn't pasted into /admin-panel/whop-settings/,
            # this webhook used to overwrite the correct plan that
            # ls_success had just set with 'starter'.
            detected_plan = wp.plan_from_membership(data, default='')

            user_data    = get_user_by_id(uid) or {}
            current_plan = (user_data.get('plan') or '').lower()
            pending_dg   = user_data.get('pending_downgrade') or {}

            if action == 'membership.went_valid':
                patch = {
                    'whop_membership_id':  mem_id,
                    'whop_cancelled':      cancel_at_end,
                    'subscription_active': True,
                    'onboarding_complete': True,
                }
                # Only set plan when detection actually identified one.
                # When it didn't, leave whatever ls_success (or a prior
                # webhook) wrote intact — never silently downgrade.
                if detected_plan:
                    patch['plan'] = detected_plan
                elif current_plan in ('starter', 'pro', 'agency'):
                    import logging
                    logging.warning(
                        "ls_webhook went_valid: plan undetectable for "
                        "membership %s (user %s) — keeping current plan %r. "
                        "Paste this membership's plan_id into "
                        "/admin-panel/whop-settings/ to fix detection.",
                        mem_id, uid, current_plan,
                    )

                # Apply pending downgrade if its date has passed
                if pending_dg:
                    sched_str = pending_dg.get('date', '')
                    try:
                        sched_dt = datetime.strptime(sched_str, '%Y-%m-%d')
                        today    = datetime.now(timezone.utc).replace(tzinfo=None)
                        if today >= sched_dt:
                            dg_plan = pending_dg.get('plan', '')
                            if dg_plan in ('starter', 'pro', 'agency'):
                                dg_limit   = PLAN_CITY_LIMITS.get(dg_plan, 1)
                                city_count = len(user_data.get('cities', []))
                                patch['plan']              = dg_plan
                                patch['cities_frozen']     = city_count > dg_limit
                                patch['pending_downgrade'] = None
                    except Exception:
                        pass

                update_user(uid, **patch)

                # Snapshot full Whop data so settings page renders from DB
                # only — no live wp.get_membership() call needed.
                _snapshot_whop_to_user(uid, data)

                # Branded payment-success / activation receipt. The dedup
                # helper guarantees we send AT MOST ONCE per
                # (user, membership_id, plan) tuple, so:
                #
                #   • redirect won the race → it already stamped, this
                #     no-ops silently. (Most common happy-path.)
                #   • redirect never ran (closed browser, off-platform
                #     upgrade, ls_success couldn't verify the membership)
                #     → this is the ONLY path that delivers the receipt
                #     and the bug fix this branch was added for.
                #   • Whop sends went_valid for every billing-cycle
                #     renewal → same (mem_id, plan), skipped, no spam.
                #
                # Wrapped in try/except because Whop retries non-2xx
                # responses and we never want a template render glitch
                # to loop the webhook.
                try:
                    _email_plan = (patch.get('plan') or current_plan or '').lower()
                    _maybe_fire_payment_success_email(
                        uid, mem_id, _email_plan, data, request,
                    )
                except Exception:
                    import logging
                    logging.exception(
                        "payment-success dispatch failed in webhook for "
                        "user=%s membership=%s", uid, mem_id,
                    )

                # Affiliate commission: credit the referrer (if any) the
                # first time this user transitions to a *paid* plan. This
                # is gated by the per-user idempotency flag inside
                # ``credit_referral_first_payment``, so subsequent
                # ``went_valid`` events (renewals, plan changes) do not
                # double-pay. We only credit on real paid plans.
                _credit_plan = (patch.get('plan') or current_plan or '').lower()
                if _credit_plan in ('pro', 'agency') or (
                    _credit_plan == 'starter' and PLAN_PRICE.get('starter', 0) > 0
                ):
                    _price_cents = PLAN_PRICE.get(_credit_plan, 0) * 100
                    if _price_cents > 0:
                        try:
                            credit_referral_first_payment(
                                uid, _price_cents, membership_id=mem_id,
                            )
                        except Exception:
                            # Never fail the webhook over a referral credit
                            # — Whop will retry the whole event otherwise.
                            import logging
                            logging.exception(
                                "credit_referral_first_payment failed for "
                                "user %s membership %s", uid, mem_id,
                            )

            elif action == 'membership.cancelled':
                update_user(uid, whop_cancelled=True)

            elif action == 'membership.went_invalid':
                # Membership fully expired. Only act on this if it's the
                # user's *current* membership — otherwise we'd wipe out an
                # upgrade by reacting to the OLD (Pro/Starter) membership
                # going invalid after the user already moved to a new tier.
                current_mem = (user_data.get('whop_membership_id') or '')
                if current_mem and current_mem != mem_id:
                    # Stale event for a superseded membership — ignore.
                    pass
                else:
                    final_plan = pending_dg.get('plan', 'starter') if pending_dg else 'starter'
                    dg_limit   = PLAN_CITY_LIMITS.get(final_plan, 1)
                    city_count = len(user_data.get('cities', []))
                    update_user(uid,
                        whop_membership_id=None,
                        plan=final_plan,
                        cities_frozen=city_count > dg_limit,
                        pending_downgrade=None,
                        subscription_active=False,
                    )
        except Exception:
            pass

    return HttpResponse('OK', status=200)


@login_required
@require_http_methods(['POST'])
def revoke_session(request):
    user_id = request.session.get('user_id')
    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    session_id = data.get('session_id')
    if not session_id:
        return JsonResponse({'ok': False, 'error': 'Missing session_id'}, status=400)
    sessions = get_sessions_for_user(user_id)
    ids = {s['id'] for s in sessions}
    if int(session_id) not in ids:
        return JsonResponse({'ok': False, 'error': 'Session not found'}, status=404)
    delete_session_by_id(int(session_id))
    return JsonResponse({'ok': True})


@login_required
@require_http_methods(['POST'])
def revoke_all_sessions(request):
    user_id     = request.session.get('user_id')
    current_key = request.session.session_key
    count = delete_sessions_for_user(user_id, except_key=current_key)
    return JsonResponse({'ok': True, 'revoked': count})


# ── TOTP helpers ───────────────────────────────────────────────

def _totp_qr_data_url(secret: str, email: str) -> str:
    import pyotp, qrcode, io, base64
    uri = pyotp.totp.TOTP(secret).provisioning_uri(
        name=email, issuer_name='Permitlify')
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()


@login_required
@require_http_methods(['GET'])
def totp_setup_qr(request):
    import pyotp
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    secret  = user.get('totp_secret') or pyotp.random_base32()
    set_totp_secret(user_id, secret)
    formatted = ' '.join(secret[i:i+4] for i in range(0, len(secret), 4))
    return JsonResponse({
        'ok':        True,
        'secret':    secret,
        'formatted': formatted,
        'qr':        _totp_qr_data_url(secret, user.get('email', '')),
    })


@login_required
@require_http_methods(['POST'])
def totp_verify_enable(request):
    import pyotp
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    code   = str(data.get('code', '')).replace(' ', '').strip()
    secret = user.get('totp_secret', '')
    if not secret:
        return JsonResponse({'ok': False, 'error': 'No TOTP secret found. Refresh and try again.'})
    totp = pyotp.TOTP(secret)
    if totp.verify(code, valid_window=1):
        enable_totp(user_id)
        return JsonResponse({'ok': True})
    return JsonResponse({'ok': False, 'error': 'Incorrect code. Try again.'})


@login_required
@require_http_methods(['POST'])
def totp_disable(request):
    import pyotp
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    password = data.get('password', '')
    code     = str(data.get('code', '')).replace(' ', '').strip()
    if not authenticate_user(user.get('email', ''), password):
        return JsonResponse({'ok': False, 'error': 'Incorrect password.'})
    secret = user.get('totp_secret', '')
    if secret and code:
        totp = pyotp.TOTP(secret)
        if not totp.verify(code, valid_window=1):
            return JsonResponse({'ok': False, 'error': 'Incorrect authenticator code.'})
    disable_totp(user_id)
    return JsonResponse({'ok': True})


@require_http_methods(['GET', 'POST'])
def login_2fa(request):
    pending_id = request.session.get('totp_pending_user_id')
    if not pending_id:
        return redirect('login')
    error = None
    if request.method == 'POST':
        import pyotp
        code = request.POST.get('code', '').replace(' ', '').strip()
        user = get_user_by_id(pending_id) or {}
        secret = user.get('totp_secret', '')
        if secret and pyotp.TOTP(secret).verify(code, valid_window=1):
            ua  = request.session.get('totp_pending_ua', '')
            ip  = request.session.get('totp_pending_ip', '')
            dev = request.session.get('totp_pending_dev', '')
            for k in ['totp_pending_user_id','totp_pending_name','totp_pending_email',
                      'totp_pending_initials','totp_pending_plan','totp_pending_ua',
                      'totp_pending_ip','totp_pending_dev']:
                request.session.pop(k, None)
            # Refresh Whop billing state on 2FA-completed login too — same
            # email-first, 3-second-capped helper used by the email +
            # Google paths. Keeps plan badges everywhere in lock-step
            # with reality. Wrapped: a Whop / detection bug must never
            # break the 2FA login finalization — fall back to the
            # existing user.plan so the session still mints.
            try:
                _whop = _whop_login_sync(user['id'], user)
            except Exception:
                log.exception("_whop_login_sync failed for user %s (2fa login)", user.get('id'))
                _whop = {'plan': (user.get('plan') or 'starter')}
            request.session['user_id']       = user['id']
            request.session['user_name']     = user['name']
            request.session['user_email']    = user['email']
            request.session['user_initials'] = user.get('avatar_initials', user['name'][:2].upper())
            request.session['user_plan']     = (_whop['plan'] or 'starter').title()
            request.session.save()
            create_session(user_id=user['id'], session_key=request.session.session_key,
                           device=dev, ip=ip, ua=ua)
            _send_login_alert_if_new_device(
                user=user, request=request,
                method_label='Email + password (with 2FA)',
                device=dev, ip=ip, ua=ua,
            )
            record_login_event(user_id=user['id'], status='success',
                               device=dev, ip=ip, ua=ua)
            return redirect('dashboard')
        error = 'Incorrect code. Please try again.'
    return render(request, 'core/login_2fa.html', {'error': error})


@require_http_methods(['GET', 'POST'])
def login_verify_code(request):
    """Step 2 of email + password sign-in: enter the 6-digit code we
    just emailed.

    Hard rules:
      * Code expires after ``CODE_TTL_MINUTES`` (default 10 min).
      * ``CODE_MAX_ATTEMPTS`` wrong tries (default 5) burns the code —
        the user has to go back to /login/ and start over.
      * On success: drop all the ``email_code_pending_*`` session keys,
        mint the real session, refresh Whop, redirect to dashboard.
      * No pending state in session → bounce back to /login/.
    """
    from .auth_codes import verify_code, is_expired, CODE_TTL_MINUTES

    pending_id = request.session.get('email_code_pending_user_id')
    if not pending_id:
        return redirect('login')

    pending_email = request.session.get('email_code_pending_email', '') or ''
    expires_iso   = request.session.get('email_code_pending_expires_at', '')

    error  = None
    notice = None

    if request.method == 'POST':
        submitted = (request.POST.get('code') or '').strip().replace(' ', '')
        stored_hash = request.session.get('email_code_pending_code_hash', '')
        attempts    = int(request.session.get('email_code_pending_attempts', 0) or 0)

        if is_expired(expires_iso):
            error = 'This code has expired. Click "resend the code" below to get a fresh one.'
        elif attempts <= 0:
            error = 'Too many wrong attempts. Please sign in again to get a new code.'
            for k in list(request.session.keys()):
                if k.startswith('email_code_pending_'):
                    request.session.pop(k, None)
            return redirect('login')
        elif not submitted or len(submitted) != 6 or not submitted.isdigit():
            error = 'Please enter the 6-digit code from your email.'
            request.session['email_code_pending_attempts'] = attempts - 1
        elif not verify_code(submitted, stored_hash):
            remaining = attempts - 1
            request.session['email_code_pending_attempts'] = remaining
            if remaining <= 0:
                for k in list(request.session.keys()):
                    if k.startswith('email_code_pending_'):
                        request.session.pop(k, None)
                return redirect('login')
            error = f'Incorrect code. {remaining} attempt{"s" if remaining != 1 else ""} remaining.'
        else:
            # ── success ─────────────────────────────────────────────
            user = get_user_by_id(pending_id)
            if not user:
                # User was deleted/banned between step 1 and step 2 —
                # bail out cleanly instead of crashing on user['email'].
                for k in list(request.session.keys()):
                    if k.startswith('email_code_pending_'):
                        request.session.pop(k, None)
                return redirect('login')

            ua  = request.session.get('email_code_pending_ua', '')
            ip  = request.session.get('email_code_pending_ip', '')
            dev = request.session.get('email_code_pending_dev', '')

            for k in list(request.session.keys()):
                if k.startswith('email_code_pending_'):
                    request.session.pop(k, None)

            # ── session fixation defence ───────────────────────────
            # Rotate the session key the moment we elevate from
            # "anonymous, mid-flow" to "authenticated". Any cookie an
            # attacker may have managed to plant pre-auth becomes
            # worthless after this call. (Must run BEFORE we set the
            # user_id keys so the new keys land in the new session.)
            request.session.cycle_key()

            # Same Whop refresh dance as the password and TOTP paths so
            # the plan badge matches reality. Failure must never block
            # login finalisation.
            try:
                _whop = _whop_login_sync(user['id'], user)
            except Exception:
                log.exception("_whop_login_sync failed for user %s (email-code login)", user.get('id'))
                _whop = {'plan': (user.get('plan') or 'starter')}

            request.session['user_id']       = user['id']
            request.session['user_name']     = user['name']
            request.session['user_email']    = user['email']
            request.session['user_initials'] = user.get('avatar_initials', user['name'][:2].upper())
            request.session['user_plan']     = (_whop['plan'] or 'starter').title()
            request.session.save()
            create_session(user_id=user['id'], session_key=request.session.session_key,
                           device=dev, ip=ip, ua=ua)
            _send_login_alert_if_new_device(
                user=user, request=request,
                method_label='Email + password (with email code)',
                device=dev, ip=ip, ua=ua,
            )
            record_login_event(user_id=user['id'], status='success',
                               device=dev, ip=ip, ua=ua)
            return redirect('dashboard')

        # Refresh expiry view-model after a failed attempt
        expires_iso = request.session.get('email_code_pending_expires_at', '')

    # Build view model: expiry timestamp in ms (for the JS countdown)
    # and a masked email so the page can show "j••••@gmail.com" without
    # echoing the full address back from the URL.
    expires_at_ms = 0
    if expires_iso:
        try:
            from datetime import datetime as _dt, timezone as _tz
            dt = _dt.fromisoformat(expires_iso)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=_tz.utc)
            expires_at_ms = int(dt.timestamp() * 1000)
        except ValueError:
            expires_at_ms = 0

    masked = ''
    if pending_email and '@' in pending_email:
        local, _, domain = pending_email.partition('@')
        if len(local) <= 2:
            masked_local = (local[:1] or '') + '•' * max(1, 6 - len(local))
        else:
            masked_local = local[0] + '•' * min(6, max(1, len(local) - 2)) + local[-1]
        masked = f'{masked_local}@{domain}'

    return render(request, 'core/login_verify_code.html', {
        'error':                 error,
        'notice':                notice,
        'pending_email':         pending_email,
        'pending_email_masked':  masked,
        'expires_at_ms':         expires_at_ms,
        'ttl_minutes':           CODE_TTL_MINUTES,
    })


@require_http_methods(['POST'])
def login_verify_code_resend(request):
    """AJAX endpoint to send a fresh email code.

    Refuses if there's no pending login state (the user must go back
    to /login/ and re-enter their password). Resets the attempts
    counter and the 10-minute clock on success.
    """
    from .auth_codes import (
        generate_code, hash_code, expiry_iso, send_login_code_email,
        CODE_MAX_ATTEMPTS,
    )

    pending_id    = request.session.get('email_code_pending_user_id')
    pending_email = request.session.get('email_code_pending_email', '')
    pending_name  = request.session.get('email_code_pending_name', '')

    if not pending_id or not pending_email:
        return JsonResponse({'ok': False, 'error': 'No pending sign-in. Please sign in again.'}, status=400)

    # ── 60-second resend cooldown ───────────────────────────────────
    # Prevents email-bombing the recipient and burning Resend quota
    # if the resend link is hammered (intentionally or by a buggy
    # client). Stored in the session so it's per-flow, per-browser.
    from datetime import datetime as _dt, timezone as _tz
    last_iso = request.session.get('email_code_pending_last_send_at', '')
    if last_iso:
        try:
            last_dt = _dt.fromisoformat(last_iso)
            if last_dt.tzinfo is None:
                last_dt = last_dt.replace(tzinfo=_tz.utc)
            elapsed = (_dt.now(_tz.utc) - last_dt).total_seconds()
            if elapsed < 60:
                wait = int(60 - elapsed) + 1
                return JsonResponse(
                    {'ok': False, 'error': f'Please wait {wait}s before requesting another code.'},
                    status=429,
                )
        except ValueError:
            pass

    code = generate_code()
    ok, msg = send_login_code_email(
        to_email   = pending_email,
        to_name    = pending_name,
        code       = code,
        request_ip = request.session.get('email_code_pending_ip', ''),
        request_ua = request.session.get('email_code_pending_ua', ''),
    )
    if not ok:
        log.warning("email-code resend: transport down for %s (%s)", pending_email, msg)
        return JsonResponse({'ok': False, 'error': 'Could not send a new code right now. Try again in a moment.'}, status=503)

    request.session['email_code_pending_code_hash']    = hash_code(code)
    request.session['email_code_pending_expires_at']   = expiry_iso()
    request.session['email_code_pending_attempts']     = CODE_MAX_ATTEMPTS
    request.session['email_code_pending_last_send_at'] = _dt.now(_tz.utc).isoformat()
    return JsonResponse({'ok': True})


@login_required
@require_http_methods(['POST'])
def security_change_password(request):
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}
    new_pw     = request.POST.get('new_password', '')
    confirm_pw = request.POST.get('confirm_password', '')
    # See ``profile`` view: Google-only users (auth_provider == 'google')
    # have a random server-generated password they don't know, so the
    # first time they set one we skip the current-password gate and
    # flip auth_provider to 'local' afterwards.
    is_google_only = (user.get('auth_provider') == 'google')
    if not is_google_only:
        current_pw = request.POST.get('current_password', '')
        if not authenticate_user(user.get('email', ''), current_pw):
            return JsonResponse({'ok': False, 'error': 'Current password is incorrect.'})
    if len(new_pw) < 8:
        return JsonResponse({'ok': False, 'error': 'Password must be at least 8 characters.'})
    if new_pw != confirm_pw:
        return JsonResponse({'ok': False, 'error': 'Passwords do not match.'})
    if is_google_only:
        update_user(user_id, password=hash_password(new_pw), auth_provider='local')
    else:
        update_user(user_id, password=hash_password(new_pw))
    return JsonResponse({'ok': True})


@login_required
@require_http_methods(['POST'])
def security_account_action(request):
    action = request.POST.get('action', '')
    if action == 'pause':
        return JsonResponse({'ok': True, 'msg': 'Account paused. All alerts have stopped — resume anytime.'})
    if action == 'delete_data':
        return JsonResponse({'ok': True, 'msg': 'All coverage data and permit history deleted.'})
    if action == 'cancel':
        return JsonResponse({'ok': True, 'msg': 'Subscription cancelled. Access continues until end of billing period.'})
    return JsonResponse({'ok': False, 'error': 'Unknown action.'})


@login_required
@require_http_methods(['POST'])
def add_city_view(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return JsonResponse({'ok': False, 'error': 'Not authenticated'}, status=401)
    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    city  = data.get('city',  '').strip()
    state = data.get('state', '').strip()
    if not city:
        return JsonResponse({'ok': False, 'error': 'City name required'}, status=400)
    # Reject cities we don't have a scraper for
    _supported = {c['city'].lower() for c in get_supported_cities()}
    if city.lower() not in _supported:
        return JsonResponse({'ok': False, 'error': f"We don't have coverage for {city} yet. Check the supported cities list in the admin panel."}, status=400)
    user   = get_user_by_id(user_id) or {}
    # Block users with no active Whop subscription — their dashboard
    # already shows the "Preview Mode" lock banner, but the cities
    # endpoint was previously open and let them add cities anyway.
    # Admins (allow-listed by email) bypass this since their access
    # doesn't go through Whop. Same JSON shape as the upgrade gate
    # below so the existing client-side error handler renders the
    # CTA without changes.
    if not user.get('subscription_active') and user.get('email') not in ADMIN_EMAILS:
        return JsonResponse({'ok': False, 'no_plan': True, 'upgrade_required': True,
                             'error': 'Choose a plan to start tracking cities.'}, status=403)
    # Block adding cities while frozen
    if user.get('cities_frozen', False):
        return JsonResponse({'ok': False, 'frozen': True,
                             'error': 'Remove excess cities before adding new ones.'}, status=403)
    # Block Starter/Pro users who have hit their plan city limit
    plan       = (user.get('plan') or 'starter').capitalize()
    city_limit = PLAN_CITY_LIMITS.get(plan, 1)
    current    = list(user.get('cities', []))
    if plan != 'Agency' and len(current) >= city_limit:
        return JsonResponse({'ok': False, 'upgrade_required': True,
                             'error': 'Upgrade to Agency to add more cities.'}, status=403)
    entry  = f"{city}, {state}" if state else city
    cities = list(user.get('cities', []))
    city_names = [c.split(',')[0].strip().lower() for c in cities]
    if city.lower() in city_names:
        return JsonResponse({'ok': False, 'duplicate': True,
                             'error': f"{city} is already in your coverage."})
    cities.append(entry)
    update_user(user_id, cities=cities)
    return JsonResponse({'ok': True, 'cities': cities})


@login_required
@require_http_methods(['POST'])
def remove_city_view(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return JsonResponse({'ok': False, 'error': 'Not authenticated'}, status=401)
    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    entry  = data.get('city', '').strip()
    user   = get_user_by_id(user_id) or {}
    cities = [c for c in user.get('cities', []) if c != entry]
    update_user(user_id, cities=cities)
    # Auto-unfreeze if city count is now within the plan limit
    plan       = user.get('plan', 'starter')
    city_limit = PLAN_CITY_LIMITS.get(plan, 1)
    was_frozen = user.get('cities_frozen', False)
    now_frozen = len(cities) > city_limit
    if was_frozen and not now_frozen:
        update_user(user_id, cities_frozen=False)
    return JsonResponse({
        'ok':        True,
        'cities':    cities,
        'frozen':    now_frozen,
        'unfrozen':  was_frozen and not now_frozen,
        'city_limit': city_limit,
    })


@login_required
@require_http_methods(['POST'])
def save_billing_address(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return JsonResponse({'ok': False, 'error': 'Not authenticated'}, status=401)
    update_user(user_id,
        bill_company   = request.POST.get('bill_company',   '').strip(),
        bill_tax_id    = request.POST.get('bill_tax_id',    '').strip(),
        bill_street    = request.POST.get('bill_street',    '').strip(),
        bill_city      = request.POST.get('bill_city',      '').strip(),
        bill_state_zip = request.POST.get('bill_state_zip', '').strip(),
    )
    return JsonResponse({'ok': True})


@login_required
def export_invoices_csv(request):
    user_id  = request.session.get('user_id')
    invoices = get_user_invoices(user_id)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="permitlify-invoices.csv"'

    writer = csv.writer(response)
    writer.writerow(['Invoice ID', 'Plan', 'Billing Period', 'Amount', 'Status', 'Payment'])
    for inv in invoices:
        writer.writerow([
            inv.get('number', inv.get('invoice_id', '')),
            inv.get('plan_label', inv.get('plan', '').title()),
            inv.get('period', inv.get('date', '')),
            inv.get('amount', ''),
            inv.get('status', 'paid').title(),
            inv.get('payment', 'Whop'),
        ])
    if not invoices:
        writer.writerow(['—', '—', '—', '—', '—', '—'])
    return response


def _build_invoice_ctx(request, inv_id, *, ascii_features=False):
    """Resolve + normalise the invoice context dict shared by both the
    web preview (``invoice_pdf``) and the PDF download (``invoice_pdf_download``).

    Whop webhooks occasionally write ``None`` for fields that we'd otherwise
    call ``.lower()`` / ``.title()`` / ``//`` on. Coercing once here means
    a single bad row can no longer 500 either endpoint. Returns ``None`` if
    the invoice is missing or doesn't belong to the session user (caller
    should raise ``Http404``).

    ``ascii_features`` flips the bullet character used in plan-feature
    strings — Helvetica (used by the PDF) lacks the U+00B7 middle dot
    glyph and would render it as a tofu square, so the PDF path passes
    True to fall back to ASCII hyphens.
    """
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}

    inv = get_invoice_by_id(inv_id)
    if not inv:
        return None
    try:
        if int(inv.get('user_id', -1)) != int(user_id):
            return None
    except (TypeError, ValueError):
        return None

    sep = ' - ' if ascii_features else ' · '
    plan_features = {
        'starter': sep.join(['AI-scored permit feed', '1 city', '30 alerts/mo', '7-day history', 'Email delivery']),
        'pro':     sep.join(['AI-scored permit feed', 'up to 5 cities', '300 alerts/mo', '90-day history', 'Trade filtering', 'CSV export', 'Priority support']),
        'agency':  sep.join(['AI-scored permit feed', '15 cities', 'Unlimited alerts', 'Full archive', 'REST API + webhooks', 'Slack/SMS/webhook channels', 'White-label', 'Dedicated onboarding']),
    }

    plan_raw = (inv.get('plan') or '').strip()
    try:
        amt_cents = int(inv.get('amount_cents') or 0)
    except (TypeError, ValueError):
        amt_cents = 0

    return {
        'inv_id':          str(inv.get('invoice_id') or inv_id),
        'inv_num_short':   str(inv.get('number') or inv_id),
        'inv_date':        inv.get('date') or '',
        'inv_due':         inv.get('date') or '',
        'inv_period':      inv.get('period') or '',
        'inv_status':      (inv.get('status') or 'paid'),
        'inv_amount':      amt_cents // 100,
        'user_plan':       plan_raw.title(),
        'plan_features':   plan_features.get(plan_raw.lower(), ''),
        'user_name':       request.session.get('user_name') or '',
        'user_email':      request.session.get('user_email') or '',
        'company':         user.get('company') or user.get('bill_company') or '',
        'bill_street':     user.get('bill_street') or '',
        'bill_city':       user.get('bill_city') or '',
        'bill_state_zip':  user.get('bill_state_zip') or '',
        'bill_ein':        user.get('bill_ein') or user.get('bill_tax_id') or '',
    }


@login_required
def invoice_pdf(request, inv_id):
    ctx = _build_invoice_ctx(request, inv_id)
    if ctx is None:
        raise Http404
    return render(request, 'core/invoice_print.html', ctx)


@login_required
def invoice_pdf_download(request, inv_id):
    """Server-rendered PDF download.

    The on-screen ``invoice_pdf`` view renders a beautiful HTML preview, but
    asking the browser to print → save was unreliable (per-browser margins,
    print headers, sometimes blurry). This endpoint generates a real PDF
    server-side via reportlab and returns it as a file attachment so users
    get a consistent, vector, selectable-text PDF every time.
    """
    ctx = _build_invoice_ctx(request, inv_id, ascii_features=True)
    if ctx is None:
        raise Http404

    from .invoice_pdf import build_invoice_pdf
    pdf_bytes = build_invoice_pdf(ctx)

    filename = f"Permitlify-Invoice-{ctx['inv_id']}.pdf"
    resp = HttpResponse(pdf_bytes, content_type='application/pdf')
    resp['Content-Disposition'] = f'attachment; filename="{filename}"'
    resp['Content-Length'] = str(len(pdf_bytes))
    resp['Cache-Control']  = 'private, no-store'
    return resp


@login_required
@subscription_required
@require_http_methods(['GET', 'POST'])
def profile(request):
    user_id = request.session.get('user_id')
    user = get_user_by_id(user_id) or {}

    success_profile  = False
    success_password = False
    error_password   = None

    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'save_profile':
            first    = request.POST.get('first_name', '').strip()
            last     = request.POST.get('last_name', '').strip()
            full_name = (first + ' ' + last).strip() or first or user.get('name', '')
            phone    = request.POST.get('phone', '').strip()
            company  = request.POST.get('company', '').strip()
            trade    = request.POST.get('trade', '').strip()
            bio      = request.POST.get('bio', '').strip()
            initials = ''.join(w[0].upper() for w in full_name.split()[:2]) if full_name else user.get('avatar_initials', 'U')

            update_user(user_id,
                name=full_name,
                phone=phone,
                company=company,
                trade=trade,
                bio=bio,
                avatar_initials=initials,
            )
            request.session['user_name']     = full_name
            request.session['user_initials'] = initials
            user = get_user_by_id(user_id) or {}
            success_profile = True

        elif action == 'change_password':
            new_pw     = request.POST.get('new_password', '')
            confirm_pw = request.POST.get('confirm_password', '')
            # Google-only users have a random server-generated password
            # they don't know — they signed in with the Google button —
            # so we can't (and shouldn't) ask them for a "current
            # password". The "first time setting a password" flow skips
            # that gate. After it succeeds we flip auth_provider to
            # 'local' so any *subsequent* change goes through the
            # normal current-password check.
            is_google_only = (user.get('auth_provider') == 'google')

            if is_google_only:
                if len(new_pw) < 8:
                    error_password = 'Password must be at least 8 characters.'
                elif new_pw != confirm_pw:
                    error_password = 'Passwords do not match.'
                else:
                    update_user(user_id, password=hash_password(new_pw),
                                auth_provider='local')
                    user = get_user_by_id(user_id) or user
                    success_password = True
            else:
                current_pw = request.POST.get('current_password', '')
                if not authenticate_user(user.get('email', ''), current_pw):
                    error_password = 'Current password is incorrect.'
                elif len(new_pw) < 8:
                    error_password = 'New password must be at least 8 characters.'
                elif new_pw != confirm_pw:
                    error_password = 'Passwords do not match.'
                else:
                    update_user(user_id, password=hash_password(new_pw))
                    success_password = True

    name   = user.get('name', '')
    parts  = name.split(' ', 1)
    first_name = parts[0] if parts else ''
    last_name  = parts[1] if len(parts) > 1 else ''

    TRADES = ['Roofing', 'HVAC', 'Plumbing', 'Electrical', 'General Contractor', 'Solar', 'Windows & Doors', 'Other']

    ctx = _user_ctx(request)
    ctx.update({
        'first_name':       first_name,
        'last_name':        last_name,
        'phone':            user.get('phone', ''),
        'company':          user.get('company', ''),
        'trade':            user.get('trade', 'Roofing'),
        'bio':              user.get('bio', ''),
        'trades':           TRADES,
        'success_profile':  success_profile,
        'success_password': success_password,
        'error_password':   error_password,
        # True for users who signed up via Google and have never set
        # their own password. Template uses this to swap the
        # "Change Password" form for a "Set Password" form (no
        # current-password field) and shows a friendly heads-up
        # banner explaining why.
        'is_google_only_user': (user.get('auth_provider') == 'google'),
    })
    return render(request, 'core/profile.html', ctx)

def _user_ctx(request):
    return {
        'user_name':     request.session.get('user_name', ''),
        'user_email':    request.session.get('user_email', ''),
        'user_initials': request.session.get('user_initials', 'MK'),
        'user_plan':     request.session.get('user_plan', 'Starter'),
        'is_admin':      request.session.get('user_email') in ADMIN_EMAILS,
        # Soft-lock flag set by ``subscription_required`` decorator. True
        # when the logged-in user has no active subscription. Templates
        # use it to render a "Preview Mode" banner + Upgrade CTA in
        # place of the old hard /paywall/ redirect.
        'is_locked':     getattr(request, 'is_locked', False),
    }

# ── Admin shared helpers ───────────────────────────────────────

def _admin_plan_counts(all_users):
    """In-memory plan tally — must match the bucketing logic in
    ``count_users_by_plan()`` (core/db.py) so the admin Users tab
    KPI cards stay consistent with the cached SQL aggregate. Users
    without an active Whop subscription are bucketed under
    ``no_plan`` regardless of their (default-on-signup) plan field;
    admins are exempted because their access doesn't go through Whop.
    """
    counts = {'starter': 0, 'pro': 0, 'agency': 0, 'no_plan': 0}
    for u in all_users:
        is_admin = u.get('email') in ADMIN_EMAILS
        if not is_admin and not u.get('subscription_active'):
            counts['no_plan'] += 1
            continue
        p = u.get('plan', 'starter').lower()
        counts[p] = counts.get(p, 0) + 1
    return counts

def _admin_scraper_sidebar(scrapers=None):
    """Return ``(danger_count, broken_count)`` for the sidebar warning
    badge.

    Backed by the real ``scrapers`` table now: a scraper is "broken"
    when its most recent run failed, "danger" when it has been failing
    consecutively (we use ``last_run_status`` as a cheap proxy and let
    the stats page surface the per-day truth).
    """
    try:
        from .db import list_scrapers as _ls
        rows, _, _, _ = _ls('', 1, 200)
    except Exception:
        return 0, 0
    danger = sum(1 for s in rows if (s.get('last_run_status') or '') == 'failed' and s.get('enabled'))
    warning = sum(1 for s in rows if (s.get('last_run_status') or '') == 'partial' and s.get('enabled'))
    return danger, danger + warning

def _admin_base_ctx(request, active_section, scrapers=None):
    danger_count, broken_count = _admin_scraper_sidebar(scrapers)
    return {
        'active_section':  active_section,
        'admin_name':      request.session.get('user_name', 'Admin'),
        'admin_initials':  request.session.get('user_initials', 'MK'),
        'today':           date.today().strftime('%B %d, %Y'),
        'danger_count':    danger_count,
        'broken_count':    broken_count,
        'banned_count':    len(get_all_banned()),
    }

# ── Admin views ────────────────────────────────────────────────

@admin_required
@cached_admin_html(15)
def admin_dashboard(request):
    # Pull every aggregate from the SQL-side helpers in `core/db.py`.
    # Each one is a tiny GROUP BY / COUNT query with its own 30 s
    # in-process TTL, so we (1) skip dragging the entire users table
    # (id + JSONB) into Python only to count it, and (2) reuse those
    # aggregates across all admin pages that need the same numbers.
    today          = date.today()
    # Pass ADMIN_EMAILS so the SQL helper exempts allow-listed admin
    # accounts from the synthetic 'no_plan' bucket the same way the
    # in-memory _admin_plan_counts() does — otherwise an admin without
    # an active Whop subscription would be counted as no_plan on the
    # global dashboard but not on the Users tab, and the two pages
    # would silently disagree.
    plan_counts    = count_users_by_plan(tuple(ADMIN_EMAILS))
    total_users    = sum(plan_counts.values())
    new_this_month = count_users_joined_in_month(today.strftime('%Y-%m'))
    top_cities     = aggregate_user_cities()[:5]

    # Pull real Whop figures so MRR / ARR / Active subs / chart match the
    # /admin-panel/revenue/ page (and the Whop merchant dashboard) instead
    # of the old PLAN_PRICE × plan_counts approximation, which silently
    # overstates MRR by ~177× when most of the "active" plans are actually
    # trial signups that never cycled. See core.whop._compute_mrr_at for
    # the full justification.
    #
    # Strategy:
    #   * Get a 365-day revenue snapshot once — we slice it for both the
    #     month-over-month delta badge and the 6-month gross-revenue chart.
    #   * Count currently valid+active/trialing memberships from the same
    #     /memberships fetch the revenue helper already pulled (cached
    #     in-process), so Active Subscribers reflects what Whop reports.
    #   * Fall back to the local PLAN_PRICE math when Whop is unreachable
    #     so the dashboard still renders something sensible offline.
    whop_stats   = None
    whop_mrr     = None
    whop_arr     = None
    whop_active  = None
    whop_mrr_pct = None
    monthly_revenue = []
    try:
        from .whop import get_revenue_stats
        whop_stats = get_revenue_stats(range_key='365d')
    except Exception:
        log.exception("admin_dashboard: get_revenue_stats failed")

    # Only trust Whop's MRR / chart when BOTH endpoints succeeded — a
    # partial fetch (memberships ok, payments down) would silently produce
    # MRR=$0 because no payments are visible to attach to memberships,
    # which is much more misleading than falling back to the local
    # PLAN_PRICE estimate. We still pull `active_recurring` from the
    # memberships-only payload (it doesn't depend on payments) so the
    # Active Subscribers card stays accurate even during a payments
    # outage.
    if whop_stats:
        rng = whop_stats.get('range') or {}
        totals = whop_stats.get('totals') or {}
        whop_active = totals.get('active_recurring')
        if whop_stats.get('payments_ok') and whop_stats.get('memberships_ok'):
            whop_mrr     = (rng.get('mrr') or {}).get('value')
            whop_arr     = (rng.get('arr') or {}).get('value')
            whop_mrr_pct = (rng.get('mrr') or {}).get('delta_pct')
            # Bucket the 365-day daily gross series into the trailing 6
            # calendar months so the chart shows real numbers. ``labels``
            # and ``series`` are aligned arrays from get_revenue_stats.
            series = (rng.get('gross') or {}).get('series') or []
            if series:
                from collections import OrderedDict
                buckets: 'OrderedDict[str, float]' = OrderedDict()
                # ``labels`` are 'Mon DD' (no year). Walk forward day-by-day
                # from the start of the window so the bucket key 'Mon YYYY'
                # handles the Dec → Jan rollover correctly.
                cur_dt = today - timedelta(days=len(series) - 1)
                for v in series:
                    key = cur_dt.strftime('%b %Y')
                    buckets[key] = buckets.get(key, 0.0) + float(v or 0)
                    cur_dt += timedelta(days=1)
                # Last 6 months to mirror the previous chart length.
                for k, v in list(buckets.items())[-6:]:
                    monthly_revenue.append({'month': k, 'revenue': round(v, 2)})

    if whop_mrr is not None:
        mrr         = whop_mrr
        active_subs = whop_active if whop_active is not None else (
            plan_counts.get('pro', 0) + plan_counts.get('agency', 0)
        )
        data_source = 'whop'
    else:
        # Whop unreachable (or only partially) — fall back to the local
        # PLAN_PRICE estimate. Marked with a ⚠ in the template so admins
        # know it's not authoritative.
        mrr         = sum(PLAN_PRICE.get(p, 0) * n for p, n in plan_counts.items())
        active_subs = whop_active if whop_active is not None else (
            plan_counts.get('pro', 0) + plan_counts.get('agency', 0)
        )
        data_source = 'local'

    avg_rev = round(mrr / active_subs, 2) if active_subs else 0

    if not monthly_revenue:
        # No Whop series available — show a single bar for "this month"
        # using whatever MRR we computed above. Avoids the old hard-coded
        # historical numbers, which had no basis in real data.
        monthly_revenue = [{'month': today.strftime('%b %Y'), 'revenue': mrr}]

    scrapers          = _enrich_scrapers(SAMPLE_SCRAPERS)
    total_leads_today = sum(s['leads_today'] for s in scrapers)
    ctx = {
        **_admin_base_ctx(request, 'overview', scrapers),
        'total_users':       total_users,
        'active_subs':       active_subs,
        'mrr':               mrr,
        'arr':               whop_arr if whop_arr is not None else round(mrr * 12, 2),
        'mrr_delta_pct':     whop_mrr_pct,   # None when no prior period to compare
        'data_source':       data_source,
        'new_this_month':    new_this_month,
        'avg_rev':           avg_rev,
        'plan_counts':       plan_counts,
        'monthly_revenue':   monthly_revenue,
        'top_cities':        top_cities,
        'total_leads_today': total_leads_today,
        'quick_links': [
            {'icon': '🤖', 'label': 'Scrapers',   'url': '/admin-panel/scrapers/'},
            {'icon': '👥', 'label': 'All Users',  'url': '/admin-panel/users/'},
            {'icon': '💰', 'label': 'Revenue',    'url': '/admin-panel/revenue/'},
            {'icon': '🏙️', 'label': 'Top Cities', 'url': '/admin-panel/cities/'},
            {'icon': '🚫', 'label': 'Banned',     'url': '/admin-panel/banned/'},
        ],
    }
    return render(request, 'core/admin_overview.html', ctx)


# ─────────────────────────────────────────────────────────────────
# Vendor library passthrough (jQuery + DataTables).
#
# Whitenoise on production (behind Cloudflare + DigitalOcean App
# Platform) emits Content-Type: text/javascript; charset="utf-8" with
# literal quotes around utf-8. Combined with the X-Content-Type-Options:
# nosniff header we set globally, MS Edge (and some Safari builds)
# refuses to execute the script — the file loads with HTTP 200 but the
# browser silently rejects it, leaving jQuery undefined and our
# admin DataTables permanently empty (issue surfaced May 2026 on the
# /admin-panel/scrapers/ page even in InPrivate mode).
#
# Serving these tiny files (≤ 90 KB each) through Django with an
# explicit, RFC-clean Content-Type sidesteps whitenoise entirely. The
# files are still cached by the browser for 30 days.
# ─────────────────────────────────────────────────────────────────
from pathlib import Path as _Path
from functools import lru_cache as _lru_cache
from django.conf import settings as _settings

_VENDOR_LIB_DIR = _Path(_settings.BASE_DIR) / 'static' / 'vendor' / 'lib'
_VENDOR_LIB_TYPES = {
    'core.min.js':  'text/javascript; charset=utf-8',
    'grid.min.js':  'text/javascript; charset=utf-8',
    'grid.min.css': 'text/css; charset=utf-8',
}

@_lru_cache(maxsize=8)
def _vendor_bytes(name):
    return (_VENDOR_LIB_DIR / name).read_bytes()

def vendor_lib(request, name):
    """Serve `static/vendor/lib/{name}` with a clean Content-Type so
    Edge/Safari accept it under X-Content-Type-Options: nosniff."""
    if name not in _VENDOR_LIB_TYPES:
        raise Http404(name)
    try:
        body = _vendor_bytes(name)
    except FileNotFoundError:
        raise Http404(name)
    resp = HttpResponse(body, content_type=_VENDOR_LIB_TYPES[name])
    resp['Cache-Control']    = 'public, max-age=2592000, immutable'  # 30 days
    resp['X-Content-Type-Options'] = 'nosniff'
    return resp


@admin_required
def admin_scrapers_view(request):
    """Real scrapers list — backed by the `scrapers` table.

    The actual rows are loaded by the DataTable JS via AJAX against
    :func:`admin_scrapers_data`. This shell view just renders the page
    chrome (search box, state/city filters, table skeleton) and seeds
    the filter dropdowns from the current set of scrapers.
    """
    from .db import (reap_stale_scraper_runs, reap_stale_cron_batches,
                     list_scraper_state_city_options)
    # Cheap indexed UPDATEs — un-stick any run row OR batch row that's
    # been "running" past its budget (gunicorn worker recycle, OOM
    # kill, hung Firecrawl past urllib timeout, etc.) so the list page
    # status pills tell the truth instead of showing phantom in-flight
    # rows. Both are best-effort; never fatal.
    try:
        reaped = reap_stale_scraper_runs(30)
        if reaped:
            logging.info('reaped %d stale scraper_runs row(s)', reaped)
    except Exception:
        logging.exception('reap_stale_scraper_runs failed (non-fatal)')
    try:
        reaped_b = reap_stale_cron_batches(60)
        if reaped_b:
            logging.info('reaped %d stale cron_batches row(s)', reaped_b)
    except Exception:
        logging.exception('reap_stale_cron_batches failed (non-fatal)')

    # Total + filter options — used to render the empty state and the
    # state/city <select>s. Done at page-render time so the dropdowns
    # are populated on first paint without an extra AJAX round-trip.
    options = list_scraper_state_city_options()
    # Total scrapers count for the meta line. Cheap COUNT(*) — and
    # list_scrapers_dt does the same on every AJAX call, so caching
    # it here doesn't help.
    from .db import pg as _pg
    total_row = _pg.query_one('SELECT COUNT(*) AS n FROM scrapers')
    total = int((total_row or {}).get('n') or 0)

    # Full canonical state-code list for the Edit modal's
    # auto-infer-from-name validator. Independent of which states
    # currently have a scraper, so editing the very first scraper in
    # a brand new state still gets the inferred suffix accepted.
    from .us_cities_top import US_STATES
    all_state_codes = [code for code, _ in US_STATES]

    ctx = {
        **_admin_base_ctx(request, 'scrapers'),
        'q':                       (request.GET.get('q') or '').strip(),
        'state_filter':            (request.GET.get('state') or '').strip().upper(),
        'city_filter':             (request.GET.get('city')  or '').strip().title(),
        'total':                   total,
        'state_options':           options['states'],
        'cities_by_state_json':    json.dumps(options['cities_by_state']),
        'all_state_codes_json':    json.dumps(all_state_codes),
        # Firecrawl-Agent settings card (rendered below the table —
        # the same global knobs are also exposed on the per-scraper
        # detail page via the same partial). Settings persist via
        # /admin-panel/scrapers/agent/settings/.
        **_agent_settings_ctx(),
    }
    return render(request, 'core/admin_scrapers.html', ctx)


@admin_required
def admin_scrapers_data(request):
    """DataTables server-side AJAX endpoint for /admin-panel/scrapers/.

    Reads DataTables' standard query params plus our own filter params
    (``state``, ``city``, ``q``) and returns the JSON envelope
    DataTables expects: ``{draw, recordsTotal, recordsFiltered, data}``.

    Per-row payload is hand-shaped so the client renderer doesn't have
    to know about Python dates or DB internals.
    """
    from .db import list_scrapers_dt
    try:
        draw = int(request.GET.get('draw') or 1)
    except (TypeError, ValueError):
        draw = 1
    try:
        start  = int(request.GET.get('start')  or 0)
        length = int(request.GET.get('length') or 25)
    except (TypeError, ValueError):
        start, length = 0, 25

    # Column-index → key mapping. Must mirror the `columns:` array in
    # admin_scrapers.html. Two-step indirection (idx → key → SQL frag
    # in db.list_scrapers_dt) keeps SQL injection impossible even with
    # a malicious order[0][column]. City and State are now two columns
    # so admins can sort by either independently — be careful to keep
    # this list in lockstep with the template's `columns:` definition.
    col_keys = ['name', 'url', 'city', 'state', 'last_run', 'permits', 'status']
    try:
        col_idx = int(request.GET.get('order[0][column]') or 4)
    except (TypeError, ValueError):
        col_idx = 4
    order_col = col_keys[col_idx] if 0 <= col_idx < len(col_keys) else 'last_run'
    order_dir = (request.GET.get('order[0][dir]') or 'desc').lower()

    state  = (request.GET.get('state')  or '').strip()
    city   = (request.GET.get('city')   or '').strip()
    search = (request.GET.get('q')      or '').strip()

    rows, total_unfiltered, total_filtered = list_scrapers_dt(
        search=search, state=state, city=city,
        start=start, length=length,
        order_col=order_col, order_dir=order_dir,
    )

    data = []
    for s in rows:
        url = s.get('url') or ''
        try:
            host = urllib.parse.urlparse(url).netloc or url
        except Exception:
            host = url
        data.append({
            'id':           int(s['id']),
            'name':         s.get('name') or '',
            'url':          url,
            'host':         host,
            'city':         s.get('city')  or '',
            'state':        s.get('state') or '',
            'agency_code':  s.get('agency_code') or '',
            'last_run_at':  s['last_run_at'].strftime('%b %d, %Y %I:%M %p')
                            if s.get('last_run_at') else '',
            'last_run_status': s.get('last_run_status') or '',
            'enabled':      bool(s.get('enabled')),
            'total_permits': int(s.get('total_permits') or 0),
        })

    return JsonResponse({
        'draw':            draw,
        'recordsTotal':    total_unfiltered,
        'recordsFiltered': total_filtered,
        'data':            data,
    })


# ── Scrapers — additional admin views ────────────────────────────────

@admin_required
def admin_scraper_new_view(request):
    """Create-scraper form. POST creates the row and redirects to the
    new scraper's detail page.

    City/state are optional but strongly recommended — the scrapers
    list page lets the admin filter by them, and the per-row meta on
    that page renders ``City, ST`` under the scraper name.
    """
    from .db import create_scraper, get_scraper
    from .scraper_accela import parse_accela_url
    from .us_cities_top import US_STATES, CITIES_BY_STATE
    err = None
    parsed_preview = None
    name_in = url_in = city_in = state_in = ''
    # Pre-fill from ?city=&state= so the Accela finder's "Add to scrapers"
    # button can hand us context the admin already typed once.
    if request.method == 'GET':
        city_in  = (request.GET.get('city')  or '').strip()
        state_in = (request.GET.get('state') or '').strip().upper()
        name_in  = (request.GET.get('name')  or '').strip()
        url_in   = (request.GET.get('url')   or '').strip()
    if request.method == 'POST':
        name_in  = (request.POST.get('name')  or '').strip()
        url_in   = (request.POST.get('url')   or '').strip()
        city_in  = (request.POST.get('city')  or '').strip()
        state_in = (request.POST.get('state') or '').strip().upper()
        if not name_in:
            err = 'Name is required.'
        elif not url_in or not url_in.startswith('https://'):
            err = 'A full https:// URL is required.'
        elif state_in and (len(state_in) != 2 or not state_in.isalpha()):
            err = 'State must be a 2-letter code (e.g. CA).'
        else:
            # Lenient validation: we only enforce the host allowlist
            # (accela.com / *.accela.com — see parse_accela_url) and
            # let Firecrawl figure out the page contents. Backfill
            # specifically needs capID3 to enumerate, so the per-button
            # handler will surface a clean error if it's missing.
            parsed = parse_accela_url(url_in)
            if not parsed:
                err = ('URL must be on accela.com (or a subdomain). '
                       'Paste any Accela permit URL — CapDetail, CapHome, '
                       'list, or report page.')
            else:
                sid = create_scraper(
                    name=name_in,
                    url=url_in,
                    source='accela',
                    agency_code=parsed.get('agency_code', ''),
                    module=parsed.get('module', ''),
                    cap_id_template=parsed,
                    city=city_in,
                    state=state_in,
                    enabled=True,
                )
                return redirect(f'/admin-panel/scrapers/{sid}/')
    if request.method == 'GET' and request.GET.get('preview_url'):
        parsed_preview = parse_accela_url(request.GET['preview_url'])
    ctx = {
        **_admin_base_ctx(request, 'scrapers'),
        'err':                  err,
        'name_in':              name_in,
        'url_in':               url_in,
        'city_in':              city_in,
        'state_in':             state_in,
        'parsed_preview':       parsed_preview,
        'us_states':            US_STATES,
        'cities_by_state_json': json.dumps(CITIES_BY_STATE),
    }
    return render(request, 'core/admin_scraper_new.html', ctx)


@admin_required
def admin_scraper_permits_data(request, sid):
    """DataTables server-side AJAX endpoint for /admin-panel/scrapers/<sid>/.

    Bound to the table by the JS init in admin_scraper_detail.html.
    Reads DataTables' standard query params (``draw``, ``start``,
    ``length``, ``search[value]``, ``order[0][column]``,
    ``order[0][dir]``) plus our own filter params (``date_from``,
    ``date_to``, ``has_email``, ``has_phone``) and returns the JSON
    envelope DataTables expects: ``{draw, recordsTotal,
    recordsFiltered, data}``.

    Per-row payload is hand-shaped instead of dumping raw DB columns
    so the client-side renderer never has to parse Python date objects
    or look up money/score formatting twice.
    """
    from .db import get_scraper, list_permits_for_scraper_dt
    scraper = get_scraper(sid)
    if not scraper:
        return JsonResponse({'draw': 0, 'recordsTotal': 0, 'recordsFiltered': 0,
                             'data': [], 'error': 'Scraper not found'}, status=404)

    # DataTables sends draw as the request id; echo it back so stale
    # responses (e.g. the user typed fast and an earlier slow query
    # arrived after a later faster one) are dropped client-side.
    try:
        draw = int(request.GET.get('draw') or 1)
    except (TypeError, ValueError):
        draw = 1
    try:
        start = int(request.GET.get('start') or 0)
        length = int(request.GET.get('length') or 50)
    except (TypeError, ValueError):
        start, length = 0, 50

    # ORDER BY: DataTables sends column index → we map index → key,
    # and the DB layer maps key → SQL fragment (whitelist). Two-step
    # mapping keeps SQL injection impossible even if a malicious
    # client posts a bogus column index or name.
    col_keys = ['permit', 'type', 'address', 'city', 'contractor',
                'email', 'phone', 'date', 'value', 'score']
    try:
        col_idx = int(request.GET.get('order[0][column]') or 7)
    except (TypeError, ValueError):
        col_idx = 7
    order_col = col_keys[col_idx] if 0 <= col_idx < len(col_keys) else 'date'
    order_dir = (request.GET.get('order[0][dir]') or 'desc').lower()

    # Filter inputs (mirror the legacy non-DT view).
    date_from = (request.GET.get('date_from') or '').strip() or None
    date_to   = (request.GET.get('date_to')   or '').strip() or None
    he_raw = (request.GET.get('has_email') or '').strip().lower()
    hp_raw = (request.GET.get('has_phone') or '').strip().lower()
    has_email = True if he_raw == 'yes' else (False if he_raw == 'no' else None)
    has_phone = True if hp_raw == 'yes' else (False if hp_raw == 'no' else None)
    # Search text: prefer DataTables' own ``search[value]`` (built-in
    # search box) and fall back to our explicit ``q`` so the legacy
    # filter form still works if anyone bookmarks an old URL.
    q = (request.GET.get('search[value]')
         or request.GET.get('q') or '').strip()

    rows, total_unfiltered, total_filtered = list_permits_for_scraper_dt(
        sid, date_from=date_from, date_to=date_to,
        has_email=has_email, has_phone=has_phone, query=q,
        start=start, length=length,
        order_col=order_col, order_dir=order_dir,
    )

    def _iso(d):
        return d.isoformat() if hasattr(d, 'isoformat') else (d or '')
    def _money(c):
        try: return f'${int(c) // 100:,}' if c else ''
        except (TypeError, ValueError): return ''

    data = [{
        'id':         r['id'],
        'permit':     r.get('permit_number') or '',
        'type':       r.get('permit_type') or '',
        'address':    r.get('address') or '',
        'city':       r.get('city') or '',
        'state':      r.get('state') or '',
        'contractor': r.get('contractor_name') or '',
        'email':      r.get('contractor_email') or '',
        'phone':      r.get('contractor_phone') or '',
        'date':       _iso(r.get('applied_date') or r.get('issued_date')),
        'value':      _money(r.get('valuation_cents')),
        'grade':      r.get('ai_grade') or '',
        'score':      int(r.get('ai_score') or 0),
    } for r in rows]
    return JsonResponse({
        'draw': draw,
        'recordsTotal':    total_unfiltered,
        'recordsFiltered': total_filtered,
        'data':            data,
    })


def _agent_settings_ctx() -> dict:
    """Build the context dict consumed by templates/core/_agent_settings_card.html.

    The Firecrawl-Agent knobs (prompt, model, max_credits, on/off) are
    stored globally in system_settings — they are NOT per-scraper. The
    same partial card is rendered on the scrapers list page and the
    per-scraper detail page; this helper keeps both sites in sync so a
    later default change only needs editing here.
    """
    from .db import get_system_setting
    from .scraper_accela import (
        ACCELA_SCRAPER_AGENT_DEFAULT_PROMPT,
        ACCELA_SCRAPER_AGENT_DEFAULT_MODEL,
        ACCELA_SCRAPER_AGENT_VALID_MODELS,
        ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS,
        ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP,
    )
    saved_prompt  = (get_system_setting('accela_scraper_agent_prompt_template') or '').strip()
    saved_model   = (get_system_setting('accela_scraper_agent_model') or '').strip()
    saved_credits = (get_system_setting('accela_scraper_agent_max_credits') or '').strip()
    saved_at      = (get_system_setting('accela_scraper_agent_settings_saved_at') or '').strip()
    saved_use_raw = (get_system_setting('accela_scraper_use_agent') or 'on').strip().lower()
    initial_prompt  = saved_prompt or ACCELA_SCRAPER_AGENT_DEFAULT_PROMPT
    initial_model   = (saved_model
                       if saved_model in ACCELA_SCRAPER_AGENT_VALID_MODELS
                       else ACCELA_SCRAPER_AGENT_DEFAULT_MODEL)
    try:
        initial_credits = int(saved_credits) if saved_credits else ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS
    except (TypeError, ValueError):
        initial_credits = ACCELA_SCRAPER_AGENT_DEFAULT_MAX_CREDITS
    initial_credits = max(1, min(initial_credits, ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP))
    return {
        'agent_default_prompt':    initial_prompt,
        'agent_default_model':     initial_model,
        'agent_models':            ACCELA_SCRAPER_AGENT_VALID_MODELS,
        'agent_default_credits':   initial_credits,
        'agent_max_credits_cap':   ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP,
        'agent_settings_saved_at': saved_at,
        'agent_use_on':            saved_use_raw != 'off',
    }


@admin_required
def admin_scraper_detail_view(request, sid):
    """Per-scraper detail page: header + filters bar + paginated permits
    table + run / backfill buttons + Firecrawl-Agent settings card.
    Run history moved to its own /admin-panel/scraper-logs/<sid>/
    page."""
    from .db import (get_scraper, list_permits_for_scraper,
                     count_permits_for_scraper)
    scraper = get_scraper(sid)
    if not scraper:
        raise Http404('Scraper not found')

    date_from = (request.GET.get('date_from') or '').strip() or None
    date_to   = (request.GET.get('date_to')   or '').strip() or None
    has_email_raw = (request.GET.get('has_email') or '').strip().lower()
    has_phone_raw = (request.GET.get('has_phone') or '').strip().lower()
    has_email = True if has_email_raw == 'yes' else (False if has_email_raw == 'no' else None)
    has_phone = True if has_phone_raw == 'yes' else (False if has_phone_raw == 'no' else None)
    q = (request.GET.get('q') or '').strip()
    try:
        page = int(request.GET.get('page') or 1)
    except (TypeError, ValueError):
        page = 1
    per_page = 25
    # list_permits_for_scraper returns the clamped page as the 4th
    # element so the prev/next links match the rows we render.
    rows, total, total_pages, page = list_permits_for_scraper(
        sid, date_from=date_from, date_to=date_to,
        has_email=has_email, has_phone=has_phone,
        query=q, page=page, per_page=per_page,
    )
    # `runs` query removed — the Recent runs side panel was retired
    # in favour of /admin-panel/scraper-logs/<sid>/. The template no
    # longer references {{ runs }}.
    # url host for chrome
    try:
        host = urllib.parse.urlparse(scraper['url']).netloc
    except Exception:
        host = scraper['url']
    qs_keep = []
    for k, v in (('q', q), ('date_from', date_from or ''),
                 ('date_to', date_to or ''),
                 ('has_email', has_email_raw), ('has_phone', has_phone_raw)):
        if v:
            qs_keep.append(f'{k}={urllib.parse.quote(str(v))}')
    qs_str = '&'.join(qs_keep)

    ctx = {
        **_admin_base_ctx(request, 'scrapers'),
        'scraper':     scraper,
        'host':        host,
        'permits':     rows,
        'total':       total,
        'page':        page,
        'per_page':    per_page,
        'total_pages': total_pages,
        'has_prev':    page > 1,
        'has_next':    page < total_pages,
        'prev_page':   max(1, page - 1),
        'next_page':   min(total_pages, page + 1),
        'qs_str':      qs_str,
        'filter_date_from': date_from or '',
        'filter_date_to':   date_to or '',
        'filter_has_email': has_email_raw,
        'filter_has_phone': has_phone_raw,
        'filter_q':         q,
        'permit_count':     count_permits_for_scraper(sid),
        # Agent settings card (shared partial — see _agent_settings_ctx)
        **_agent_settings_ctx(),
    }
    return render(request, 'core/admin_scraper_detail.html', ctx)


@admin_required
@require_http_methods(['POST'])
def admin_scraper_run_now(request, sid):
    """Async single-URL run. Kicks off the daemon thread and returns
    the run_id immediately so the UI can show a live progress bar
    while Firecrawl + the extraction LLM work (which together take
    30-90 seconds — too long to block the request).

    The frontend opens the same progress modal it uses for backfill
    and polls /admin-panel/scrapers/runs/<rid>/status/ until done."""
    from .scraper_accela import run_scraper_async, ScraperError
    # The unified run-now button now also carries an optional date
    # range (date_from + date_to inputs sit next to it). When set, the
    # worker passes them into the LIST-page prompt as a filter rule
    # AND post-checks every row against them on the Python side. Empty
    # values mean "no bound on that side".
    date_from = (request.POST.get('date_from') or '').strip() or None
    date_to   = (request.POST.get('date_to')   or '').strip() or None
    try:
        run_id = run_scraper_async(
            sid, mode='single',
            date_from=date_from, date_to=date_to,
        )
        return JsonResponse({'ok': True, 'run_id': run_id})
    except ScraperError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=400)
    except Exception:
        # Don't echo internal exception strings back to the browser —
        # the full traceback is already in the server log.
        logging.exception('scraper run-now kickoff failed')
        return JsonResponse(
            {'ok': False, 'error': 'Could not start run — check server logs.'},
            status=500,
        )


@admin_required
@require_http_methods(['POST'])
def admin_scraper_backfill(request, sid):
    """Async backfill — kicks off the daemon thread and returns the
    run_id immediately so the UI can begin polling progress."""
    from .scraper_accela import run_scraper_async, ScraperError
    try:
        count = int(request.POST.get('count') or 20)
    except (TypeError, ValueError):
        count = 20
    count = max(1, min(count, 200))
    # NOTE: backfill walks the scraper's URL backwards by capID3 — it
    # fetches each detail page directly without going through the list
    # page, so the date_from / date_to filter the admin set on the
    # detail page does NOT apply here. The Run-now endpoint is the one
    # that honours the date range. We intentionally do not read those
    # POST fields here so the contract stays honest.
    try:
        run_id = run_scraper_async(sid, mode='backfill', count=count)
        return JsonResponse({'ok': True, 'run_id': run_id})
    except ScraperError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=400)
    except Exception:
        # See note above — keep internal details out of the JSON.
        logging.exception('scraper backfill kickoff failed')
        return JsonResponse(
            {'ok': False, 'error': 'Could not start backfill — check server logs.'},
            status=500,
        )


@admin_required
@require_http_methods(['POST'])
def admin_scraper_agent_save_settings(request):
    """Persist the per-scraper Firecrawl-Agent settings card values.

    Body (JSON): ``prompt_template`` (string ≤8000 chars), ``model``
    (one of ``ACCELA_SCRAPER_AGENT_VALID_MODELS``), ``max_credits``
    (int 1..``ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP``), ``use_agent``
    (bool — when false, scrapes fall back to the legacy Firecrawl +
    Claude pipeline). Same shape as the finder's save endpoint so the
    template JS is essentially copy-pasted.
    """
    from .scraper_accela import (
        ACCELA_SCRAPER_AGENT_VALID_MODELS,
        ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP,
    )

    raw_body = request.body or b''
    if len(raw_body) > 16384:
        return JsonResponse({'ok': False, 'error': 'Request body too large.'},
                            status=413)

    if request.content_type and request.content_type.startswith('application/json'):
        try:
            payload = json.loads(raw_body.decode('utf-8') or '{}')
        except (json.JSONDecodeError, UnicodeDecodeError):
            return JsonResponse({'ok': False, 'error': 'Invalid JSON body.'},
                                status=400)
        if not isinstance(payload, dict):
            return JsonResponse(
                {'ok': False, 'error': 'JSON body must be an object.'},
                status=400,
            )
    else:
        payload = request.POST

    raw_prompt = payload.get('prompt_template', '')
    if not isinstance(raw_prompt, str):
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template must be a string.'},
            status=400,
        )
    prompt_template = raw_prompt.strip()
    if not prompt_template:
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template cannot be empty.'},
            status=400,
        )
    if len(prompt_template) > 8000:
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template too long (max 8000 chars).'},
            status=400,
        )

    raw_model = payload.get('model', '')
    if not isinstance(raw_model, str):
        return JsonResponse({'ok': False, 'error': 'model must be a string.'},
                            status=400)
    model = raw_model.strip()
    if model not in ACCELA_SCRAPER_AGENT_VALID_MODELS:
        return JsonResponse({
            'ok': False,
            'error': f'model must be one of {list(ACCELA_SCRAPER_AGENT_VALID_MODELS)}.',
        }, status=400)

    raw_credits = payload.get('max_credits', None)
    if raw_credits is None or raw_credits == '':
        return JsonResponse(
            {'ok': False, 'error': 'max_credits is required.'},
            status=400,
        )
    try:
        max_credits = int(raw_credits)
    except (TypeError, ValueError):
        return JsonResponse(
            {'ok': False, 'error': 'max_credits must be an integer.'},
            status=400,
        )
    if max_credits < 1 or max_credits > ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP:
        return JsonResponse({
            'ok': False,
            'error': f'max_credits must be 1..{ACCELA_SCRAPER_AGENT_MAX_CREDITS_CAP}.',
        }, status=400)

    # use_agent toggle: strict parser. We deliberately whitelist the
    # accepted shapes (bool, the canonical strings, 0/1) instead of
    # truthy-coercing arbitrary input, so a typo like
    # ``"use_agent": "tru"`` becomes a 400 the admin can SEE rather
    # than silently flipping to False.
    raw_use = payload.get('use_agent', True)
    if isinstance(raw_use, bool):
        use_agent = raw_use
    elif isinstance(raw_use, int):  # bool is filtered above
        if raw_use not in (0, 1):
            return JsonResponse(
                {'ok': False, 'error': 'use_agent must be true or false.'},
                status=400,
            )
        use_agent = bool(raw_use)
    elif isinstance(raw_use, str):
        v = raw_use.strip().lower()
        if v in ('true', 'on', 'yes', '1'):
            use_agent = True
        elif v in ('false', 'off', 'no', '0'):
            use_agent = False
        else:
            return JsonResponse(
                {'ok': False, 'error': 'use_agent must be true or false.'},
                status=400,
            )
    else:
        return JsonResponse(
            {'ok': False, 'error': 'use_agent must be true or false.'},
            status=400,
        )

    from .db import set_system_setting
    set_system_setting('accela_scraper_agent_prompt_template', prompt_template)
    set_system_setting('accela_scraper_agent_model',           model)
    set_system_setting('accela_scraper_agent_max_credits',     str(max_credits))
    set_system_setting('accela_scraper_use_agent',             'on' if use_agent else 'off')
    saved_at = datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')
    set_system_setting('accela_scraper_agent_settings_saved_at', saved_at)

    return JsonResponse({'ok': True, 'saved_at': saved_at,
                         'use_agent': use_agent})


@admin_required
def admin_scraper_run_status(request, rid):
    """Polling endpoint for the progress modal. Returns the current
    run row as JSON so the modal can update its progress bar."""
    from .db import get_scraper_run
    run = get_scraper_run(rid)
    if not run:
        return JsonResponse({'ok': False, 'error': 'run not found'}, status=404)
    total = max(1, int(run.get('total_targets') or 1))
    processed = int(run.get('processed') or 0)
    pct = round(100 * processed / total, 1) if total else 0
    # ``step_log`` is the CLI-style transcript the worker appends to
    # via ``append_scraper_run_step``. We send the whole array each
    # poll because (a) it's small (~100 entries × ~80 chars = <10KB)
    # and (b) the UI re-renders the terminal panel from scratch each
    # tick which keeps the JS dead-simple.
    return JsonResponse({
        'ok':           True,
        'run_id':       run['id'],
        'status':       run.get('status'),
        'mode':         run.get('mode'),
        'total':        total,
        'processed':    processed,
        'succeeded':    int(run.get('succeeded') or 0),
        'failed':       int(run.get('failed') or 0),
        'pct':          pct,
        'current_step': run.get('current_step') or '',
        'errors':       run.get('error') or [],
        'step_log':     run.get('step_log') or [],
        'finished':     bool(run.get('finished_at')),
    })


# ── "Run cron now" — kick all enabled scrapers in one click ─────────
#
# Wraps the scripts/run_scrapers.py cron entrypoint behind an admin
# button so we can fire a manual cron pass without ssh'ing into the
# box. Each child run is recorded with kind='cron'/mode='cron' so the
# stats page reports it the same as the scheduled job.
#
# Architecture notes:
#   • Coordinator runs in a daemon thread on whichever gunicorn worker
#     handled the POST. It writes batch+child progress only to
#     Postgres, so the polling endpoint can be served by ANY worker
#     (production runs >1 worker — in-memory state would leak).
#   • Children are launched serially via run_scraper_async() and
#     awaited via DB polling, mirroring scripts/run_scrapers.py so
#     manual + scheduled behaviour stay identical.
#   • A 30-min per-child timeout caps a stuck Firecrawl request so
#     the whole batch can't pin one worker forever.

_CRON_BATCH_PER_RUN_MAX_SECONDS = 1800   # 30 min — same as scripts/run_scrapers.py
_CRON_BATCH_POLL_SECONDS        = 2.0


def _wait_for_scraper_run(run_id: int, *, max_wait_seconds: int) -> dict | None:
    """Block until ``scraper_runs.finished_at`` is set or timeout. Used
    by the cron coordinator to march through children one at a time."""
    import time as _time
    from .db import get_scraper_run
    deadline = _time.time() + max_wait_seconds
    while _time.time() < deadline:
        row = get_scraper_run(run_id)
        if row and row.get('finished_at'):
            return row
        _time.sleep(_CRON_BATCH_POLL_SECONDS)
    # Timed out — return whatever we have so the caller can record it
    # as "did not finish" and move on.
    return get_scraper_run(run_id)


def _run_cron_batch_worker(batch_id: int) -> None:
    """Daemon thread body. Iterates every enabled scraper in series,
    kicking each via ``run_scraper_async(mode='cron', kind='cron')``
    and waiting for the run row to report finished_at. All progress is
    persisted to Postgres so the polling endpoint works cross-worker."""
    from .db import (
        list_enabled_scrapers_all, get_scraper_run,
        update_cron_batch, append_cron_batch_run_id,
        reap_stale_scraper_runs,
    )
    from .scraper_accela import run_scraper_async
    from datetime import datetime as _dt
    try:
        # Reap once at the start so a previous half-dead run doesn't
        # block the new pass — defensive, the list view also reaps.
        try:
            reap_stale_scraper_runs(30)
        except Exception:
            logging.exception('cron-batch %s: reaper failed (non-fatal)', batch_id)

        # Use the un-paginated query so a future fleet of >100 enabled
        # scrapers doesn't get silently truncated by list_scrapers()'s
        # 100/page clamp.
        enabled = list_enabled_scrapers_all()
        if not enabled:
            update_cron_batch(
                batch_id,
                status='success',
                finished_at=_dt.utcnow(),
                note='no enabled scrapers — nothing to run',
            )
            return

        ok = 0
        fail = 0
        for s in enabled:
            sid = int(s['id'])
            try:
                run_id = run_scraper_async(
                    sid, mode='cron', kind='cron', count=20,
                )
            except Exception:
                logging.exception(
                    'cron-batch %s: failed to kick scraper #%d', batch_id, sid,
                )
                fail += 1
                continue
            try:
                append_cron_batch_run_id(batch_id, run_id)
            except Exception:
                logging.exception(
                    'cron-batch %s: append run_id %d failed (non-fatal)',
                    batch_id, run_id,
                )

            finished = _wait_for_scraper_run(
                run_id, max_wait_seconds=_CRON_BATCH_PER_RUN_MAX_SECONDS,
            )
            if not finished or not finished.get('finished_at'):
                fail += 1
                continue
            status = (finished.get('status') or '').strip().lower()
            if status == 'success':
                ok += 1
            else:
                fail += 1

        final_status = (
            'success' if fail == 0 and ok > 0 else
            'failed'  if ok == 0 else
            'partial'
        )
        update_cron_batch(
            batch_id,
            status=final_status,
            finished_at=_dt.utcnow(),
            note=f'done — {ok} succeeded, {fail} failed',
        )
    except Exception:
        logging.exception('cron-batch %s: coordinator crashed', batch_id)
        try:
            update_cron_batch(
                batch_id,
                status='failed',
                finished_at=_dt.utcnow(),
                note='coordinator crashed — see server logs',
            )
        except Exception:
            pass


@admin_required
@require_http_methods(['POST'])
def admin_run_cron_now(request):
    """Kick a manual cron pass — runs every enabled scraper in series
    with kind='cron'/mode='cron' so it's indistinguishable from the
    scheduled job. Returns the batch_id immediately so the UI can
    start polling /admin-panel/scrapers/cron/batch/<id>/."""
    import threading
    from .db import create_cron_batch
    try:
        kicked_by = request.session.get('user_id')
        batch_id = create_cron_batch(kicked_by=kicked_by)
    except Exception:
        logging.exception('admin_run_cron_now: failed to create batch row')
        return JsonResponse(
            {'ok': False, 'error': 'Could not start cron batch — check server logs.'},
            status=500,
        )
    t = threading.Thread(
        target=_run_cron_batch_worker,
        args=(batch_id,),
        name=f'cron-batch-{batch_id}',
        daemon=True,
    )
    t.start()
    return JsonResponse({'ok': True, 'batch_id': batch_id})


@admin_required
def admin_cron_batch_status(request, batch_id):
    """Polling endpoint for the multi-scraper cron terminal panel.
    Returns the batch row plus a live snapshot of every child run."""
    from .db import get_cron_batch, get_scraper_run, get_scraper
    batch = get_cron_batch(batch_id)
    if not batch:
        return JsonResponse({'ok': False, 'error': 'batch not found'}, status=404)
    children = []
    for rid in (batch.get('run_ids') or []):
        try:
            run = get_scraper_run(int(rid))
        except Exception:
            run = None
        if not run:
            continue
        sid = int(run.get('scraper_id') or 0)
        scraper_name = ''
        if sid:
            try:
                sc = get_scraper(sid)
                scraper_name = (sc or {}).get('name') or f'scraper #{sid}'
            except Exception:
                scraper_name = f'scraper #{sid}'
        total = max(1, int(run.get('total_targets') or 1))
        processed = int(run.get('processed') or 0)
        pct = round(100 * processed / total, 1) if total else 0.0
        # Cap step_log to last 60 lines so a long backfill transcript
        # doesn't bloat each poll. The per-scraper detail page is the
        # place to read full history.
        step_log = run.get('step_log') or []
        if len(step_log) > 60:
            step_log = step_log[-60:]
        children.append({
            'run_id':       run['id'],
            'scraper_id':   sid,
            'scraper_name': scraper_name,
            'status':       run.get('status'),
            'total':        total,
            'processed':    processed,
            'succeeded':    int(run.get('succeeded') or 0),
            'failed':       int(run.get('failed') or 0),
            'pct':          pct,
            'current_step': run.get('current_step') or '',
            'step_log':     step_log,
            'finished':     bool(run.get('finished_at')),
        })
    return JsonResponse({
        'ok':          True,
        'batch_id':    batch['id'],
        'status':      batch.get('status'),
        'started_at':  batch['started_at'].isoformat() if batch.get('started_at') else None,
        'finished_at': batch['finished_at'].isoformat() if batch.get('finished_at') else None,
        'note':        batch.get('note') or '',
        'children':    children,
        'finished':    bool(batch.get('finished_at')),
    })


# ── Scraper Cron sub-page ─────────────────────────────────────────────

_DAYS_OF_WEEK = [
    {'value': 'mon', 'label': 'Mon'},
    {'value': 'tue', 'label': 'Tue'},
    {'value': 'wed', 'label': 'Wed'},
    {'value': 'thu', 'label': 'Thu'},
    {'value': 'fri', 'label': 'Fri'},
    {'value': 'sat', 'label': 'Sat'},
    {'value': 'sun', 'label': 'Sun'},
]
_VALID_DAY_VALUES = {d['value'] for d in _DAYS_OF_WEEK}


def _human_dt(dt):
    """Format a datetime for an admin table — returns '' on falsy."""
    if not dt:
        return ''
    try:
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return str(dt)


def _human_duration(start, end):
    if not start or not end:
        return ''
    try:
        delta = end - start
        secs = int(delta.total_seconds())
    except Exception:
        return ''
    if secs < 0:
        return ''
    if secs < 60:
        return f'{secs}s'
    if secs < 3600:
        return f'{secs // 60}m {secs % 60}s'
    h = secs // 3600
    m = (secs % 3600) // 60
    return f'{h}h {m}m'


def _load_cron_settings():
    """Read all cron settings into one dict for the template."""
    from .db import get_system_setting
    raw_days = (get_system_setting('scrapers_cron_days') or '').strip()
    days = [d for d in raw_days.split(',') if d in _VALID_DAY_VALUES]
    try:
        count = int(get_system_setting('scrapers_cron_count') or 50)
    except (TypeError, ValueError):
        count = 50
    try:
        window = int(get_system_setting('scrapers_cron_window_minutes') or 30)
    except (TypeError, ValueError):
        window = 30
    return {
        'enabled':        bool(get_system_setting('scrapers_cron_enabled')),
        'at_utc':         (get_system_setting('scrapers_cron_at_utc') or '08:00').strip(),
        'days':           days,
        'count':          max(1, min(count, 500)),
        'window_minutes': max(1, min(window, 720)),
        'saved_at':       (get_system_setting('scrapers_cron_saved_at') or '').strip(),
    }


@admin_required
def admin_scraper_cron_view(request):
    """Render the Scraper → Cron sub-page: schedule editor, recent
    batches, and the live terminal panel."""
    from .db import recent_cron_batches
    cron = _load_cron_settings()
    raw_batches = recent_cron_batches(limit=20)
    batches = []
    for b in raw_batches:
        batches.append({
            'id':              b['id'],
            'started_human':   _human_dt(b.get('started_at')),
            'finished_human':  _human_dt(b.get('finished_at')),
            'duration_human':  _human_duration(b.get('started_at'), b.get('finished_at')),
            'status':          (b.get('status') or 'queued'),
            'note':            b.get('note') or '',
            'child_count':     int(b.get('child_count') or 0),
        })
    return render(request, 'core/admin_scraper_cron.html', {
        'cron':           cron,
        'days_of_week':   _DAYS_OF_WEEK,
        'batches':        batches,
        **_admin_base_ctx(request, 'scraper_cron'),
    })


@admin_required
@require_http_methods(['POST'])
def admin_scraper_cron_save(request):
    """Persist cron schedule settings to system_settings, then redirect
    back to the cron page with a success message."""
    from .db import set_system_setting
    from datetime import datetime as _dt
    enabled = request.POST.get('enabled') == '1'
    at_utc  = (request.POST.get('at_utc') or '08:00').strip()
    # Validate HH:MM, fall back to 08:00 if it's nonsense — never crash.
    if not re.fullmatch(r'\d{1,2}:\d{2}', at_utc):
        at_utc = '08:00'
    else:
        try:
            hh, mm = at_utc.split(':')
            at_utc = f'{int(hh):02d}:{int(mm):02d}'
            if not (0 <= int(hh) <= 23 and 0 <= int(mm) <= 59):
                at_utc = '08:00'
        except Exception:
            at_utc = '08:00'

    try:
        count = int(request.POST.get('count') or 50)
    except (TypeError, ValueError):
        count = 50
    count = max(1, min(count, 500))
    try:
        window = int(request.POST.get('window_minutes') or 30)
    except (TypeError, ValueError):
        window = 30
    window = max(1, min(window, 720))

    raw_days = request.POST.getlist('days')
    days = sorted({d for d in raw_days if d in _VALID_DAY_VALUES})

    set_system_setting('scrapers_cron_enabled', enabled)
    set_system_setting('scrapers_cron_at_utc', at_utc)
    set_system_setting('scrapers_cron_count', str(count))
    set_system_setting('scrapers_cron_window_minutes', str(window))
    set_system_setting('scrapers_cron_days', ','.join(days))
    set_system_setting(
        'scrapers_cron_saved_at',
        _dt.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC'),
    )
    return redirect('/admin-panel/scrapers/cron/')


# ── Firecrawl + Claude usage sub-pages ────────────────────────────────

def _firecrawl_cost_per_call() -> float:
    raw = get_system_setting('firecrawl_cost_per_call')
    try:
        return float(raw) if raw not in (None, '') else 0.0015
    except (TypeError, ValueError):
        return 0.0015


def _claude_cost_per_mtok() -> tuple:
    """Return (input_per_mtok, output_per_mtok). Defaults match Claude
    3.5 Sonnet pricing as of 2026."""
    def _f(key, default):
        raw = get_system_setting(key)
        try:
            return float(raw) if raw not in (None, '') else default
        except (TypeError, ValueError):
            return default
    return _f('claude_input_cost_per_mtok', 3.0), _f('claude_output_cost_per_mtok', 15.0)


@admin_required
def admin_scraper_firecrawl_view(request):
    """Firecrawl usage dashboard — KPIs, calls/day chart, recent
    failures, AND a paginated *All calls* table with source / state /
    city / status filters so admins can audit usage by location."""
    from .db import (firecrawl_usage_summary, list_firecrawl_calls,
                     list_firecrawl_call_filter_options)
    summary = firecrawl_usage_summary(days=30)
    cost_per_call = _firecrawl_cost_per_call()
    est_cost_30d = round(summary['totals']['calls_30d'] * cost_per_call, 2)

    # ── filter inputs ─────────────────────────────────────────────
    # Read once, normalise once, pass the SAME normalised values to
    # both the DB query and the template so the dropdowns reflect
    # what's actually being filtered (e.g. state shows up as upper).
    f_source = (request.GET.get('source') or '').strip()
    f_state  = (request.GET.get('state')  or '').strip().upper()
    f_city   = (request.GET.get('city')   or '').strip()
    f_status = (request.GET.get('status') or '').strip().lower()
    if f_status not in ('success', 'failed'):
        f_status = ''
    try:
        page = max(1, int(request.GET.get('page') or 1))
    except (TypeError, ValueError):
        page = 1
    page_size = 50
    start = (page - 1) * page_size

    rows, total_unfiltered, total_filtered = list_firecrawl_calls(
        source=f_source,
        state=f_state,
        city=f_city,
        status=f_status,
        start=start,
        length=page_size,
    )
    options = list_firecrawl_call_filter_options()

    # Pagination metadata — clamp page to last page if the filter set
    # changed between requests so we never render an empty table for a
    # page that no longer exists.
    page_count = max(1, (total_filtered + page_size - 1) // page_size)
    if page > page_count:
        page = page_count
        start = (page - 1) * page_size
        rows, _, _ = list_firecrawl_calls(
            source=f_source, state=f_state, city=f_city,
            status=f_status, start=start, length=page_size,
        )
    range_from = (start + 1) if rows else 0
    range_to   = start + len(rows)

    # Build the querystring without `page=` so pagination links can
    # append the page number without duplicating filter params.
    from urllib.parse import urlencode
    qs_pairs = [(k, v) for k, v in (
        ('source', f_source), ('state', f_state),
        ('city',   f_city),   ('status', f_status)) if v]
    base_qs = urlencode(qs_pairs)

    return render(request, 'core/admin_scraper_firecrawl.html', {
        'totals':           summary['totals'],
        'per_day':          summary['per_day'],
        'per_day_json':     json.dumps(summary['per_day']),
        'recent_failures':  summary['recent_failures'],
        'cost_per_call':    cost_per_call,
        'est_cost_30d':     est_cost_30d,
        # All-calls table + filter UI ─────────────────────────────
        'calls':                  rows,
        'calls_total':            total_unfiltered,
        'calls_filtered_total':   total_filtered,
        'calls_page':             page,
        'calls_page_count':       page_count,
        'calls_range_from':       range_from,
        'calls_range_to':         range_to,
        'calls_base_qs':          base_qs,
        'filter_source':          f_source,
        'filter_state':           f_state,
        'filter_city':            f_city,
        'filter_status':          f_status,
        'filter_sources':         options['sources'],
        'filter_states':          options['states'],
        'filter_cities_by_state_json':
            json.dumps(options['cities_by_state']),
        **_admin_base_ctx(request, 'scraper_firecrawl'),
    })


@admin_required
def admin_scraper_claude_view(request):
    """Claude usage dashboard — KPIs, tokens/day chart, recent failures."""
    from .db import claude_usage_summary
    summary = claude_usage_summary(days=30)
    in_per, out_per = _claude_cost_per_mtok()
    in_tok = summary['totals']['input_tokens_30d']
    out_tok = summary['totals']['output_tokens_30d']
    est_cost_30d = round(
        (in_tok / 1_000_000.0) * in_per + (out_tok / 1_000_000.0) * out_per,
        2,
    )
    return render(request, 'core/admin_scraper_claude.html', {
        'totals':           summary['totals'],
        'per_day':          summary['per_day'],
        'per_day_json':     json.dumps(summary['per_day']),
        'recent_failures':  summary['recent_failures'],
        'input_per_mtok':   in_per,
        'output_per_mtok':  out_per,
        'est_cost_30d':     est_cost_30d,
        **_admin_base_ctx(request, 'scraper_claude'),
    })


# ── Accela permit-search finder ───────────────────────────────────────
#
# Two endpoints:
#   GET  /admin-panel/scrapers/accela-search/        → the page.
#   POST /admin-panel/scrapers/accela-search/run/    → JSON, one city per
#                                                       call so the
#                                                       browser can
#                                                       update the table
#                                                       progressively.
#
# Per-city flow: hand the {city, state} pair to Firecrawl's autonomous
# Agent (`fc.agent(prompt=…, schema=…, model=…, max_credits=…)`) which
# does its own browsing/search and returns a structured pick (URL,
# confidence, reason). We enforce the accela.com host rule both in the
# prompt AND defensively in the Python response handler.

@admin_required
def admin_scraper_accela_search_view(request):
    """Render the Accela permit-search finder page.

    Embeds the curated per-state city list AND the Claude finder
    defaults (prompt template, model, max output tokens) so the controls
    at the top of the page render with sane initial values.

    The finder used to call the Firecrawl Agent SDK; it now calls
    Claude directly. We kept the same context variable names
    (``firecrawl_*``) so the template diff stays small — they're
    purely cosmetic identifiers, not engine-coupled.

    Also embeds the set of (state, city) pairs that ALREADY exist in
    the ``scrapers`` table so the JS can subtract them from the
    pre-populated city list — no point asking the AI to re-discover
    a URL we've already saved. The hint shown next to the textarea
    tells the admin how many were skipped.
    """
    from .us_cities_top import US_STATES, CITIES_BY_STATE
    from .scraper_accela import (
        ACCELA_FINDER_DEFAULT_PROMPT,
        ACCELA_FINDER_DEFAULT_MODEL,
        ACCELA_FINDER_VALID_MODELS,
        ACCELA_FINDER_DEFAULT_MAX_TOKENS,
        ACCELA_FINDER_MAX_TOKENS_CAP,
    )
    from .db import list_scraper_state_city_options
    # Prefer the admin-saved settings (system_settings) over the
    # hard-coded defaults from core/scraper_accela.py. This lets the
    # "Save settings" button on the card persist the prompt / model /
    # max_tokens across page reloads. Each lookup falls back to the
    # constant so a fresh install still renders sensible values.
    saved_prompt = (get_system_setting('accela_finder_prompt_template') or '').strip()
    saved_model  = (get_system_setting('accela_finder_model') or '').strip()
    saved_tokens_raw = (get_system_setting('accela_finder_max_tokens') or '').strip()
    saved_at     = (get_system_setting('accela_finder_settings_saved_at') or '').strip()

    initial_prompt = saved_prompt or ACCELA_FINDER_DEFAULT_PROMPT
    initial_model  = (saved_model
                      if saved_model in ACCELA_FINDER_VALID_MODELS
                      else ACCELA_FINDER_DEFAULT_MODEL)
    try:
        initial_tokens = int(saved_tokens_raw) if saved_tokens_raw else ACCELA_FINDER_DEFAULT_MAX_TOKENS
    except (TypeError, ValueError):
        initial_tokens = ACCELA_FINDER_DEFAULT_MAX_TOKENS
    # Clamp to [1, CAP] — Anthropic enforces its own per-model output
    # ceiling, but a sensible upper bound here prevents typos like
    # "50000" from sending oversized requests that would 400 anyway.
    initial_tokens = max(1, min(initial_tokens, ACCELA_FINDER_MAX_TOKENS_CAP))

    # Existing (state, city) pairs in the scrapers table — used by the
    # JS to filter the pre-populated city list. We compare on
    # title-cased city + uppercased state to match what
    # `create_scraper` stores. Cities in the curated list that don't
    # match exactly (e.g. "St. Petersburg" vs "Saint Petersburg") will
    # not be filtered out — the admin can still manually delete them
    # from the textarea, and the per-row dedup in the push endpoint is
    # the authoritative guard.
    existing = list_scraper_state_city_options().get('cities_by_state') or {}

    # Pass the raw dicts (not pre-serialized JSON) so the template can
    # use Django's `|json_script` filter, which escapes `<`, `>` and
    # `&` to prevent a `</script>` payload smuggled via a city name
    # from breaking out of the JSON island.
    return render(request, 'core/admin_scraper_accela_search.html', {
        'us_states':                   US_STATES,
        'cities_by_state':             CITIES_BY_STATE,
        'existing_cities_by_state':    existing,
        'firecrawl_default_prompt':    initial_prompt,
        'firecrawl_default_model':     initial_model,
        'firecrawl_models':            ACCELA_FINDER_VALID_MODELS,
        'firecrawl_default_credits':   initial_tokens,
        'firecrawl_credits_cap':       ACCELA_FINDER_MAX_TOKENS_CAP,
        'firecrawl_settings_saved_at': saved_at,
        **_admin_base_ctx(request, 'scraper_accela_search'),
    })


@admin_required
@require_http_methods(['POST'])
def admin_scraper_accela_search_save_settings(request):
    """Persist the Claude-finder settings shown at the top of the
    Accela permit-search finder page.

    Body (JSON): ``prompt_template`` (string ≤4000 chars),
    ``model`` (one of ``ACCELA_FINDER_VALID_MODELS`` — Claude models),
    ``max_credits`` (interpreted as max output tokens; positive int
    clamped to ``ACCELA_FINDER_MAX_TOKENS_CAP``). The legacy
    ``max_credits`` JSON key is preserved so the existing JS doesn't
    need to know the engine swapped. Returns ``{ok, saved_at}`` on
    success or ``{ok:false, error}`` with a 400/413 on bad input.
    """
    from .scraper_accela import (
        ACCELA_FINDER_VALID_MODELS,
        ACCELA_FINDER_MAX_TOKENS_CAP,
    )

    raw_body = request.body or b''
    if len(raw_body) > 16384:
        return JsonResponse({'ok': False, 'error': 'Request body too large.'},
                            status=413)

    if request.content_type and request.content_type.startswith('application/json'):
        try:
            payload = json.loads(raw_body.decode('utf-8') or '{}')
        except (json.JSONDecodeError, UnicodeDecodeError):
            return JsonResponse({'ok': False, 'error': 'Invalid JSON body.'},
                                status=400)
        if not isinstance(payload, dict):
            return JsonResponse(
                {'ok': False, 'error': 'JSON body must be an object.'},
                status=400,
            )
    else:
        payload = request.POST

    raw_prompt = payload.get('prompt_template', '')
    if not isinstance(raw_prompt, str):
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template must be a string.'},
            status=400,
        )
    prompt_template = raw_prompt.strip()
    if not prompt_template:
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template cannot be empty.'},
            status=400,
        )
    if len(prompt_template) > 4000:
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template too long (max 4000 chars).'},
            status=400,
        )

    raw_model = payload.get('model', '')
    if not isinstance(raw_model, str):
        return JsonResponse({'ok': False, 'error': 'model must be a string.'},
                            status=400)
    model = raw_model.strip()
    if model not in ACCELA_FINDER_VALID_MODELS:
        return JsonResponse({
            'ok': False,
            'error': f'model must be one of {list(ACCELA_FINDER_VALID_MODELS)}.',
        }, status=400)

    # The JSON key is still ``max_credits`` (legacy — the front-end
    # form input wasn't renamed to keep the diff small). It is now
    # interpreted as Claude's ``max_tokens``.
    raw_credits = payload.get('max_credits', None)
    if raw_credits is None or raw_credits == '':
        return JsonResponse(
            {'ok': False, 'error': 'max_tokens is required.'},
            status=400,
        )
    try:
        max_tokens = int(raw_credits)
    except (TypeError, ValueError):
        return JsonResponse(
            {'ok': False, 'error': 'max_tokens must be an integer.'},
            status=400,
        )
    if max_tokens < 1:
        return JsonResponse({
            'ok': False,
            'error': 'max_tokens must be a positive integer.',
        }, status=400)
    if max_tokens > ACCELA_FINDER_MAX_TOKENS_CAP:
        return JsonResponse({
            'ok': False,
            'error': f'max_tokens cannot exceed {ACCELA_FINDER_MAX_TOKENS_CAP}.',
        }, status=400)

    from .db import set_system_setting
    set_system_setting('accela_finder_prompt_template', prompt_template)
    set_system_setting('accela_finder_model',           model)
    set_system_setting('accela_finder_max_tokens',      str(max_tokens))
    saved_at = datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')
    set_system_setting('accela_finder_settings_saved_at', saved_at)

    return JsonResponse({'ok': True, 'saved_at': saved_at})


@admin_required
@require_http_methods(['POST'])
def admin_scraper_accela_search_run(request):
    """Run one city through Claude → JSON envelope, then auto-push it
    to the ``scrapers`` table if Claude returned a usable URL.

    Body (JSON): ``state`` (2-letter code), ``city`` (string), optional
    ``prompt_template``, ``model``, ``max_credits`` (legacy name —
    interpreted as Claude ``max_tokens``). Returns
    ``{ok, city, state, url, confidence, reason, error, log, auto_push}``
    where ``auto_push`` is one of::

        {'status': 'pushed',  'scraper_id', 'name', 'edit_url'}
        {'status': 'exists',  'existing': {...}}
        {'status': 'skipped', 'reason': str}        # no URL or low confidence
        {'status': 'invalid', 'error': str}         # bad accela URL
        {'status': 'error',   'error': str}         # DB / unexpected
        None                                         # Claude itself errored

    The auto-push wiring is per the admin's instruction: "ask him to
    return json contain exactly url city state and then insert them on
    scraper after receiving the data". ``ok=false`` is returned with
    HTTP 200 so the table can render Claude failures inline alongside
    successful rows.
    """
    from .scraper_accela import (
        claude_finder_pick, ScraperError,
        ACCELA_FINDER_VALID_MODELS,
    )
    from .us_cities_top import get_state_name

    # Accept either JSON or form-encoded — keeps the frontend tiny.
    # Cap the body at 16 KB — the prompt template can legitimately be a
    # few KB, but anything past 16 KB is almost certainly malformed and
    # would otherwise risk an opaque 500 from DATA_UPLOAD_MAX_MEMORY_SIZE.
    raw_body = request.body or b''
    if len(raw_body) > 16384:
        return JsonResponse({'ok': False, 'error': 'Request body too large.'},
                            status=413)

    if request.content_type and request.content_type.startswith('application/json'):
        try:
            payload = json.loads(raw_body.decode('utf-8') or '{}')
        except (json.JSONDecodeError, UnicodeDecodeError):
            return JsonResponse({'ok': False, 'error': 'Invalid JSON body.'},
                                status=400)
        if not isinstance(payload, dict):
            return JsonResponse(
                {'ok': False, 'error': 'JSON body must be an object.'},
                status=400,
            )
    else:
        payload = request.POST

    # `payload` is now either a dict or a Django QueryDict — both expose
    # .get(). Coerce values to str defensively because a JSON client can
    # legally send {"city": 123} or {"city": ["a","b"]}, neither of
    # which has .strip().
    raw_state = payload.get('state', '')
    raw_city  = payload.get('city',  '')
    if not isinstance(raw_state, str) or not isinstance(raw_city, str):
        return JsonResponse(
            {'ok': False, 'error': 'state and city must be strings.'},
            status=400,
        )
    state = raw_state.strip().upper()
    city  = raw_city.strip()
    if len(state) != 2 or not state.isalpha() or not city:
        return JsonResponse(
            {'ok': False, 'error': 'state (2-letter) and city are required.'},
            status=400,
        )
    if len(city) > 80:
        return JsonResponse({'ok': False, 'error': 'city name too long.'},
                            status=400)

    # Optional Firecrawl-agent knobs from the top-of-page form. None →
    # the helper falls back to its own defaults. Validate types and
    # ranges *here* so a bogus body returns a clean 400 envelope rather
    # than blowing up inside the SDK.
    raw_prompt = payload.get('prompt_template', None)
    if raw_prompt is not None and not isinstance(raw_prompt, str):
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template must be a string.'},
            status=400,
        )
    if isinstance(raw_prompt, str) and len(raw_prompt) > 4000:
        return JsonResponse(
            {'ok': False, 'error': 'prompt_template too long (max 4000 chars).'},
            status=400,
        )
    prompt_template = raw_prompt.strip() if isinstance(raw_prompt, str) else None

    raw_model = payload.get('model', None)
    if raw_model is not None and not isinstance(raw_model, str):
        return JsonResponse(
            {'ok': False, 'error': 'model must be a string.'},
            status=400,
        )
    model = raw_model.strip() if isinstance(raw_model, str) else None
    if model and model not in ACCELA_FINDER_VALID_MODELS:
        return JsonResponse({
            'ok': False,
            'error': f'model must be one of {list(ACCELA_FINDER_VALID_MODELS)}.',
        }, status=400)

    # Legacy JSON key — interpreted as Claude max_tokens. Front-end
    # form input wasn't renamed to keep the diff small.
    raw_credits = payload.get('max_credits', None)
    max_tokens = None
    if raw_credits is not None and raw_credits != '':
        try:
            max_tokens = int(raw_credits)
        except (TypeError, ValueError):
            return JsonResponse(
                {'ok': False, 'error': 'max_tokens must be an integer.'},
                status=400,
            )
        if max_tokens < 1:
            return JsonResponse({
                'ok': False,
                'error': 'max_tokens must be a positive integer.',
            }, status=400)

    state_name = get_state_name(state) or state

    try:
        result = claude_finder_pick(
            city, state_name,
            prompt_template=prompt_template,
            model=model,
            max_tokens=max_tokens,
        )
    except ScraperError as e:
        return JsonResponse({
            'ok':        False,
            'city':      city,
            'state':     state,
            'error':     str(e),
            'log':       None,
            'auto_push': None,
        })

    # ── Auto-push step: per admin's instruction, every successful
    # Claude response is immediately turned into a `scrapers` row (or
    # bounced as duplicate). The JS reads ``auto_push`` to render the
    # status pill — no manual click needed. We only push when Claude
    # returned a non-null URL; failures, host-rejected URLs, and
    # low-confidence picks-without-URL all surface as 'skipped'.
    auto_push = None
    chosen_url = result.get('url') if result.get('ok') else None
    if chosen_url:
        try:
            push_res = _create_or_dedup_accela_scraper(
                chosen_url, city, state, name='',
            )
            auto_push = push_res
        except Exception as e:
            log.exception('accela finder auto-push failed for %s/%s', state, city)
            auto_push = {'status': 'error', 'error': f'DB error: {e}'}
    elif result.get('ok'):
        auto_push = {'status': 'skipped',
                     'reason': result.get('reason') or 'No URL returned.'}

    return JsonResponse({
        'ok':         bool(result.get('ok')),
        'city':       city,
        'state':      state,
        'url':        result.get('url'),
        'confidence': result.get('confidence') or 'low',
        'reason':     result.get('reason') or '',
        'error':      result.get('error'),
        'log':        result.get('log'),
        'auto_push':  auto_push,
    })


@admin_required
@require_http_methods(['POST'])
def admin_scraper_accela_search_push(request):
    """Create a new ``scrapers`` row directly from a finder result.

    Removes the old "open the new-scraper popup pre-filled" dance —
    the admin clicks once and the scraper is live. Body (JSON):
    ``url`` (https accela.com), ``city`` (string), ``state``
    (2-letter), optional ``name`` (defaults to "{City} {ST} Accela
    Permits"). Returns ``{ok:true, scraper_id, name, edit_url}`` on
    success.

    Dedup behavior: if a scrapers row already exists for the same URL
    *or* the same (city, state) pair, returns HTTP 409 with
    ``{ok:false, error, existing:{id, name, url, city, state}}`` so
    the UI can render an "⚠ Already exists (View)" pill linking to
    the original. (city, state) match is the common case — same city
    pushed twice — and url match catches duplicates that landed under
    a different label.

    NOTE: the body of this endpoint is delegated to
    :func:`_create_or_dedup_accela_scraper` so the auto-push step in
    the finder ``…/run/`` view shares one source of truth for the
    advisory-locked dedup-then-insert.
    """
    raw_body = request.body or b''
    if len(raw_body) > 8192:
        return JsonResponse({'ok': False, 'error': 'Request body too large.'},
                            status=413)
    try:
        payload = json.loads(raw_body.decode('utf-8') or '{}')
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({'ok': False, 'error': 'Invalid JSON body.'},
                            status=400)
    if not isinstance(payload, dict):
        return JsonResponse({'ok': False, 'error': 'JSON body must be an object.'},
                            status=400)

    raw_url   = payload.get('url',   '')
    raw_city  = payload.get('city',  '')
    raw_state = payload.get('state', '')
    raw_name  = payload.get('name',  '')
    if not all(isinstance(v, str) for v in (raw_url, raw_city, raw_state, raw_name)):
        return JsonResponse(
            {'ok': False, 'error': 'url/city/state/name must be strings.'},
            status=400,
        )
    url   = raw_url.strip()
    city  = raw_city.strip()
    state = raw_state.strip().upper()
    name  = raw_name.strip()

    if not url or not url.lower().startswith('https://'):
        return JsonResponse({'ok': False, 'error': 'A full https:// URL is required.'},
                            status=400)
    if len(state) != 2 or not state.isalpha():
        return JsonResponse({'ok': False, 'error': 'state must be a 2-letter code.'},
                            status=400)
    if not city or len(city) > 80:
        return JsonResponse({'ok': False, 'error': 'city is required (≤80 chars).'},
                            status=400)
    if len(url) > 1000:
        return JsonResponse({'ok': False, 'error': 'url too long (max 1000 chars).'},
                            status=400)
    if len(name) > 200:
        return JsonResponse({'ok': False, 'error': 'name too long (max 200 chars).'},
                            status=400)

    result = _create_or_dedup_accela_scraper(url, city, state, name)
    if result['status'] == 'pushed':
        return JsonResponse({
            'ok':         True,
            'scraper_id': result['scraper_id'],
            'name':       result['name'],
            'edit_url':   result['edit_url'],
        })
    if result['status'] == 'exists':
        return JsonResponse({
            'ok':       False,
            'error':    'A scraper for this URL or city already exists.',
            'existing': result['existing'],
        }, status=409)
    # 'invalid' — bad accela URL after parsing
    return JsonResponse({
        'ok':    False,
        'error': result.get('error') or 'URL must be on accela.com (or a subdomain).',
    }, status=400)


def _create_or_dedup_accela_scraper(url: str, city: str, state: str,
                                    name: str = '') -> dict:
    """Shared helper used by both the manual ``…/push/`` endpoint and
    the auto-push step inside ``…/run/``.

    Returns one of three envelopes (no JsonResponse — callers wrap)::

        {'status': 'pushed',  'scraper_id': int, 'name': str, 'edit_url': str}
        {'status': 'exists',  'existing':   {'id': int, 'name': str, 'url': str,
                                             'city': str, 'state': str,
                                             'edit_url': str}}
        {'status': 'invalid', 'error':      str}

    Preconditions: caller has already validated url/city/state shape
    (length, scheme, etc.) — this helper still validates the accela
    host via ``parse_accela_url`` because it's the dedup-safety
    gate that protects the DB even if a future caller skimps on
    upstream checks.

    Race-safety: dedup-then-insert is wrapped in one Postgres txn with
    a per-(state, city) advisory lock so concurrent pushes for the
    same city serialise — the second caller sees the first one's row
    and returns ``status='exists'`` cleanly. Different cities don't
    block each other (different lock key).
    """
    from .db import pg
    from .scraper_accela import parse_accela_url

    # Defence-in-depth: the manual push endpoint already enforces
    # https://; the auto-push path goes through Claude which is told
    # to return https only — but Claude could still return an http://
    # link or a malformed URL. Require https here so this single
    # helper is the canonical gate for both paths.
    if not isinstance(url, str) or not url.lower().startswith('https://'):
        return {'status': 'invalid',
                'error':  'URL must start with https://.'}

    parsed = parse_accela_url(url)
    if not parsed:
        return {'status': 'invalid',
                'error':  'URL must be on accela.com (or a subdomain).'}

    # Mirror `create_scraper`'s column transforms so the dedup query
    # compares apples-to-apples with what would actually be stored.
    city_norm  = city.title()
    state_norm = state.upper()
    # Race-safety: dedup matches on URL OR (city, state), so we must
    # lock on BOTH keys — locking only the (city, state) pair allowed
    # two concurrent pushes of the same URL with DIFFERENT cities to
    # both insert, defeating URL-level dedup. Take the locks in
    # deterministic sort order to avoid AB/BA deadlock between
    # concurrent transactions racing on the same pair of keys.
    city_lock_key = f'scraper:push:city:{state_norm}:{city_norm.lower()}'
    url_lock_key  = f'scraper:push:url:{url.lower()}'
    lock_keys     = sorted({city_lock_key, url_lock_key})

    with pg.conn() as c, c.cursor() as cur:
        for lk in lock_keys:
            cur.execute('SELECT pg_advisory_xact_lock(hashtext(%s))', (lk,))
        cur.execute(
            """SELECT id, name, url, city, state
                 FROM scrapers
                WHERE LOWER(url) = LOWER(%s)
                   OR (city = %s AND state = %s)
                ORDER BY id ASC
                LIMIT 1""",
            (url, city_norm, state_norm),
        )
        existing_row = cur.fetchone()
        if existing_row:
            existing_dict = dict(existing_row)
            return {
                'status': 'exists',
                'existing': {
                    'id':       int(existing_dict['id']),
                    'name':     existing_dict.get('name') or '',
                    'url':      existing_dict.get('url') or '',
                    'city':     existing_dict.get('city') or '',
                    'state':    existing_dict.get('state') or '',
                    'edit_url': f'/admin-panel/scrapers/{int(existing_dict["id"])}/',
                },
            }

        final_name = (name or '').strip() or f'{city_norm} {state_norm} Accela Permits'
        # Wrap the INSERT in a SAVEPOINT so that if the partial unique
        # index `scrapers_accela_one_per_city_uidx` fires (race that
        # squeaked past the advisory lock, OR a future code path that
        # bypasses this helper entirely), we can ROLLBACK TO that
        # savepoint and continue running queries inside the same
        # outer transaction. Without this, Postgres marks the whole
        # transaction as aborted and the recovery SELECT below would
        # fail with InFailedSqlTransaction.
        cur.execute('SAVEPOINT accela_dedup_insert')
        try:
            cur.execute(
                """INSERT INTO scrapers (name, source, url, agency_code, module,
                                          cap_id_template, city, state, enabled, config)
                   VALUES (%s, %s, %s, %s, %s, %s::jsonb, %s, %s, %s, %s::jsonb)
                   RETURNING id""",
                (
                    final_name[:200],
                    'accela',
                    url,
                    (parsed.get('agency_code') or '').strip().upper() or None,
                    (parsed.get('module') or '').strip() or None,
                    json.dumps(parsed),
                    city_norm or None,
                    state_norm or None,
                    True,
                    json.dumps({}),
                ),
            )
            sid = int(cur.fetchone()['id'])
            cur.execute('RELEASE SAVEPOINT accela_dedup_insert')
        except psycopg.errors.UniqueViolation:
            cur.execute('ROLLBACK TO SAVEPOINT accela_dedup_insert')
            # Now safe to query within the same connection — the
            # partial-rollback brought the transaction back to the
            # state right before the failed INSERT.
            cur.execute(
                """SELECT id, name, url, city, state
                     FROM scrapers
                    WHERE source = 'accela'
                      AND state = %s AND LOWER(city) = LOWER(%s)
                    LIMIT 1""",
                (state_norm, city_norm),
            )
            row = cur.fetchone()
            if row:
                d = dict(row)
                return {
                    'status': 'exists',
                    'existing': {
                        'id':       int(d['id']),
                        'name':     d.get('name') or '',
                        'url':      d.get('url') or '',
                        'city':     d.get('city') or '',
                        'state':    d.get('state') or '',
                        'edit_url': f'/admin-panel/scrapers/{int(d["id"])}/',
                    },
                }
            # UniqueViolation but no matching row? Shouldn't happen —
            # surface explicitly instead of silently 500-ing.
            return {'status': 'invalid',
                    'error':  'Race during dedup — please retry.'}

    return {
        'status':     'pushed',
        'scraper_id': sid,
        'name':       final_name,
        'edit_url':   f'/admin-panel/scrapers/{sid}/',
    }


@admin_required
def admin_scraper_run_log_view(request, sid, rid):
    """Return one run's full step_log + permit-lineage summary as JSON.

    Powers the inline "📜 View log" panel on the scraper-detail page —
    the modal shows the CLI-style transcript the worker streamed PLUS
    a count and small preview of every permit this run created (so
    the admin can decide whether to delete-run or delete-run+permits).

    Scoped under the scraper id so the URL is self-explanatory and we
    can 404 cleanly when someone hand-edits the path with a run id
    that belongs to a different scraper.
    """
    from .db import (get_scraper_run, count_permits_for_run,
                     list_permits_for_run, get_scraper)
    if not get_scraper(sid):
        return JsonResponse({'ok': False, 'error': 'scraper not found'},
                            status=404)
    run = get_scraper_run(rid)
    if not run or int(run.get('scraper_id') or 0) != int(sid):
        return JsonResponse({'ok': False, 'error': 'run not found'},
                            status=404)
    permits = list_permits_for_run(rid, limit=200)
    return JsonResponse({
        'ok':              True,
        'run_id':          run['id'],
        'scraper_id':      run['scraper_id'],
        'status':          run.get('status'),
        'mode':            run.get('mode'),
        'kind':            run.get('kind'),
        'started_at':      str(run.get('started_at') or ''),
        'finished_at':     str(run.get('finished_at') or ''),
        'created_at':      str(run.get('created_at') or ''),
        'date_from':       str(run.get('date_from') or ''),
        'date_to':         str(run.get('date_to') or ''),
        'total_targets':   int(run.get('total_targets') or 0),
        'processed':       int(run.get('processed') or 0),
        'succeeded':       int(run.get('succeeded') or 0),
        'failed':          int(run.get('failed') or 0),
        'current_step':    run.get('current_step') or '',
        'step_log':        run.get('step_log') or [],
        'errors':          run.get('error') or [],
        # `permits_count` is the live link-back via permits.scraper_run_id —
        # always trust this over `succeeded` because a permit can be
        # deleted/relabelled later without touching the run row.
        'permits_count':   count_permits_for_run(rid),
        'permits_preview': [
            {
                'id':              p['id'],
                'permit_number':   p.get('permit_number') or '',
                'address':         p.get('address') or '',
                'city':            p.get('city') or '',
                'state':           p.get('state') or '',
                'contractor_name': p.get('contractor_name') or '',
                'applied_date':    str(p.get('applied_date') or ''),
                'issued_date':     str(p.get('issued_date') or ''),
                'valuation_cents': p.get('valuation_cents'),
                'ai_score':        p.get('ai_score'),
                'ai_grade':        p.get('ai_grade') or '',
            }
            for p in permits
        ],
    })


@admin_required
@require_http_methods(['POST'])
def admin_scraper_run_delete_view(request, sid, rid):
    """Delete one scraper run. Form param `delete_permits=on` opts into
    cascading the delete to every permit row that this run produced.

    Returns JSON when called with X-Requested-With (the inline modal),
    otherwise redirects back to the scraper detail page so plain
    `<form>` POSTs still work without JS.
    """
    from .db import delete_scraper_run, get_scraper, get_scraper_run, ScraperRunBusy
    if not get_scraper(sid):
        raise Http404
    run = get_scraper_run(rid)
    if not run or int(run.get('scraper_id') or 0) != int(sid):
        raise Http404
    delete_permits = (request.POST.get('delete_permits') or '').lower() in (
        '1', 'on', 'true', 'yes',
    )
    is_xhr = (request.headers.get('X-Requested-With') == 'XMLHttpRequest'
              or 'application/json' in (request.headers.get('Accept') or ''))
    try:
        result = delete_scraper_run(rid, delete_permits=delete_permits)
    except ScraperRunBusy as e:
        # Worker is still owning this run; refuse to race the cascade
        # against it. 409 Conflict so the JS surfaces a clean toast and
        # plain form-submit fallbacks land on a readable error page.
        if is_xhr:
            return JsonResponse(
                {'ok': False, 'error': str(e), 'code': 'run_busy'},
                status=409,
            )
        return HttpResponse(str(e), status=409, content_type='text/plain')
    if is_xhr:
        return JsonResponse({'ok': True, **result})
    return redirect(f'/admin-panel/scrapers/{sid}/')


# ── Scraper Logs (separate menu tab) ─────────────────────────────────
# Two-level nav: index lists every scraper with its run-history counts,
# detail shows ALL runs for one scraper plus a bulk-delete checkbox UI.
# We keep the "Recent runs" sidebar on the existing scraper detail page
# untouched — this is an additional surface, not a replacement.

@admin_required
def admin_scraper_logs_index_view(request):
    """List every scraper with run counts so admins can pick which one's
    history to manage. Uses the same search/pagination shape as the
    main /admin-panel/scrapers/ view so the muscle memory matches."""
    from .db import list_scrapers_with_run_counts
    q = (request.GET.get('q') or '').strip()
    try:
        page = int(request.GET.get('page') or 1)
    except (TypeError, ValueError):
        page = 1
    per_page = 50
    rows, total, total_pages, page = list_scrapers_with_run_counts(q, page, per_page)
    enriched = []
    for s in rows:
        url = s.get('url') or ''
        try:
            host = urllib.parse.urlparse(url).netloc or url
        except Exception:
            host = url
        last = s.get('last_run_at_actual') or s.get('last_run_at')
        enriched.append({
            **s,
            'host':           host,
            'last_run_human': last.strftime('%b %d, %Y %I:%M %p') if last else '—',
        })
    ctx = {
        **_admin_base_ctx(request, 'scraper_logs'),
        'scrapers':    enriched,
        'q':           q,
        'page':        page,
        'per_page':    per_page,
        'total':       total,
        'total_pages': total_pages,
        'has_prev':    page > 1,
        'has_next':    page < total_pages,
        'prev_page':   max(1, page - 1),
        'next_page':   min(total_pages, page + 1),
    }
    return render(request, 'core/admin_scraper_logs_index.html', ctx)


@admin_required
def admin_scraper_logs_detail_view(request, sid):
    """Show every run for one scraper with bulk-delete checkboxes.
    Limit defaults to 500 — more than enough for the UI; if anyone
    crosses that we'll add server-side pagination then."""
    from .db import get_scraper, list_scraper_runs, count_permits_for_run
    scraper = get_scraper(sid)
    if not scraper:
        raise Http404
    # Hard cap so the page never blows up on a runaway scraper. The
    # template surfaces this honestly via `truncated` so the admin
    # knows there's older history that the UI isn't showing.
    RUN_LIMIT = 500
    runs = list_scraper_runs(sid, limit=RUN_LIMIT + 1)
    truncated = len(runs) > RUN_LIMIT
    if truncated:
        runs = runs[:RUN_LIMIT]
    # Pre-compute the cascade preview so the admin sees "X permits
    # will be deleted" inline before ticking "with permits".
    enriched = []
    for r in runs:
        enriched.append({
            **r,
            'permits_count':  count_permits_for_run(r['id']),
            'created_human':  r['created_at'].strftime('%b %d, %Y %I:%M %p')
                              if r.get('created_at') else '—',
            'is_busy':        (r.get('status') or '').lower() in ('queued', 'running'),
        })
    ctx = {
        **_admin_base_ctx(request, 'scraper_logs'),
        'scraper':       scraper,
        'runs':          enriched,
        'total_runs':    len(enriched),
        'truncated':     truncated,
        'run_limit':     RUN_LIMIT,
    }
    return render(request, 'core/admin_scraper_logs_detail.html', ctx)


@admin_required
@require_http_methods(['POST'])
def admin_scraper_logs_bulk_delete_view(request, sid):
    """Bulk-delete runs from the scraper-logs detail page. Accepts:
      • ``run_ids`` — repeated form param (one per checked checkbox)
      • ``delete_permits=on`` — opt-in cascade

    Returns JSON for XHR, redirects for plain form POSTs (with a
    ``?msg=`` so the receiving page can flash a confirmation toast)."""
    from .db import get_scraper, bulk_delete_scraper_runs
    scraper = get_scraper(sid)
    if not scraper:
        raise Http404
    raw_ids = request.POST.getlist('run_ids')
    run_ids: list[int] = []
    for v in raw_ids:
        try:
            run_ids.append(int(v))
        except (TypeError, ValueError):
            continue
    delete_permits = (request.POST.get('delete_permits') or '').lower() in (
        '1', 'on', 'true', 'yes',
    )
    is_xhr = (request.headers.get('X-Requested-With') == 'XMLHttpRequest'
              or 'application/json' in (request.headers.get('Accept') or ''))
    result = bulk_delete_scraper_runs(sid, run_ids, delete_permits=delete_permits)
    if is_xhr:
        return JsonResponse({'ok': True, **result})
    # Plain-form fallback: redirect with a small summary in the query
    # string so the detail page can flash a banner without us needing
    # session-based messages framework wiring.
    msg = f"Deleted {result['runs_deleted']} run(s)"
    if delete_permits and result['permits_deleted']:
        msg += f" + {result['permits_deleted']} permit(s)"
    if result['busy']:
        msg += f" · skipped {len(result['busy'])} in-flight"
    return redirect(f"/admin-panel/scraper-logs/{sid}/?msg={urllib.parse.quote(msg)}")


@admin_required
def admin_permit_raw_view(request, pid):
    """Return the `raw` JSONB blob for one permit so the admin can
    audit exactly what Firecrawl saw — markdown, JSON extract, source
    URL, scrape mode, fetched-at. Used by the "View source" modal on
    the scraper detail page.

    Returns 404 if the permit doesn't exist OR isn't an Accela-scraped
    permit (we only want admins peeking at scrape provenance, not the
    seeded demo rows)."""
    from .db import pg
    row = pg.query_one(
        'SELECT id, source, source_permit_id, permit_number, address, '
        'city, state, raw, scraped_at, created_at '
        'FROM permits WHERE id = %s',
        (pid,),
    )
    if not row:
        return JsonResponse({'ok': False, 'error': 'Permit not found.'}, status=404)
    src = (row.get('source') or '')
    if not src.startswith('accela:'):
        return JsonResponse({'ok': False,
                             'error': 'Source page is only available for permits scraped by this system.'},
                            status=400)
    raw = row.get('raw') or {}
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            raw = {'markdown': raw}
    return JsonResponse({
        'ok':              True,
        'permit_id':       row['id'],
        'permit_number':   row.get('permit_number') or '',
        'address':         row.get('address') or '',
        'city':            row.get('city') or '',
        'state':           row.get('state') or '',
        'scraped_url':     raw.get('scraped_url') or '',
        'mode':            raw.get('mode') or 'detail',
        'fetched_at':      raw.get('fetched_at') or '',
        'markdown':        raw.get('markdown') or '',
        'firecrawl_json':  raw.get('firecrawl_json') or raw.get('list_row') or {},
        'metadata':        raw.get('firecrawl_metadata') or {},
    })


@admin_required
@require_http_methods(['POST'])
def admin_scraper_delete(request, sid):
    from .db import delete_scraper, get_scraper
    if not get_scraper(sid):
        raise Http404
    delete_scraper(sid)
    return redirect('/admin-panel/scrapers/')


@admin_required
@require_http_methods(['POST'])
def admin_scraper_update_meta(request, sid):
    """Patch scraper name / url / city / state from the inline Edit
    modal on /admin-panel/scrapers/. Returns JSON {ok: true} on
    success or {ok: false, error: '…'} on validation failure.

    The URL is required and validated as http(s)://… so a typo
    cannot brick the scraper by pointing it at a relative path.
    City / state may be cleared by posting an empty string."""
    from .db import get_scraper, update_scraper
    if not get_scraper(sid):
        raise Http404
    name  = (request.POST.get('name')  or '').strip()
    url   = (request.POST.get('url')   or '').strip()
    city  = (request.POST.get('city')  or '').strip()
    state = (request.POST.get('state') or '').strip().upper()
    if not name:
        return JsonResponse({'ok': False, 'error': 'Name is required.'}, status=400)
    if len(name) > 200:
        return JsonResponse({'ok': False, 'error': 'Name must be 200 characters or fewer.'}, status=400)
    if not url:
        return JsonResponse({'ok': False, 'error': 'URL is required.'}, status=400)
    if not (url.startswith('http://') or url.startswith('https://')):
        return JsonResponse({'ok': False, 'error': 'URL must start with http:// or https://'}, status=400)
    if len(url) > 2000:
        return JsonResponse({'ok': False, 'error': 'URL is too long.'}, status=400)
    if state and (len(state) != 2 or not state.isalpha()):
        return JsonResponse({'ok': False, 'error': 'State must be a 2-letter postal code (e.g. CA).'}, status=400)
    if len(city) > 120:
        return JsonResponse({'ok': False, 'error': 'City name is too long.'}, status=400)
    # ── Auto-infer state from the trailing 2-letter token of `name`
    # when the admin left the State field blank. Every scraper in the
    # app is named "{City} {ST}" by convention, so a row called
    # "Fremont CA" with an empty state field is almost always a slip
    # of the keyboard — not an intentional NULL. We only accept a
    # real US state code (rejects "Lehigh Acres FL" → "FL" ✓ but also
    # blocks "Permit-Search GO" → "GO" ✗ because GO isn't a state).
    if not state:
        from .us_cities_top import STATE_NAME_BY_CODE
        tail = (name.rsplit(' ', 1)[-1] if ' ' in name else '').upper()
        if len(tail) == 2 and tail.isalpha() and tail in STATE_NAME_BY_CODE:
            state = tail
    update_scraper(
        sid,
        name  = name,
        url   = url,
        city  = city  or None,
        state = state or None,
    )
    # Echo the resolved state back so the client can show the inferred
    # value as a friendly toast / hint without re-querying.
    return JsonResponse({'ok': True, 'state': state or ''})


@admin_required
def admin_scraper_settings_view(request):
    """Firecrawl + Claude key + cron toggle. Keys are SHARED with the
    blog AI subsystem — saving here updates the same setting."""
    from .db import get_system_setting, set_system_setting
    msg = None
    err = None
    if request.method == 'POST':
        action = (request.POST.get('action') or 'save').strip()
        if action == 'save':
            fc = (request.POST.get('firecrawl_api_key') or '').strip()
            ck = (request.POST.get('claude_api_key')    or '').strip()
            cm = (request.POST.get('claude_model')      or '').strip()
            ep = (request.POST.get('extraction_prompt') or '').strip()
            cron_on = request.POST.get('scrapers_cron_enabled') == 'on'
            # Only overwrite the key when a non-empty value is posted,
            # so the masked placeholder doesn't wipe a stored secret.
            if fc:
                set_system_setting('firecrawl_api_key', fc)
            if ck:
                set_system_setting('claude_api_key', ck)
            if cm:
                set_system_setting('claude_model', cm)
            # The unified extraction-prompt textarea IS posted on every
            # save — empty value means "use the built-in default" (we
            # store an empty string and `get_extraction_prompt()` falls
            # back to the constant). The legacy list-only prompt is
            # retired; the worker now wraps THIS prompt with built-in
            # list-page directives at scrape time.
            set_system_setting('extraction_prompt', ep)
            set_system_setting('scrapers_cron_enabled', cron_on)
            msg = 'Settings saved.'
        elif action == 'clear_firecrawl':
            set_system_setting('firecrawl_api_key', '')
            msg = 'Firecrawl key cleared.'
        elif action == 'clear_claude':
            set_system_setting('claude_api_key', '')
            msg = 'Claude key cleared.'
        elif action == 'reset_prompt':
            set_system_setting('extraction_prompt', '')
            msg = 'Extraction prompt reset to built-in default.'
    from .scraper_accela import EXTRACT_SYSTEM_PROMPT, get_extraction_prompt
    fc_set = bool((get_system_setting('firecrawl_api_key') or '').strip())
    ck_set = bool((get_system_setting('claude_api_key')   or '').strip())
    prompt_override = (get_system_setting('extraction_prompt') or '').strip()
    ctx = {
        **_admin_base_ctx(request, 'scraper_settings'),
        'has_firecrawl':              fc_set,
        'has_claude':                 ck_set,
        'claude_model':               (get_system_setting('claude_model') or '').strip()
                                       or 'claude-3-5-sonnet-latest',
        'scrapers_cron_enabled':      bool(get_system_setting('scrapers_cron_enabled')),
        # Show what's CURRENTLY active in the textarea (override or
        # default). Admin edits, saves → becomes the override; blank +
        # save → falls back to the default.
        'extraction_prompt':          get_extraction_prompt(),
        'is_prompt_overridden':       bool(prompt_override),
        'msg':                        msg,
        'err':                        err,
    }
    return render(request, 'core/admin_scraper_settings.html', ctx)


@admin_required
def admin_scraper_stats_view(request):
    """Daily chart + summary cards across all scrapers."""
    from .db import (get_scraper_summary, get_scraper_daily_stats,
                     list_recent_scraper_runs)
    summary = get_scraper_summary()
    days = get_scraper_daily_stats(30)
    max_permits = max((d['permits'] for d in days), default=1) or 1
    for d in days:
        d['bar_pct'] = round(100 * d['permits'] / max_permits, 1) if max_permits else 0
    recent_runs = list_recent_scraper_runs(15)
    for r in recent_runs:
        r['started_human'] = (r['started_at'].strftime('%b %d %I:%M %p')
                              if r.get('started_at') else '—')
    ctx = {
        **_admin_base_ctx(request, 'scraper_stats'),
        'summary':     summary,
        'days':        days,
        'recent_runs': recent_runs,
    }
    return render(request, 'core/admin_scraper_stats.html', ctx)


def _enrich_users_for_admin_table(all_users):
    """Add display-only fields the admin Users table renders.

    Extracted so both the page-shell view (``admin_users_view``) and
    the htmx rows partial (``admin_users_rows_view``) can share the
    exact same enrichment — guarantees the partial-loaded table is
    byte-identical to the legacy inline-rendered version.
    """
    sorted_users = sorted(all_users, key=lambda u: u.get('joined', '2000-01-01'), reverse=True)
    for u in sorted_users:
        plan = u.get('plan', 'starter').lower()
        u['is_admin']     = u.get('email') in ADMIN_EMAILS
        # "No Plan" — user signed up but never completed a Whop checkout
        # (or their subscription expired / was cancelled fully). The
        # plan field defaults to 'starter' on signup, so without this
        # flag the admin table would dishonestly show every brand-new
        # signup as a paying $29/mo Starter customer. Admins are
        # exempted because their access doesn't go through Whop —
        # they're allow-listed by email.
        u['is_no_plan']   = not (u['is_admin'] or u.get('subscription_active'))
        # Revenue column shows $0 for no-plan users so MRR totals on
        # the admin Users tab match what's actually being collected.
        u['price']        = 0 if u['is_no_plan'] else PLAN_PRICE.get(plan, 0)
        raw_cities        = u.get('cities', [])
        u['cities_count'] = len(raw_cities)
        u['cities']       = [
            c if ', ' in c else (c + ', ' + _city_state(c) if _city_state(c) else c)
            for c in raw_cities
        ]
        parts = u.get('name', '').split()
        u['avatar_initials'] = (parts[0][0] + parts[-1][0]).upper() if len(parts) >= 2 else u.get('name', 'U')[:2].upper()
        # Per-user Whop billing mode for the admin toggle column.
        # Treat any value other than 'dev' as 'prod' so legacy users
        # without the field rendered before the migration default to live.
        u['whop_mode'] = 'dev' if u.get('whop_mode') == 'dev' else 'prod'
        # Per-user email-code login verification state for the admin
        # toggle column. The stored field is `email_code_disabled`
        # (default missing/False = code REQUIRED) but the template
        # renders an `email_code` string of 'on' | 'off' so the
        # toggle pill HTML mirrors the Whop PROD/DEV pattern.
        u['email_code'] = 'off' if u.get('email_code_disabled') else 'on'
    return sorted_users


@admin_required
@cached_admin_html(15)
def admin_users_view(request):
    """Admin Users page — renders the page chrome + stats only.

    The actual table rows are loaded async via htmx from
    ``/admin-panel/users/_rows/`` (see ``admin_users_rows_view``).
    Splitting the heavy per-user enrichment + 25 KB of <tr> markup
    into a separate request lets the shell ship in <50 ms even on a
    cold worker, instead of staring at a blank page for 200-300 ms
    while the entire users list is enriched and rendered.
    """
    all_users   = get_all_users()
    today       = date.today()
    plan_counts = _admin_plan_counts(all_users)
    this_month  = today.strftime('%Y-%m')
    new_this_month = sum(1 for u in all_users if u.get('joined', '').startswith(this_month))
    ctx = {
        **_admin_base_ctx(request, 'users'),
        # The table body is now loaded by htmx, so the shell doesn't
        # need the full users list — just the count for the heading.
        'users':          [],
        'total_users':    len(all_users),
        'plan_counts':    plan_counts,
        'new_this_month': new_this_month,
        'deleted':        request.GET.get('deleted', ''),
        'banned':         request.GET.get('banned', ''),
        'bulk_deleted':   request.GET.get('bulk_deleted', ''),
        'bulk_self':      request.GET.get('bulk_self', ''),
        'bulk_admin':     request.GET.get('bulk_admin', ''),
        'bulk_synced':    request.GET.get('bulk_synced', ''),
        'bulk_no_member': request.GET.get('bulk_no_member', ''),
        'bulk_failed':    request.GET.get('bulk_failed', ''),
        'mode_set':       request.GET.get('mode_set', ''),
        'bulk_mode':      request.GET.get('bulk_mode', ''),
        'mode':           request.GET.get('mode', ''),
        # Per-user email-code login verification toggle outcomes.
        # Mirrors the mode_set / mode pair so the same toast pattern
        # at the top of admin_users.html can render the result.
        'email_code_set': request.GET.get('email_code_set', ''),
        'email_code':     request.GET.get('email_code', ''),
    }
    return render(request, 'core/admin_users.html', ctx)


@admin_required
@cached_admin_html(15)
def admin_users_rows_view(request):
    """htmx partial: just the <tr> rows for the admin Users table.

    Returned to the ``hx-get="/admin-panel/users/_rows/"`` request the
    main ``admin_users.html`` page fires the moment its empty <tbody>
    enters the DOM. Cached for 15 s like every other admin GET, and
    invalidated automatically by ``AdminHTMLCacheInvalidationMiddleware``
    when any admin write happens (delete user, flip whop mode, etc.).
    """
    sorted_users = _enrich_users_for_admin_table(list(get_all_users()))
    return render(request, 'core/_admin_users_rows.html', {'users': sorted_users})


@admin_required
@cached_admin_html(15)
def admin_affiliates_view(request):
    """Admin → Affiliates: platform-wide stats + per-user referral table.

    Shows the top of funnel (signups via referral) and the bottom (paid
    conversions + commission paid out). The per-user table lists every
    user who has at least one referral event so admins can see who their
    affiliates actually are without scanning the full users table.
    """
    totals    = get_total_affiliate_stats()
    referrers = get_all_referrers_with_stats()

    # Decorate each row with display-friendly fields the template can dump
    # straight into the table without extra logic.
    for r in referrers:
        r['avatar_initials'] = r.get('avatar_initials') or (
            ''.join(w[0].upper() for w in (r.get('name') or r.get('email','U')).split()[:2])
            or (r.get('email','U')[:2].upper())
        )
        r['earnings'] = f"${r['earnings_cents']/100:,.2f}"
        try:
            r['last_event_fmt'] = (r['last_event_at'].strftime('%b %d, %Y · %H:%M')
                                   if r.get('last_event_at') else '—')
        except Exception:
            r['last_event_fmt'] = '—'
        r['conv_pct'] = (round(100 * r['paid'] / r['signups']) if r['signups'] else 0)

    pct_raw = get_system_setting('affiliate_commission_pct', 20)
    try:
        pct = int(pct_raw)
    except (TypeError, ValueError):
        pct = 20

    ctx = {
        **_admin_base_ctx(request, 'affiliates'),
        'commission_pct':       pct,
        'active_affiliates':    totals['active_affiliates'],
        'total_signups':        totals['total_signups'],
        'total_paid':           totals['total_paid'],
        'total_earnings':       f"${totals['total_earnings_cents']/100:,.2f}",
        'total_earnings_cents': totals['total_earnings_cents'],
        'overall_conv_pct':     (round(100 * totals['total_paid'] / totals['total_signups'])
                                 if totals['total_signups'] else 0),
        'referrers':            referrers,
        'has_any':              bool(referrers),
    }
    return render(request, 'core/admin_affiliates.html', ctx)


@admin_required
@cached_admin_html(15)
def admin_revenue_view(request):
    # Mirrors the Whop merchant dashboard: a "Today" panel (gross today vs
    # yesterday with an hourly sparkline) and a "Stats" panel with a
    # date-range picker (1d/7d/30d/90d/365d) that drives 5 KPI line charts
    # (Gross / Net / New users / MRR / ARR) plus a payments-status
    # breakdown bar. All numbers come from Whop's memberships+payments
    # APIs (5-min in-process cache) — we fall back to a minimal local-DB
    # snapshot only when Whop is unreachable, so the page never blanks on
    # a transient API blip.
    range_key = request.GET.get('range', '7d')
    try:
        from .whop import get_revenue_stats, _RANGE_OPTIONS
        if range_key not in _RANGE_OPTIONS:
            range_key = '7d'
        whop_stats = get_revenue_stats(range_key=range_key)
    except Exception:
        whop_stats = None

    if whop_stats:
        ctx = {
            **_admin_base_ctx(request, 'revenue'),
            'whop':         whop_stats,
            'range_key':    range_key,
            'data_source':  'whop',
        }
        resp = render(request, 'core/admin_revenue.html', ctx)
        # Opt out of the @cached_admin_html(15) HTML cache when we're
        # serving a degraded payload (payments endpoint failed) so the
        # next request retries instead of pinning the missing chart for
        # 15 seconds. core.cache.cached_admin_html honours no-store.
        if not whop_stats.get('payments_ok'):
            resp['Cache-Control'] = 'no-store'
        return resp

    # ── Fallback: minimal local-DB snapshot (Whop unreachable) ───────
    all_users   = get_all_users()
    plan_counts = _admin_plan_counts(all_users)
    mrr         = sum(PLAN_PRICE.get(p, 0) * n for p, n in plan_counts.items())
    active_subs = plan_counts['pro'] + plan_counts['agency']
    ctx = {
        **_admin_base_ctx(request, 'revenue'),
        'whop':         None,
        'range_key':    range_key,
        'data_source':  'local',
        'fallback': {
            'mrr':         mrr,
            'active_subs': active_subs,
            'plan_counts': plan_counts,
            'total_users': len(all_users),
        },
    }
    return render(request, 'core/admin_revenue.html', ctx)


@admin_required
@cached_admin_html(15)
def admin_cities_view(request):
    all_users   = get_all_users()
    city_counts: dict = {}
    for u in all_users:
        for c in u.get('cities', []):
            city_counts[c] = city_counts.get(c, 0) + 1
    all_cities = sorted(city_counts.items(), key=lambda x: x[1], reverse=True)
    top_city_name  = all_cities[0][0] if all_cities else '—'
    top_city_count = all_cities[0][1] if all_cities else 1
    ctx = {
        **_admin_base_ctx(request, 'cities'),
        'all_cities':     all_cities,
        'total_cities':   len(all_cities),
        'total_users':    len(all_users),
        'top_city_name':  top_city_name,
        'top_city_count': top_city_count,
    }
    return render(request, 'core/admin_cities.html', ctx)


@admin_required
def admin_cities_manager_view(request):
    msg   = ''
    error = ''
    if request.method == 'POST':
        action = request.POST.get('action', '')
        city   = request.POST.get('city', '').strip().title()
        state  = request.POST.get('state', '').strip().upper()
        if action == 'add':
            if not city or not state:
                error = 'City and state are required.'
            elif add_supported_city(city, state):
                msg = f'{city}, {state} added successfully.'
            else:
                error = f'{city} is already in the supported cities list.'
        elif action == 'remove':
            if remove_supported_city(city):
                msg = f'{city} removed from supported cities.'
            else:
                error = f'City "{city}" not found.'
        elif action == 'bulk_remove':
            names = [n.strip() for n in request.POST.getlist('city_names') if n.strip()]
            removed = bulk_remove_supported_cities(names)
            if removed:
                msg = f'Removed {removed} cit{"y" if removed == 1 else "ies"} from supported list.'
            else:
                error = 'No matching cities were removed.'
    supported = get_supported_cities()
    states = sorted({c['state'] for c in supported})
    ctx = {
        **_admin_base_ctx(request, 'cities_manager'),
        'supported':   supported,
        'states':      states,
        'city_count':  len(supported),
        'state_count': len(states),
        'msg':         msg,
        'error':       error,
    }
    return render(request, 'core/admin_cities_manager.html', ctx)


@admin_required
@cached_admin_html(15)
def admin_banned_view(request):
    banned_list = get_all_banned()
    ctx = {
        **_admin_base_ctx(request, 'banned'),
        'banned_list': banned_list,
        'unbanned':    request.GET.get('unbanned', ''),
        'banned_count': len(banned_list),
    }
    return render(request, 'core/admin_banned.html', ctx)


_EMAIL_SERVICES = {
    'billing': {
        'label':       'Billing',
        'icon_color':  '#1d4ed8',
        'bg_color':    'rgba(29,78,216,.1)',
        'description': 'Invoices, plan changes, payment confirmations, and upgrade/downgrade notices.',
        'defaults': {
            'from_email':  'billing@permitlify.com',
            'from_name':   'Permitlify Billing',
            'reply_to':    'billing@permitlify.com',
        },
        'events': [
            {'label': 'Plan upgraded',         'note': 'Sent on upgrade'},
            {'label': 'Plan downgraded',       'note': 'Sent on downgrade'},
            {'label': 'Trial started',         'note': 'Welcome + trial details'},
            {'label': 'Payment receipt',       'note': 'Via Whop'},
            {'label': 'Subscription cancelled','note': 'Via Whop'},
        ],
    },
    'support': {
        'label':       'Support',
        'icon_color':  '#059669',
        'bg_color':    'rgba(5,150,105,.1)',
        'description': 'Ticket confirmations, agent replies, and resolution notices.',
        'defaults': {
            'from_email':  'support@permitlify.com',
            'from_name':   'Permitlify Support',
            'reply_to':    'support@permitlify.com',
        },
        'events': [
            {'label': 'Ticket opened',         'note': 'Confirmation to user'},
            {'label': 'Agent reply',           'note': 'Notifies user of response'},
            {'label': 'Ticket resolved',       'note': 'Closure notice + CSAT'},
        ],
    },
    'alerts': {
        'label':       'Alerts & Notifications',
        'icon_color':  '#dc2626',
        'bg_color':    'rgba(220,38,38,.08)',
        'description': 'Hot lead alerts, daily digests, weekly performance reports, and city coverage updates.',
        'defaults': {
            'from_email':  'alerts@permitlify.com',
            'from_name':   'Permitlify Alerts',
            'reply_to':    'noreply@permitlify.com',
        },
        'events': [
            {'label': 'Hot lead alert (80+)',  'note': 'Within 5 min of filing'},
            {'label': 'Daily digest',          'note': 'Every morning at 6 AM'},
            {'label': 'Weekly report',         'note': 'Monday 6 AM'},
            {'label': 'New city coverage',     'note': 'On coverage expansion'},
        ],
    },
    'marketing': {
        'label':       'Marketing & Onboarding',
        'icon_color':  '#d97706',
        'bg_color':    'rgba(217,119,6,.08)',
        'description': 'Welcome sequences, product updates, feature announcements, and newsletters.',
        'defaults': {
            'from_email':  'hello@permitlify.com',
            'from_name':   'Permitlify Team',
            'reply_to':    'hello@permitlify.com',
        },
        'events': [
            {'label': 'Welcome email',         'note': 'On signup'},
            {'label': 'Onboarding tips',       'note': 'Day 1, 3, 7 sequence'},
            {'label': 'Product update',        'note': 'On new feature launch'},
            {'label': 'Newsletter',            'note': 'Monthly digest'},
        ],
    },
    'system': {
        'label':       'System & Security',
        'icon_color':  '#6b7280',
        'bg_color':    'rgba(107,114,128,.1)',
        'description': 'Password resets, 2FA codes, login alerts, and account security notices.',
        'defaults': {
            'from_email':  'noreply@permitlify.com',
            'from_name':   'Permitlify',
            'reply_to':    '',
        },
        'events': [
            {'label': 'Password reset',        'note': 'Link valid for 1 hour'},
            {'label': '2FA code',              'note': 'Valid for 10 minutes'},
            {'label': 'New login alert',       'note': 'On unrecognised device'},
            {'label': 'Account locked',        'note': 'On repeated failed logins'},
        ],
    },
}


def _email_settings_current() -> dict:
    """Return all service email settings, falling back to defaults."""
    result = {}
    for svc, cfg in _EMAIL_SERVICES.items():
        result[svc] = {
            'from_email': get_system_setting(f'{svc}_from_email', cfg['defaults']['from_email']),
            'from_name':  get_system_setting(f'{svc}_from_name',  cfg['defaults']['from_name']),
            'reply_to':   get_system_setting(f'{svc}_reply_to',   cfg['defaults']['reply_to']),
        }
    return result


@admin_required
def admin_email_settings(request):
    """Admin page for per-service sender configuration + delivery testing.

    Three POST actions, all dispatched via the ``action`` field and all
    returning JSON when called with ``X-Requested-With: XMLHttpRequest``:

    * ``save``        — persist From / From Name / Reply-To for one service
    * ``test_send``   — send a real test email via the configured transport
                        (Resend if RESEND_API_KEY is set, otherwise SMTP)
    * ``verify``      — admin checked their inbox; mark the service as
                        verified (or clear verification)
    """
    from datetime import datetime, timezone
    from .email_service import send_email, get_service_health, get_transport_status, get_smtp_config, get_resend_api_key

    result = {'ok': False, 'action': '', 'service': '', 'error': '', 'detail': ''}

    if request.method == 'POST':
        action = (request.POST.get('action') or 'save').strip()
        svc    = (request.POST.get('service') or '').strip()

        # Transport credentials are global (not per-service), so we handle
        # them before the per-service dispatch.
        if action == 'save_transport':
            try:
                provider = (request.POST.get('provider') or 'resend').strip().lower()
                if provider == 'resend':
                    api_key = (request.POST.get('resend_api_key') or '').strip()
                    # Empty string is treated as "clear it"; non-empty replaces.
                    set_system_setting('email_resend_api_key', api_key)
                    detail = 'Resend API key cleared.' if not api_key else 'Resend API key saved.'
                elif provider == 'smtp':
                    fields = {
                        'email_smtp_host':     (request.POST.get('smtp_host') or '').strip(),
                        'email_smtp_port':     (request.POST.get('smtp_port') or '').strip() or '587',
                        'email_smtp_user':     (request.POST.get('smtp_user') or '').strip(),
                        'email_smtp_use_tls':  '1' if (request.POST.get('smtp_use_tls') or '').strip().lower() in ('1', 'true', 'yes', 'on') else '0',
                    }
                    pwd_raw = request.POST.get('smtp_password')
                    # Only overwrite the password if a new value was actually
                    # submitted — empty string from a "leave blank to keep"
                    # field shouldn't wipe the saved one.
                    if pwd_raw is not None and pwd_raw.strip():
                        fields['email_smtp_password'] = pwd_raw.strip()
                    for k, v in fields.items():
                        set_system_setting(k, v)
                    detail = 'SMTP settings saved.'
                elif provider == 'clear':
                    for k in ('email_resend_api_key', 'email_smtp_host', 'email_smtp_port',
                              'email_smtp_user', 'email_smtp_password', 'email_smtp_use_tls'):
                        set_system_setting(k, '')
                    detail = 'All transport credentials cleared.'
                else:
                    raise ValueError(f'Unknown provider "{provider}"')
                result = {'ok': True, 'action': 'save_transport', 'service': '',
                          'error': '', 'detail': detail}
            except Exception as e:
                result = {'ok': False, 'action': 'save_transport', 'service': '',
                          'error': str(e), 'detail': ''}

            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                payload = dict(result)
                payload['transport'] = get_transport_status()
                return JsonResponse(payload)

        elif svc not in _EMAIL_SERVICES:
            result = {'ok': False, 'action': action, 'service': svc,
                      'error': 'Unknown service.', 'detail': ''}
        elif action == 'save':
            try:
                for field in ('from_email', 'from_name', 'reply_to'):
                    val = request.POST.get(field, '').strip()
                    set_system_setting(f'{svc}_{field}', val)
                result = {'ok': True, 'action': 'save', 'service': svc,
                          'error': '', 'detail': 'Saved.'}
            except Exception as e:
                result = {'ok': False, 'action': 'save', 'service': svc,
                          'error': str(e), 'detail': ''}

        elif action == 'test_send':
            to_addr = (request.POST.get('to') or '').strip()
            subject = (request.POST.get('subject') or '').strip()
            body    = (request.POST.get('body') or '').strip()
            now_iso = datetime.now(timezone.utc).isoformat(timespec='seconds')
            ok, info = send_email(svc, to_addr, subject, body)
            try:
                set_system_setting(f'{svc}_last_test_at',     now_iso)
                set_system_setting(f'{svc}_last_test_to',     to_addr)
                set_system_setting(f'{svc}_last_test_status', 'sent' if ok else 'failed')
                set_system_setting(f'{svc}_last_test_error',  '' if ok else info)
            except Exception:
                pass
            result = {
                'ok': ok, 'action': 'test_send', 'service': svc,
                'error':  '' if ok else info,
                'detail': (f'Sent to {to_addr}. Check the inbox, then mark below.'
                           if ok else info),
            }

        elif action == 'verify':
            working = (request.POST.get('working') or '').strip().lower() in ('1', 'true', 'yes', 'on')
            try:
                if working:
                    set_system_setting(f'{svc}_verified_at',
                                       datetime.now(timezone.utc).isoformat(timespec='seconds'))
                    set_system_setting(f'{svc}_verified_by',
                                       request.session.get('user_email') or '')
                else:
                    set_system_setting(f'{svc}_verified_at', '')
                    set_system_setting(f'{svc}_verified_by', '')
                result = {'ok': True, 'action': 'verify', 'service': svc,
                          'error': '', 'detail': 'Marked working.' if working else 'Verification cleared.'}
            except Exception as e:
                result = {'ok': False, 'action': 'verify', 'service': svc,
                          'error': str(e), 'detail': ''}
        else:
            result = {'ok': False, 'action': action, 'service': svc,
                      'error': f'Unknown action "{action}".', 'detail': ''}

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            payload = dict(result)
            if action in ('test_send', 'verify'):
                payload['health'] = get_service_health(svc)
            return JsonResponse(payload)

    services_data = []
    current = _email_settings_current()
    admin_email = request.session.get('user_email') or ''
    transport_status = get_transport_status()
    smtp_cfg         = get_smtp_config()
    has_resend_key   = bool(get_resend_api_key())
    for svc_key, cfg in _EMAIL_SERVICES.items():
        vals = current[svc_key]
        defs = cfg['defaults']
        is_customised = (
            vals['from_email'] != defs['from_email'] or
            vals['from_name']  != defs['from_name']  or
            vals['reply_to']   != defs['reply_to']
        )
        services_data.append({
            'key':           svc_key,
            'label':         cfg['label'],
            'icon_color':    cfg['icon_color'],
            'bg_color':      cfg['bg_color'],
            'description':   cfg['description'],
            'events':        cfg['events'],
            'vals':          vals,
            'is_customised': is_customised,
            'health':        get_service_health(svc_key),
        })

    ctx = {
        **_admin_base_ctx(request, 'email_settings'),
        'services':             services_data,
        'save_result':          result,
        'admin_email':          admin_email,
        'transport_configured': transport_status['configured'],
        'transport_status':     transport_status,
        'has_resend_key':       has_resend_key,
        'smtp_cfg':             smtp_cfg,
    }
    return render(request, 'core/admin_email_settings.html', ctx)


@admin_required
def admin_whop_settings(request):
    """Admin page to manage Whop API credentials and checkout URLs."""

    _CHECKOUT_FIELDS = [
        ('starter_monthly', 'Starter — Monthly'),
        ('starter_annual',  'Starter — Annual'),
        ('pro_monthly',     'Pro — Monthly'),
        ('pro_annual',      'Pro — Annual'),
        ('agency_monthly',  'Agency — Monthly'),
        ('agency_annual',   'Agency — Annual'),
    ]
    _PLAN_ID_FIELDS = _CHECKOUT_FIELDS  # same 6 plan/period combos
    _CRED_FIELDS = [
        ('whop_api_key',        'API Key',        'password'),
        ('whop_webhook_secret', 'Webhook Secret', 'password'),
        ('whop_company_id',     'Company ID',     'text'),
    ]

    save_result = {'ok': False, 'section': '', 'error': ''}

    if request.method == 'POST':
        section = request.POST.get('section', '')
        try:
            if section == 'credentials':
                for key, _, _ in _CRED_FIELDS:
                    val = request.POST.get(key, '').strip()
                    if val:
                        set_system_setting(key, val)
                save_result = {'ok': True, 'section': 'credentials', 'error': ''}
            elif section == 'checkout_urls':
                for key, _ in _CHECKOUT_FIELDS:
                    val = request.POST.get(f'whop_checkout_{key}', '').strip()
                    if val:
                        set_system_setting(f'whop_checkout_{key}', val)
                save_result = {'ok': True, 'section': 'checkout_urls', 'error': ''}
            elif section == 'plan_ids_prod':
                for key, _ in _PLAN_ID_FIELDS:
                    val = request.POST.get(f'whop_plan_id_{key}', '').strip()
                    set_system_setting(f'whop_plan_id_{key}', val)
                save_result = {'ok': True, 'section': 'plan_ids_prod', 'error': ''}
            elif section == 'plan_ids_dev':
                for key, _ in _PLAN_ID_FIELDS:
                    val = request.POST.get(f'whop_plan_id_dev_{key}', '').strip()
                    set_system_setting(f'whop_plan_id_dev_{key}', val)
                save_result = {'ok': True, 'section': 'plan_ids_dev', 'error': ''}
            elif section == 'whop_mode':
                mode = request.POST.get('whop_mode', 'prod')
                if mode in ('dev', 'prod'):
                    set_system_setting('whop_mode', mode)
                save_result = {'ok': True, 'section': 'whop_mode', 'mode': mode, 'error': ''}
            elif section == 'plan_ids':
                for key, _ in _PLAN_ID_FIELDS:
                    val = request.POST.get(f'whop_plan_id_{key}', '').strip()
                    set_system_setting(f'whop_plan_id_{key}', val)
                save_result = {'ok': True, 'section': 'plan_ids', 'error': ''}
        except Exception as e:
            save_result = {'ok': False, 'section': section, 'error': str(e)}
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse(save_result)

    # Build current credential values (masked for display)
    from .db import get_all_system_settings
    all_settings = get_all_system_settings()

    creds = []
    for key, label, input_type in _CRED_FIELDS:
        raw = all_settings.get(key, '') or os.environ.get(key.upper(), '')
        masked = (raw[:6] + '••••••••••••') if raw else ''
        creds.append({'key': key, 'label': label, 'type': input_type, 'masked': masked, 'set': bool(raw)})

    checkout_urls = []
    for key, label in _CHECKOUT_FIELDS:
        db_key = f'whop_checkout_{key}'
        val    = all_settings.get(db_key) or wp.DEFAULT_CHECKOUT_URLS.get(key, '')
        checkout_urls.append({'key': key, 'label': label, 'url': val})

    whop_mode = all_settings.get('whop_mode', 'prod') or 'prod'
    plan_ids_prod = []
    plan_ids_dev  = []
    for key, label in _PLAN_ID_FIELDS:
        prod_val = all_settings.get(f'whop_plan_id_{key}', '') or ''
        dev_val  = all_settings.get(f'whop_plan_id_dev_{key}', '') or ''
        plan_ids_prod.append({'key': key, 'label': label, 'value': prod_val, 'set': bool(prod_val)})
        plan_ids_dev.append( {'key': key, 'label': label, 'value': dev_val,  'set': bool(dev_val)})

    ctx = {
        **_admin_base_ctx(request, 'whop_settings'),
        'creds':          creds,
        'checkout_urls':  checkout_urls,
        'plan_ids_prod':  plan_ids_prod,
        'plan_ids_dev':   plan_ids_dev,
        'whop_mode':      whop_mode,
        'save_result':    save_result,
        'webhook_events': [
            'membership.went_valid',
            'membership.went_invalid',
            'membership.cancelled',
            'payment.succeeded',
        ],
    }
    return render(request, 'core/admin_whop_settings.html', ctx)


@admin_required
@require_http_methods(['POST'])
def admin_whop_resync_user(request):
    """Admin-only: look up a user's Whop memberships by email, optionally
    apply the highest-tier valid one (or a specific one) to their account.

    This is the manual repair tool for the case where a user's plan in
    our database does not match their actual Whop subscription. The
    same code path that fires on every login (`_whop_login_sync`) is
    used here, so the result is identical — we just expose it as an
    admin action so admins can fix users who haven't logged in since
    the last bug-fix deploy, without making them log in.

    POST params:
      email   — required, the user's email
      action  — 'preview' (default): just look up, no writes
                'apply':              apply highest-tier valid membership
                'apply_id:<mem_id>':  apply a specific membership by ID

    Returns JSON with:
      memberships:  every membership Whop returned, with detected plan
      best_plan:    highest-tier valid plan
      applied:      the patch that was applied (or null on preview)
      user_*:       what the user record looked like before/after
    """
    email  = (request.POST.get('email') or '').strip().lower()
    action = (request.POST.get('action') or 'preview').strip()

    if not email:
        return JsonResponse({'ok': False, 'error': 'Email is required.'}, status=400)

    # Fetch from Whop. Generous 10s timeout — admin is waiting.
    try:
        mems = wp.get_memberships_by_email(email, timeout=10)
    except Exception as e:
        return JsonResponse({'ok': False, 'error': f'Whop lookup failed: {e}'}, status=502)

    enriched     = []
    best_mem     = None
    best_plan    = ''
    best_rank    = -1
    for m in mems:
        detected = wp.plan_from_membership(m, default='') or ''
        is_valid = bool(m.get('valid'))
        prod_obj = m.get('product')
        prod_id  = ''
        if isinstance(prod_obj, str):
            prod_id = prod_obj
        elif isinstance(prod_obj, dict):
            prod_id = prod_obj.get('id', '')
        enriched.append({
            'id':                   m.get('id', ''),
            'plan_id':              m.get('plan_id', '') or m.get('plan', ''),
            'product_id':           prod_id,
            'valid':                is_valid,
            'detected_plan':        detected,
            'cancel_at_period_end': bool(m.get('cancel_at_period_end')),
            'created_at':           m.get('created_at', 0),
            'expires_at':           m.get('expires_at') or m.get('renewal_period_end', 0),
            'status':               m.get('status', ''),
        })
        if is_valid:
            r = _PLAN_RANK.get(detected, -1)
            if r > best_rank:
                best_rank = r
                best_mem  = m
                best_plan = detected

    user        = get_user_by_email(email)
    user_found  = bool(user)
    response    = {
        'ok':                   True,
        'error':                '',
        'user_found':           user_found,
        'user_id':              (user.get('id') if user else None),
        'current_plan':         ((user.get('plan') or '') if user else ''),
        'current_membership_id': ((user.get('whop_membership_id') or '') if user else ''),
        'memberships':          enriched,
        'best_plan':            best_plan,
        'best_membership_id':   (best_mem.get('id', '') if best_mem else ''),
        'applied':              None,
    }

    if action == 'preview':
        return JsonResponse(response)

    if not user_found:
        return JsonResponse({**response, 'error': 'No user with that email in our DB.'}, status=404)

    # Pick the membership to apply.
    target      = None
    target_plan = ''
    if action == 'apply':
        if not best_mem:
            # No active membership at Whop -> deactivate the user, mirror
            # of the bulk no-member branch in admin_bulk_whop_sync. The
            # admin clicked "apply" on a user with zero valid Whop
            # memberships, so the right outcome is to demote them to
            # inactive (not return 400 and leave them stuck on a stale
            # paid plan). `plan` and `whop_membership_id` are kept as
            # historical breadcrumbs; entitlement checks (_api_auth,
            # has_ls_sub, admin table) are gated on subscription_active.
            from datetime import datetime, timezone
            now_iso = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
            patch = {
                'subscription_active': False,
                'whop_resync_pending': False,
                'whop_status':         'expired',
                'whop_paused':         False,
                'whop_cancelled':      False,
                'whop_renews_at':      '',
                'last_whop_sync_at':   now_iso,
            }
            try:
                update_user(user['id'], **patch)
            except Exception as e:
                return JsonResponse({**response,
                    'error': f'DB update failed: {e}'}, status=500)
            return JsonResponse({
                **response,
                'applied':   patch,
                'deactivated': True,
                'message':  'No active Whop membership for this email; '
                            'user marked inactive.',
            })
        target, target_plan = best_mem, best_plan
    elif action.startswith('apply_id:'):
        wanted = action.split(':', 1)[1].strip()
        for m in mems:
            if m.get('id') == wanted:
                target      = m
                target_plan = wp.plan_from_membership(m, default='') or ''
                break
        if not target:
            return JsonResponse({**response, 'error':
                f'Membership ID {wanted!r} not found for this email.'}, status=404)
    else:
        return JsonResponse({**response, 'error':
            f'Unknown action {action!r}.'}, status=400)

    from datetime import datetime, timezone
    now_iso = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    patch = {
        'whop_membership_id':  target.get('id', ''),
        'whop_cancelled':      bool(target.get('cancel_at_period_end')),
        'subscription_active': bool(target.get('valid', True)),
        'last_whop_sync_at':   now_iso,
        'whop_resync_pending': False,
    }
    if target_plan in ('starter', 'pro', 'agency'):
        patch['plan'] = target_plan

    try:
        update_user(user['id'], **patch)
    except Exception as e:
        return JsonResponse({**response, 'error': f'DB update failed: {e}'}, status=500)

    # Best-effort billing/invoice sync — don't fail the response on this.
    try:
        _sync_billing_and_invoice(user['id'], target)
    except Exception:
        pass

    response['applied'] = patch
    return JsonResponse(response)


@admin_required
@require_http_methods(['GET', 'POST'])
def admin_google_settings(request):
    """Admin page to manage the Google Sign-In OAuth client at runtime.

    Three save sections (POSTed individually, with section= ... in the body):
      * ``credentials`` — write google_client_id / google_client_secret.
        Empty values are skipped (so you can rotate one without re-typing the
        other). Use the ``clear_secret`` section to actively wipe the secret.
      * ``enabled`` — flip the master toggle on/off. The "Continue with
        Google" buttons on /login/ and /signup/ only show when this is on
        AND the credentials are filled in.
      * ``clear_secret`` — wipe the saved client_secret without touching the
        client_id. Useful when rotating or revoking.
    """
    save_result = {'ok': False, 'section': '', 'error': ''}

    if request.method == 'POST':
        section = request.POST.get('section', '')
        try:
            if section == 'credentials':
                cid = request.POST.get('google_client_id', '').strip()
                sec = request.POST.get('google_client_secret', '').strip()
                if cid:
                    set_system_setting('google_client_id', cid)
                if sec:
                    set_system_setting('google_client_secret', sec)
                save_result = {'ok': True, 'section': 'credentials', 'error': ''}
            elif section == 'enabled':
                enabled = request.POST.get('google_oauth_enabled') == 'on'
                set_system_setting('google_oauth_enabled', enabled)
                save_result = {'ok': True, 'section': 'enabled',
                               'enabled': enabled, 'error': ''}
            elif section == 'clear_secret':
                set_system_setting('google_client_secret', '')
                save_result = {'ok': True, 'section': 'clear_secret', 'error': ''}
            elif section == 'clear_client_id':
                set_system_setting('google_client_id', '')
                save_result = {'ok': True, 'section': 'clear_client_id', 'error': ''}
            elif section == 'urls':
                # Allow the admin to pin the exact origin + redirect URI we
                # send to Google. These MUST match what's registered on the
                # Google Cloud Console OAuth client. Empty values clear the
                # override and we fall back to auto-detect from the request.
                redir = request.POST.get('google_redirect_uri', '').strip()
                orig  = request.POST.get('google_authorized_origin', '').strip()
                # Light validation: must be absolute http(s) URLs when set.
                for label, val in (('redirect URI', redir), ('origin', orig)):
                    if val and not (val.startswith('http://') or val.startswith('https://')):
                        raise ValueError(f'{label.title()} must start with http:// or https://')
                if redir and not redir.endswith('/auth/google/callback/'):
                    raise ValueError('Redirect URI must end with /auth/google/callback/')
                set_system_setting('google_redirect_uri', redir)
                set_system_setting('google_authorized_origin', orig)
                save_result = {'ok': True, 'section': 'urls', 'error': ''}
            elif section == 'reset_urls':
                set_system_setting('google_redirect_uri', '')
                set_system_setting('google_authorized_origin', '')
                save_result = {'ok': True, 'section': 'reset_urls', 'error': ''}
        except Exception as e:
            save_result = {'ok': False, 'section': section, 'error': str(e)}
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse(save_result)

    from .google_auth import (
        get_google_settings,
        build_redirect_uri,
        auto_redirect_uri,
        auto_authorized_origin,
        get_redirect_uri_override,
        get_authorized_origin_override,
        is_google_oauth_ready,
    )
    s = get_google_settings()
    cid = s['client_id']
    sec = s['client_secret']
    masked_id = (cid[:14] + '…' + cid[-12:]) if len(cid) > 30 else (cid or '')
    masked_secret = (sec[:6] + '••••••••••••') if sec else ''

    redirect_override = get_redirect_uri_override()
    origin_override   = get_authorized_origin_override()
    auto_redir        = auto_redirect_uri(request)
    auto_origin       = auto_authorized_origin(request)
    effective_redir   = redirect_override or auto_redir
    effective_origin  = origin_override   or auto_origin

    ctx = {
        **_admin_base_ctx(request, 'google_settings'),
        'g_client_id_set':        bool(cid),
        'g_client_secret_set':    bool(sec),
        'g_client_id_masked':     masked_id,
        'g_client_secret_masked': masked_secret,
        'g_enabled':              s['enabled'],
        'g_ready':                is_google_oauth_ready(),
        'redirect_uri':           effective_redir,
        'authorized_origin':      effective_origin,
        'redirect_uri_value':     redirect_override,
        'authorized_origin_value': origin_override,
        'redirect_uri_auto':      auto_redir,
        'authorized_origin_auto': auto_origin,
        'urls_overridden':        bool(redirect_override or origin_override),
        'save_result':            save_result,
    }
    return render(request, 'core/admin_google_settings.html', ctx)


@admin_required
@require_http_methods(['POST'])
def admin_delete_user(request, user_id):
    current_user_id = request.session.get('user_id')
    if int(user_id) == int(current_user_id):
        return redirect('/admin-panel/users/?deleted=self')
    ok = delete_user(user_id)
    if ok:
        return redirect('/admin-panel/users/?deleted=ok')
    return redirect('/admin-panel/users/?deleted=fail')


@admin_required
@require_http_methods(['POST'])
def admin_bulk_delete_users(request):
    """Delete multiple users at once. Skips the current admin and any
    accounts protected by ADMIN_EMAILS."""
    raw_ids = request.POST.getlist('user_ids')
    current_user_id = int(request.session.get('user_id') or 0)

    candidate_ids: list[int] = []
    skipped_self  = False
    for r in raw_ids:
        try:
            uid = int(r)
        except (TypeError, ValueError):
            continue
        if uid == current_user_id:
            skipped_self = True
            continue
        candidate_ids.append(uid)

    # Fetch only the requested rows instead of the full users table.
    by_id = {u['id']: u for u in get_users_by_ids(candidate_ids)}

    target_ids: list[int] = []
    skipped_admin = 0
    for uid in candidate_ids:
        u = by_id.get(uid)
        if u is None:
            continue
        if u.get('email') in ADMIN_EMAILS:
            skipped_admin += 1
            continue
        target_ids.append(uid)

    deleted = bulk_delete_users(target_ids) if target_ids else 0
    qs = f'bulk_deleted={deleted}'
    if skipped_self:
        qs += '&bulk_self=1'
    if skipped_admin:
        qs += f'&bulk_admin={skipped_admin}'
    return redirect(f'/admin-panel/users/?{qs}')


# ── Per-user Whop billing mode ───────────────────────────────────────────
# Each user document carries its own ``whop_mode`` ('prod' | 'dev'). New
# signups default to 'prod' (live billing) — see core/db.create_user. Admins
# can flip individual users from /admin-panel/users/ (the toggle below the
# user's plan badge) or many at once via the bulk action bar. The flag is
# read at checkout time by ls_embed_checkout → wp.mode_for_user(user) so
# only that user's checkout is routed to the $1 Whop dev plan IDs.

def _normalize_whop_mode(raw: str) -> str:
    """Coerce form input to a known mode; default to 'prod' for safety."""
    m = (raw or '').strip().lower()
    return m if m in ('dev', 'prod') else 'prod'


@admin_required
@require_http_methods(['POST'])
def admin_set_user_whop_mode(request, user_id):
    """Flip a single user between 'dev' and 'prod' Whop billing mode.

    Self-protection: refuses to mutate the *calling* admin's own
    account so a stray click can't accidentally route the admin's
    own real billing to the $1 dev plans (they can ask another
    admin to flip it). Other admins CAN be toggled by a fellow
    admin — testing the dev plans on a super-admin account is a
    legitimate workflow and forcing a JSONB hand-edit isn't a real
    safeguard.
    """
    target = get_user_by_id(user_id)
    if not target:
        return redirect('/admin-panel/users/?mode_set=missing')
    current_user_id = int(request.session.get('user_id') or 0)
    if int(user_id) == current_user_id:
        return redirect('/admin-panel/users/?mode_set=self')
    new_mode = _normalize_whop_mode(request.POST.get('whop_mode'))
    update_user(int(user_id), whop_mode=new_mode)
    return redirect(f'/admin-panel/users/?mode_set=ok&mode={new_mode}')


# ── Per-user email-code login verification toggle ────────────────────────
# Each user document carries an optional ``email_code_disabled`` boolean
# (omitted / falsy = email-code verification REQUIRED on every email-
# password login; True = bypass the code and log the user in directly).
# Defaults to required for everyone — the admin only flips the bit OFF
# for accounts whose ESP can't reliably deliver our 6-digit codes
# (corporate spam filters, etc.). The login view at lines ~1405-1406
# reads this flag together with `is_email_transport_configured()` to
# decide whether to redirect to /login/verify-code/ or mint the
# session immediately. TOTP-protected accounts are unaffected — the
# TOTP check fires earlier and short-circuits before we reach this
# code path.

@admin_required
@require_http_methods(['POST'])
def admin_set_user_email_code(request, user_id):
    """Flip a single user's email-code verification ON/OFF.

    Mirrors the Whop-mode endpoint's self-protection: refuses to
    mutate the *calling* admin's own account so an admin can't lock
    themselves out of email-code MFA in one stray click (they can
    still ask another admin to flip it for them). Other admin
    accounts CAN be toggled by a fellow admin — corp spam filters
    and ESP deliverability issues hit super-admins too, and forcing
    them to edit JSONB by hand isn't a real safeguard.

    The form sends ``email_code='on'|'off'``; anything else is
    coerced to ``'on'`` (the safe default) so a hand-crafted POST
    can never silently disable a security feature.
    """
    target = get_user_by_id(user_id)
    if not target:
        return redirect('/admin-panel/users/?email_code_set=missing')
    current_user_id = int(request.session.get('user_id') or 0)
    if int(user_id) == current_user_id:
        return redirect('/admin-panel/users/?email_code_set=self')
    raw = (request.POST.get('email_code') or '').strip().lower()
    new_state = 'off' if raw == 'off' else 'on'
    update_user(int(user_id), email_code_disabled=(new_state == 'off'))
    return redirect(f'/admin-panel/users/?email_code_set=ok&email_code={new_state}')


@admin_required
@require_http_methods(['POST'])
def admin_bulk_set_whop_mode(request):
    """Flip many users between 'dev' and 'prod' in one shot.

    Mirrors the bulk-delete safety contract: skips the current admin and
    any account whose email is in ADMIN_EMAILS so an admin can't
    accidentally route their own real billing to the $1 dev plans.
    """
    raw_ids = request.POST.getlist('user_ids')
    new_mode = _normalize_whop_mode(request.POST.get('whop_mode'))
    current_user_id = int(request.session.get('user_id') or 0)

    candidate_ids: list[int] = []
    skipped_self = False
    for r in raw_ids:
        try:
            uid = int(r)
        except (TypeError, ValueError):
            continue
        if uid == current_user_id:
            skipped_self = True
            continue
        candidate_ids.append(uid)

    by_id = {u['id']: u for u in get_users_by_ids(candidate_ids)}
    target_ids: list[int] = []
    skipped_admin = 0
    for uid in candidate_ids:
        u = by_id.get(uid)
        if u is None:
            continue
        if u.get('email') in ADMIN_EMAILS:
            skipped_admin += 1
            continue
        target_ids.append(uid)

    updated = 0
    for uid in target_ids:
        if update_user(uid, whop_mode=new_mode):
            updated += 1

    qs = f'bulk_mode={updated}&mode={new_mode}'
    if skipped_self:
        qs += '&bulk_self=1'
    if skipped_admin:
        qs += f'&bulk_admin={skipped_admin}'
    return redirect(f'/admin-panel/users/?{qs}')


@admin_required
@require_http_methods(['POST'])
def admin_bulk_whop_sync(request):
    """Force a fresh Whop API sync for many users at once.

    Used by the admin to fix users whose locally-cached plan / membership
    info has drifted (e.g. a webhook was missed, or the user paid via a
    plan_id that wasn't yet registered in /admin-panel/whop-settings/).

    For each user we:
    1. Look up their active memberships by email at Whop (live API).
    2. Pick the highest-tier active membership.
    3. Re-bind whop_membership_id / plan / subscription_active.
    4. Snapshot the formatted membership (status / renews_at / paused /
       cancelled) into the JSONB doc so the settings page reflects it.

    Bypasses the 1-hour _whop_login_sync throttle by calling the Whop API
    directly. Skips the current admin and ADMIN_EMAILS as a safety mirror
    of the bulk-delete / bulk-mode contracts. Counts and reports both
    successes and failures so the admin can see at a glance how many
    accounts genuinely have no Whop membership.
    """
    raw_ids = request.POST.getlist('user_ids')
    current_user_id = int(request.session.get('user_id') or 0)
    from datetime import datetime, timezone

    candidate_ids: list[int] = []
    skipped_self = False
    for r in raw_ids:
        try:
            uid = int(r)
        except (TypeError, ValueError):
            continue
        if uid == current_user_id:
            skipped_self = True
            continue
        candidate_ids.append(uid)

    by_id = {u['id']: u for u in get_users_by_ids(candidate_ids)}
    target_users: list[dict] = []
    skipped_admin = 0
    for uid in candidate_ids:
        u = by_id.get(uid)
        if u is None:
            continue
        if u.get('email') in ADMIN_EMAILS:
            skipped_admin += 1
            continue
        target_users.append(u)

    synced = 0       # Whop returned an active membership and we re-bound it
    no_member = 0    # email lookup returned nothing — user has no Whop record
    failed = 0       # exception talking to Whop or writing to DB

    for u in target_users:
        uid   = u['id']
        email = (u.get('email') or '').strip()
        if not email:
            no_member += 1
            continue
        try:
            mems = wp.get_memberships_by_email(email, timeout=5)
        except Exception:
            failed += 1
            log.exception("admin_bulk_whop_sync: get_memberships_by_email failed for user %s", uid)
            continue

        active = [m for m in mems if m.get('valid')]
        if not active:
            # No active membership at Whop. Flip the user to inactive so
            # the admin list / MRR / billing logic stop treating them as
            # a paying customer. Without this the user would keep their
            # stale `subscription_active=True` + plan badge forever (the
            # whole point of the admin clicking Sync Whop is to *fix*
            # that drift).
            #
            # We deliberately leave `plan` and `whop_membership_id` as
            # historical breadcrumbs — the admin table is driven by
            # `subscription_active`, and clearing the membership id
            # would lose the audit trail of what the user used to have.
            no_member += 1
            try:
                update_user(uid,
                    subscription_active = False,
                    whop_resync_pending = False,
                    whop_status         = 'expired',
                    whop_paused         = False,
                    whop_cancelled      = False,
                    whop_renews_at      = '',
                    last_whop_sync_at   = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
                )
            except Exception:
                log.exception("admin_bulk_whop_sync: clear-inactive update failed for user %s", uid)
            continue

        # Pick the highest-tier active membership (mirrors _whop_login_sync).
        best_m, best_plan, best_rank = None, '', -1
        for m in active:
            d = wp.plan_from_membership(m, default='')
            r = _PLAN_RANK.get(d, -1)
            if r > best_rank:
                best_m, best_plan, best_rank = m, d, r
        if best_m is None:
            best_m = active[0]
            best_plan = ''

        try:
            patch = {
                'whop_membership_id':  best_m.get('id', ''),
                'whop_cancelled':      bool(best_m.get('cancel_at_period_end')),
                'subscription_active': True,
                'last_whop_sync_at':   datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
                'whop_resync_pending': False,
            }
            if best_plan in ('starter', 'pro', 'agency'):
                patch['plan'] = best_plan
            update_user(uid, **patch)
            _snapshot_whop_to_user(uid, best_m)
            synced += 1
        except Exception:
            failed += 1
            log.exception("admin_bulk_whop_sync: update/snapshot failed for user %s", uid)

    qs = f'bulk_synced={synced}&bulk_no_member={no_member}&bulk_failed={failed}'
    if skipped_self:
        qs += '&bulk_self=1'
    if skipped_admin:
        qs += f'&bulk_admin={skipped_admin}'
    return redirect(f'/admin-panel/users/?{qs}')


@admin_required
@require_http_methods(['POST'])
def admin_ban_user(request, user_id):
    current_user_id = request.session.get('user_id')
    if int(user_id) == int(current_user_id):
        return redirect('/admin-panel/users/?banned=self')
    target = get_user_by_id(user_id)
    if not target:
        return redirect('/admin-panel/users/?banned=fail')
    ban_email(
        email=target['email'],
        name=target.get('name', ''),
        banned_by=request.session.get('user_email', ''),
    )
    delete_user(user_id)
    return redirect('/admin-panel/users/?banned=ok')


@admin_required
@require_http_methods(['POST'])
def admin_unban_email(request):
    email = request.POST.get('email', '').strip()
    if email:
        unban_email(email)
    return redirect('/admin-panel/banned/?unbanned=ok')

# ── API helpers ───────────────────────────────────────────────

_DEMO_USER_EMAIL = 'mk@permitdaily.com'


def _generate_api_key():
    return 'pl_live_' + secrets.token_urlsafe(24)


def _api_auth(request):
    """Authenticate API request. Returns user dict (with 'id') on success, None on failure.
    Sets request._api_user for downstream tracking."""
    key = (request.GET.get('api_key') or
           request.headers.get('Authorization', '').replace('Bearer ', '').strip())
    if not key:
        return None
    if key == DEMO_API_KEY:
        user = get_user_by_email(_DEMO_USER_EMAIL)
        if user:
            user['_demo_key'] = True
            request._api_user = user
            return user
        return None
    # Single-row JSONB containment lookup (backed by users_api_keys_gin_idx)
    # instead of scanning every user on every API request.
    user = get_user_by_api_key(key)
    if not user:
        return None
    if user.get('plan', 'starter').lower() != 'agency':
        return None
    # Plan field on the user record is treated as a historical breadcrumb
    # by `admin_bulk_whop_sync` / `admin_whop_resync_user` (we don't clear
    # it on cancel so admins can see what the user used to have). That's
    # only safe if entitlement decisions go through `subscription_active`,
    # which is the canonical "do they currently have access" flag (set by
    # the Whop webhook on cancel/expire/payment events). Without this
    # check, a cancelled agency user would still pass API auth.
    if not user.get('subscription_active'):
        return None
    for k in user.get('api_keys', []):
        if k.get('key') == key and k.get('active', True):
            user['_matched_key'] = key
            request._api_user = user
            return user
    return None


def _api_unauth():
    return JsonResponse({'error': 'Invalid or missing API key.', 'code': 'unauthorized',
                         'docs': 'https://permitlify.com/developers/'}, status=401)


def _api_track(request, endpoint='unknown'):
    """Track an API call for the authenticated user (per-key, per-endpoint, per-day)."""
    user = getattr(request, '_api_user', None)
    if not user:
        return
    user_id = user.get('id')
    if not user_id:
        return
    try:
        if user.get('_demo_key'):
            increment_user_field(user_id, 'api_calls', 1)
            return
        matched_key = user.get('_matched_key')
        full_user = get_user_by_id(user_id)
        if not full_user:
            return
        api_keys = full_user.get('api_keys', [])
        today = date.today().isoformat()
        for k in api_keys:
            if k.get('key') == matched_key:
                k['calls'] = k.get('calls', 0) + 1
                k['last_used'] = datetime.utcnow().isoformat()
                ep = k.get('endpoint_stats', {})
                ep[endpoint] = ep.get(endpoint, 0) + 1
                k['endpoint_stats'] = ep
                daily = k.get('daily_calls', {})
                daily[today] = daily.get(today, 0) + 1
                # Keep only last 30 days
                if len(daily) > 30:
                    oldest = sorted(daily.keys())[0]
                    del daily[oldest]
                k['daily_calls'] = daily
                break
        update_user(user_id, api_keys=api_keys)
        increment_user_field(user_id, 'api_calls', 1)
    except Exception:
        pass

# ── API endpoints ─────────────────────────────────────────────

def api_permits(request):
    if not _api_auth(request):
        return _api_unauth()
    _api_track(request, 'permits')

    # Build the user's city restriction set. The demo key (and only the
    # demo key) sees the full corpus; real keys are restricted to the
    # cities the customer has paid for. `None` means "no restriction"
    # for the SQL helper; an empty set means "user has no cities → 0
    # results" (the helper short-circuits and never hits the DB).
    api_user = getattr(request, '_api_user', {})
    if api_user.get('_demo_key'):
        user_city_set: set | None = None
    else:
        user_city_set = set()
        for c in api_user.get('cities', []) or []:
            c = c.strip()
            city_name = c.rsplit(', ', 1)[0].strip() if ', ' in c else c
            if city_name:
                user_city_set.add(city_name.lower())

    state          = request.GET.get('state', '').strip()
    city           = request.GET.get('city', '').strip()
    trade          = request.GET.get('trade', '').strip()
    status         = request.GET.get('status', '').strip()
    min_score_s    = request.GET.get('min_score', '').strip()
    max_score_s    = request.GET.get('max_score', '').strip()
    tier           = request.GET.get('tier', '').strip().lower()
    owner          = request.GET.get('owner', '').strip()
    keyword        = request.GET.get('keyword', '').strip()
    issued_after   = request.GET.get('issued_after', '').strip()
    expires_before = request.GET.get('expires_before', '').strip()
    limit_s        = request.GET.get('limit', '50').strip()
    offset_s       = request.GET.get('offset', '0').strip()

    # Validate score filters BEFORE we hit the DB so a bad query
    # parameter returns 400 instantly (and to keep the previous public
    # API contract — the v1 docs promise a 400 on non-integer scores).
    try:
        min_score = int(min_score_s) if min_score_s else None
    except ValueError:
        return JsonResponse({'error': 'min_score must be an integer.', 'code': 'bad_request'}, status=400)
    try:
        max_score = int(max_score_s) if max_score_s else None
    except ValueError:
        return JsonResponse({'error': 'max_score must be an integer.', 'code': 'bad_request'}, status=400)

    # Clamp limit/offset BEFORE building the SQL — a negative `limit`
    # would emit `LIMIT -1` and crash with a 500 (Postgres rejects it),
    # which the previous in-memory implementation never tripped because
    # Python list slicing handles negatives silently. Floor at 1, cap
    # at 200 to bound payload size for the v1 API contract.
    try:
        limit  = max(1, min(int(limit_s), 200))
        offset = max(0, int(offset_s))
    except ValueError:
        limit, offset = 50, 0

    # All filtering, paging, and the COUNT(*) for pagination metadata
    # happen in a single round-trip to Postgres.
    results, total = query_permits_view(
        city_set       = user_city_set,
        state          = state,
        city           = city,
        trade          = trade,
        status         = status,
        tier           = tier,
        min_score      = min_score,
        max_score      = max_score,
        owner          = owner,
        keyword        = keyword,
        issued_after   = issued_after,
        expires_before = expires_before,
        limit          = limit,
        offset         = offset,
    )

    return JsonResponse({
        'count':    total,
        'returned': len(results),
        'offset':   offset,
        'limit':    limit,
        'results':  results,
        'meta':     {'api_version': 'v1'},
    })

def api_permit_detail(request, number):
    if not _api_auth(request):
        return _api_unauth()
    _api_track(request, 'permit_detail')

    # Honor the same per-key city restriction the list endpoint uses
    # so /v1/permits/<id>/ cannot leak permits in cities the caller
    # didn't pay for. The demo key sees everything.
    api_user = getattr(request, '_api_user', {})
    if api_user.get('_demo_key'):
        city_set: set | None = None
    else:
        city_set = set()
        for c in api_user.get('cities', []) or []:
            c = c.strip()
            city_name = c.rsplit(', ', 1)[0].strip() if ', ' in c else c
            if city_name:
                city_set.add(city_name.lower())

    permit = get_permit_by_number(number, city_set)
    if not permit:
        return JsonResponse({'error': 'Permit not found.', 'code': 'not_found'}, status=404)
    return JsonResponse({'result': permit, 'meta': {'api_version': 'v1'}})

def api_cities(request):
    if not _api_auth(request):
        return _api_unauth()
    _api_track(request, 'cities')
    cities = [{'name': c['name'], 'state': c['state'], 'permit_count': c['count']} for c in SAMPLE_CITIES]
    return JsonResponse({'count': len(cities), 'results': cities, 'meta': {'api_version': 'v1'}})

def _score_description(desc: str) -> tuple[int, str]:
    """Analyse permit description text. Returns (points 0-25, note)."""
    if not desc:
        return 0, 'No description provided'
    d = desc.lower()

    strong_pos = [
        ('full replacement', 8, 'full replacement'),
        ('complete replacement', 8, 'complete replacement'),
        ('total replacement', 8, 'total replacement'),
        ('new construction', 8, 'new construction'),
        ('new build', 8, 'new build'),
        ('hail damage', 7, 'storm/hail damage urgency'),
        ('storm damage', 7, 'storm damage urgency'),
        ('fire damage', 7, 'fire damage urgency'),
        ('water damage', 6, 'water damage urgency'),
        ('commercial', 5, 'commercial project'),
        ('emergency', 6, 'emergency work'),
    ]
    medium_pos = [
        ('replacement', 4, 'replacement work'),
        ('upgrade', 3, 'system upgrade'),
        ('installation', 3, 'new installation'),
        ('new system', 4, 'new system'),
        ('addition', 3, 'addition/expansion'),
        ('remodel', 3, 'remodel work'),
        ('expansion', 3, 'expansion'),
        ('solar', 3, 'solar install'),
        ('panel upgrade', 4, 'panel upgrade'),
        ('full', 2, 'full scope'),
    ]
    weak_neg = [
        ('minor repair', -6, 'minor repair'),
        ('patch', -4, 'patch work only'),
        ('inspection only', -8, 'inspection only'),
        ('temporary', -5, 'temporary permit'),
        ('survey', -4, 'survey/assessment only'),
        ('demo only', -5, 'demolition only'),
        ('demolition only', -5, 'demolition only'),
    ]

    pts = 0
    signals = []
    for phrase, weight, label in strong_pos:
        if phrase in d:
            pts += weight
            signals.append(label)
            break
    for phrase, weight, label in medium_pos:
        if phrase in d and label not in signals:
            pts += weight
            signals.append(label)
    for phrase, weight, label in weak_neg:
        if phrase in d:
            pts += weight
            signals.append(label)

    pts = max(0, min(25, pts))
    note = ', '.join(signals[:3]) if signals else 'Standard permit description'
    if pts >= 18:
        note = 'Strong value signals: ' + note
    elif pts >= 10:
        note = 'Moderate signals: ' + note
    elif pts == 0:
        note = 'No strong signals detected'
    else:
        note = note.capitalize()
    return pts, note


def _score_context(owner: str, permit_type: str, project: str) -> tuple[int, str]:
    """Score based on owner type and permit type context. Returns (points 0-15, note)."""
    o = (owner or '').lower()
    pt = (permit_type or '').lower()
    pr = (project or '').lower()

    commercial_keywords = ['llc', 'corp', 'inc', 'ltd', 'group', 'properties', 'holdings',
                           'partners', 'associates', 'enterprises', 'services', 'company',
                           'management', 'development', 'real estate', 'retail', 'commercial']
    residential_keywords = ['residential', 'homeowner', 'single-family', 'single family',
                            'duplex', 'townhome', 'condo']
    high_type_keywords = ['commercial', 'industrial', 'multifamily', 'multi-family',
                          'new build', 'new construction']
    low_type_keywords = ['garage', 'fence', 'shed', 'minor', 'temporary', 'demo']

    pts = 8
    note_parts = []

    is_commercial = any(k in o for k in commercial_keywords)
    if is_commercial:
        pts += 7
        note_parts.append('commercial entity owner')
    elif any(k in o for k in residential_keywords):
        pts += 2
        note_parts.append('residential homeowner')
    else:
        pts += 4
        note_parts.append('individual owner')

    for k in high_type_keywords:
        if k in pt or k in pr:
            pts += 2
            note_parts.append('high-value permit type')
            break
    for k in low_type_keywords:
        if k in pt or k in pr:
            pts -= 3
            note_parts.append('lower-value scope')
            break

    pts = max(0, min(15, pts))
    return pts, (', '.join(note_parts) if note_parts else 'Standard context').capitalize()


def _score_grade(score: int) -> str:
    if score >= 93: return 'A+'
    if score >= 88: return 'A'
    if score >= 83: return 'A-'
    if score >= 78: return 'B+'
    if score >= 73: return 'B'
    if score >= 68: return 'B-'
    if score >= 63: return 'C+'
    if score >= 58: return 'C'
    if score >= 53: return 'C-'
    if score >= 45: return 'D'
    return 'F'


def _score_summary(trade: str, value: float, desc_note: str, tier: str, score: int) -> str:
    tier_word = {'hot': 'High-priority', 'warm': 'Moderate-priority', 'cool': 'Lower-priority'}.get(tier, 'Scored')
    trade_label = {'roofing': 'roofing', 'hvac': 'HVAC', 'electrical': 'electrical', 'plumbing': 'plumbing',
                   'solar': 'solar', 'civil': 'civil/construction'}.get(trade, trade)
    val_label = f'${value:,.0f} value' if value > 0 else 'no value provided'
    signals = desc_note.split(': ')[-1] if ': ' in desc_note else desc_note
    return f'{tier_word} {trade_label} lead — {val_label}. {signals}. Score: {score}/99.'


@csrf_exempt
@require_http_methods(['POST'])
def api_score(request):
    if not _api_auth(request):
        return _api_unauth()
    _api_track(request, 'score')
    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, ValueError):
        return JsonResponse({'error': 'Request body must be valid JSON.', 'code': 'bad_request'}, status=400)

    trade       = str(data.get('trade', 'roofing')).lower().strip()
    value_str   = str(data.get('value', '0')).replace('$', '').replace(',', '').strip()
    city        = str(data.get('city', '')).strip()
    state       = str(data.get('state', '')).strip()
    description = str(data.get('description', '')).strip()
    permit_type = str(data.get('permit_type', '')).strip()
    owner       = str(data.get('owner', '')).strip()
    status      = str(data.get('status', '')).lower().strip()
    project     = str(data.get('project', '')).strip()
    issued_date = str(data.get('issued_date', '')).strip()
    expires_date = str(data.get('expires_date', '')).strip()

    try:
        value = float(value_str)
    except ValueError:
        value = 0

    # ── Factor 1: Trade (0–25) ────────────────────────────────
    trade_scores = {
        'roofing': 25, 'hvac': 25, 'solar': 23,
        'electrical': 18, 'plumbing': 18, 'civil': 15,
    }
    f_trade = trade_scores.get(trade, 10)
    trade_notes = {
        'roofing': 'Roofing — highest conversion rate trade',
        'hvac': 'HVAC — high-urgency, high-value trade',
        'solar': 'Solar — growing high-value market',
        'electrical': 'Electrical — solid conversion trade',
        'plumbing': 'Plumbing — reliable demand',
        'civil': 'Civil/construction — project-based lead',
    }
    f_trade_note = trade_notes.get(trade, f'Trade: {trade}')

    # ── Factor 2: Value (0–25) ────────────────────────────────
    if value > 20000:
        f_value, f_value_note = 25, f'High-value permit (${value:,.0f})'
    elif value > 12000:
        f_value, f_value_note = 18, f'Good permit value (${value:,.0f})'
    elif value > 6000:
        f_value, f_value_note = 12, f'Moderate value (${value:,.0f})'
    elif value > 2000:
        f_value, f_value_note = 6, f'Lower value permit (${value:,.0f})'
    elif value > 0:
        f_value, f_value_note = 3, f'Minimal declared value (${value:,.0f})'
    else:
        f_value, f_value_note = 0, 'No permit value provided'

    # ── Factor 3: Description analysis (0–25) ─────────────────
    f_desc, f_desc_note = _score_description(description)

    # ── Factor 4: Context — owner + permit type (0–15) ────────
    f_ctx, f_ctx_note = _score_context(owner, permit_type, project)

    # ── Factor 5: Status (0–10) ───────────────────────────────
    status_scores = {'approved': 10, 'review': 7, 'pending': 5, 'expired': 0}
    f_status = status_scores.get(status, 8)
    status_notes = {
        'approved': 'Permit approved — immediately actionable',
        'review': 'In review — likely to be approved soon',
        'pending': 'Pending approval — act early',
        'expired': 'Permit expired — lower urgency',
    }
    f_status_note = status_notes.get(status, 'Status not provided — estimated active')

    raw_score = f_trade + f_value + f_desc + f_ctx + f_status
    score = max(10, min(99, raw_score))
    tier  = 'hot' if score >= 80 else 'warm' if score >= 60 else 'cool'
    grade = _score_grade(score)

    return JsonResponse({
        'score':   score,
        'tier':    tier,
        'grade':   grade,
        'summary': _score_summary(trade, value, f_desc_note, tier, score),
        'factors': {
            'trade': {
                'points': f_trade, 'max': 25,
                'note': f_trade_note,
            },
            'value': {
                'points': f_value, 'max': 25,
                'note': f_value_note,
            },
            'description': {
                'points': f_desc, 'max': 25,
                'note': f_desc_note,
            },
            'context': {
                'points': f_ctx, 'max': 15,
                'note': f_ctx_note,
            },
            'status': {
                'points': f_status, 'max': 10,
                'note': f_status_note,
            },
        },
        'inputs': {
            'trade': trade, 'value': value, 'city': city, 'state': state,
            'description': description, 'permit_type': permit_type,
            'owner': owner, 'status': status, 'project': project,
            'issued_date': issued_date, 'expires_date': expires_date,
        },
        'meta': {'api_version': 'v1', 'model': 'permitlify-score-v3'},
    })


# ── API Portal (authenticated, Agency-only) ───────────────────

@login_required
@subscription_required
def api_portal(request):
    ctx = _user_ctx(request)
    user_id = request.session.get('user_id')
    user = get_user_by_id(user_id) if user_id else None
    plan = (user.get('plan', 'starter') if user else 'starter').lower()
    if plan != 'agency':
        ctx['plan'] = plan
        return render(request, 'core/api_portal.html', ctx)
    api_keys = user.get('api_keys', [])
    total_calls = sum(k.get('calls', 0) for k in api_keys)
    ep_totals = {}
    daily_totals = {}
    for k in api_keys:
        for ep, cnt in k.get('endpoint_stats', {}).items():
            ep_totals[ep] = ep_totals.get(ep, 0) + cnt
        for day, cnt in k.get('daily_calls', {}).items():
            daily_totals[day] = daily_totals.get(day, 0) + cnt
    today = date.today()
    last_7 = [(today.replace(day=1) if False else
               (today.__class__.fromordinal(today.toordinal() - i))).isoformat()
              for i in range(6, -1, -1)]
    chart_data = [{'date': d, 'calls': daily_totals.get(d, 0)} for d in last_7]
    raw = user.get('cities', [])
    plan_cities, plan_states = [], set()
    for c in raw:
        c = c.strip()
        name, st = (c.rsplit(', ', 1) + [''])[:2] if ', ' in c else (c, _city_state(c))
        plan_cities.append({'name': name.strip(), 'state': st.strip()})
        if st: plan_states.add(st.strip())
    plan_states = sorted(plan_states)
    new_key_val = request.session.pop('api_new_key', None)
    new_key_name = request.session.pop('api_new_key_name', None)
    ctx.update({
        'plan': 'agency',
        'api_keys': api_keys,
        'api_keys_json': json.dumps(api_keys),
        'total_calls': total_calls,
        'ep_totals': ep_totals,
        'chart_data': json.dumps(chart_data),
        'today_calls': daily_totals.get(date.today().isoformat(), 0),
        'new_key_val': new_key_val,
        'new_key_name': new_key_name,
        'plan_cities_json': json.dumps(plan_cities),
        'plan_states': plan_states,
    })
    return render(request, 'core/api_portal.html', ctx)


@login_required
@require_http_methods(['POST'])
def api_key_create(request):
    user_id = request.session.get('user_id')
    user = get_user_by_id(user_id) if user_id else None
    if not user or user.get('plan', 'starter').lower() != 'agency':
        return redirect('api_portal')
    name = request.POST.get('name', '').strip() or 'My Key'
    api_keys = user.get('api_keys', [])
    if len(api_keys) >= 5:
        return redirect('api_portal')
    new_key = {
        'key': _generate_api_key(),
        'name': name[:60],
        'created': datetime.utcnow().isoformat(),
        'last_used': None,
        'calls': 0,
        'active': True,
        'endpoint_stats': {},
        'daily_calls': {},
    }
    api_keys.append(new_key)
    update_user(user_id, api_keys=api_keys)
    request.session['api_new_key'] = new_key['key']
    request.session['api_new_key_name'] = new_key['name']
    return redirect('api_portal')


@login_required
@require_http_methods(['POST'])
def api_key_revoke(request):
    user_id = request.session.get('user_id')
    user = get_user_by_id(user_id) if user_id else None
    if not user or user.get('plan', 'starter').lower() != 'agency':
        return redirect('api_portal')
    key_val = request.POST.get('key', '').strip()
    api_keys = user.get('api_keys', [])
    for k in api_keys:
        if k.get('key') == key_val:
            k['active'] = False
            break
    update_user(user_id, api_keys=api_keys)
    return redirect('api_portal')


def _fmt_notif_time(iso_str: str) -> str:
    """Format ISO datetime to human-readable display string."""
    try:
        dt   = datetime.fromisoformat(iso_str)
        now  = datetime.now()
        diff = (now.date() - dt.date()).days
        t    = dt.strftime('%I:%M %p').lstrip('0')
        if diff == 0:   return f'Today {t}'
        if diff == 1:   return f'Yesterday {t}'
        if dt.year == now.year:
            return f'{dt.strftime("%b")} {dt.day} {t}'
        return f'{dt.strftime("%b")} {dt.day}, {dt.year} {t}'
    except Exception:
        return iso_str


@login_required
@subscription_required
def notifications(request):
    ctx     = _user_ctx(request)
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) or {}

    seed_demo_notifications(user_id, ctx.get('user_email', ''))

    page_size   = 10
    page        = max(1, int(request.GET.get('page', 1)))
    type_filter = request.GET.get('type', 'all')
    offset      = (page - 1) * page_size

    raw_notifs  = get_notifications_for_user(user_id, limit=page_size,
                                              offset=offset, type_filter=type_filter)
    total_count = count_notifications_for_user(user_id, type_filter=type_filter)
    page_count  = max(1, (total_count + page_size - 1) // page_size)

    for n in raw_notifs:
        n['sent_at_display'] = _fmt_notif_time(n.get('sent_at', ''))

    stats     = get_notification_stats(user_id)
    prefs     = get_notif_prefs(user_id)
    channels  = get_notif_channels(user_id)
    ch_active = sum(1 for v in [channels.get('email'), channels.get('slack_webhook'),
                                 channels.get('webhook_url'), channels.get('sms_phone')] if v)

    page_range = list(range(max(1, page - 2), min(page_count, page + 2) + 1))

    ctx.update({
        'alerts_sent':       stats['total'],
        'alerts_week':       stats['this_week'],
        'alerts_week_delta': stats['week_delta'],
        'open_rate':         stats['open_rate'],
        'channels_active':   ch_active,
        'notifications':     raw_notifs,
        'total_count':       total_count,
        'page':              page,
        'page_count':        page_count,
        'page_range':        page_range,
        'type_filter':       type_filter,
        'notif_prefs':       prefs,
        'notif_channels':    channels,
        'webhook_configured': bool(channels.get('webhook_url')),
    })
    return render(request, 'core/notifications.html', ctx)


@login_required
def save_notif_prefs_view(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user_id = request.session.get('user_id')
    valid_keys = {'daily_digest', 'hot_lead_alerts', 'weekly_report',
                  'new_city_alerts', 'billing_reminders', 'product_updates', 'slack_alerts'}
    existing = get_notif_prefs(user_id)
    updated  = False
    for k in valid_keys:
        if k in request.POST:
            existing[k] = request.POST.get(k) == '1'
            updated = True
    if updated:
        save_notif_prefs(user_id, existing)
    return JsonResponse({'ok': True})


@login_required
def save_notif_channel_view(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user_id = request.session.get('user_id')
    key     = request.POST.get('key', '')
    value   = request.POST.get('value', '')
    # Slack, custom webhook, and SMS channels are Agency-only. Email is always allowed.
    if key in {'slack_webhook', 'webhook_url', 'sms_phone'}:
        user = get_user_by_id(user_id) if user_id else None
        if not user or user.get('plan', 'starter').lower() != 'agency':
            return JsonResponse({'ok': False, 'error': 'Agency plan required'}, status=403)
    ok = save_notif_channel(user_id, key, value)
    if not ok:
        return JsonResponse({'ok': False, 'error': 'Invalid channel key'}, status=400)
    channels  = get_notif_channels(user_id)
    ch_active = sum(1 for v in [channels.get('email'), channels.get('slack_webhook'),
                                 channels.get('webhook_url'), channels.get('sms_phone')] if v)
    return JsonResponse({'ok': True, 'channels_active': ch_active})


# ── Notification dispatch (per-channel test) ──────────────────────

def _build_sample_permit():
    return {
        'ai_score': 92, 'ai_grade': 'A',
        'address': '4821 Ridgemont Dr', 'owner_name': 'Sarah T. Monroe',
        'trade': 'roofing', 'permit_type': 'Residential Roofing',
        'valuation_cents': 1850000,
        'city': 'Fort Worth', 'state': 'TX',
        'permit_number': 'TEST-' + datetime.utcnow().strftime('%Y%m%d-%H%M%S'),
        'issued_date': date.today().isoformat(),
    }


def _audit_dispatch(user_id, *, subject, channel, recipient, ok, detail):
    """Best-effort write to the notifications audit table; never raises."""
    try:
        create_notification(
            user_id=int(user_id),
            type_key='system', type_label='Test',
            subject=subject,
            preview=('Test sent successfully' if ok else f'Failed: {detail}')[:200],
            recipient=(recipient or '')[:120],
            channel=channel,
            status_key=('sent' if ok else 'failed'),
            status_label=('Sent' if ok else 'Failed'),
            sent_at=datetime.utcnow().isoformat(),
        )
    except Exception:
        pass


@login_required
def notif_test_view(request):
    """Send a real test message through the user-saved channel.

    Accepts ``key`` of ``slack_webhook`` or ``webhook_url``. ``sms_phone`` is
    rejected with a ``coming_soon`` flag so the UI can show the right message.
    Returns ``{ok: bool, detail?: str, error?: str, coming_soon?: bool}``.
    Logs an audit row in the notifications table either way (Slack/Webhook URLs
    are redacted before storage — they are bearer credentials).
    """
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)

    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) if user_id else None
    if not user:
        return JsonResponse({'ok': False, 'error': 'Not signed in'}, status=401)
    if user.get('plan', 'starter').lower() != 'agency':
        return JsonResponse({'ok': False, 'error': 'Agency plan required'}, status=403)

    key = (request.POST.get('key') or request.GET.get('key') or '').strip()

    # SMS is intentionally not yet implemented — surface a friendly state.
    if key == 'sms_phone':
        return JsonResponse({'ok': False,
                             'coming_soon': True,
                             'error': 'SMS alerts are coming soon.'}, status=400)

    if key not in {'slack_webhook', 'webhook_url'}:
        return JsonResponse({'ok': False, 'error': 'Unsupported channel.'}, status=400)

    channels = get_notif_channels(user_id)
    target   = (channels.get(key) or '').strip()
    if not target:
        return JsonResponse({'ok': False,
                             'error': 'Save a URL for this channel first.'}, status=400)

    sample = _build_sample_permit()

    if key == 'slack_webhook':
        text, blocks = _integrations.build_permit_alert_blocks(sample)
        text = '✅ Permitlify test alert — your Slack channel is connected.\n' + text
        ok, detail = _integrations.post_slack_webhook(target, text=text, blocks=blocks)
        _audit_dispatch(user_id, subject='Slack test message', channel='Slack',
                        recipient=_integrations.redact_webhook_url(target),
                        ok=ok, detail=detail)
        if ok:
            return JsonResponse({'ok': True, 'detail': 'Sent. Check your Slack channel.'})
        return JsonResponse({'ok': False, 'error': detail}, status=502)

    # key == 'webhook_url' — generic JSON push to the user's endpoint.
    payload = {
        'event':       'test',
        'sent_at':     datetime.utcnow().isoformat() + 'Z',
        'message':     'Permitlify test webhook — your endpoint is connected.',
        'permit':      sample,
    }
    ok, detail = _integrations.post_generic_webhook(target, payload)
    _audit_dispatch(user_id, subject='Webhook test message', channel='Webhook',
                    recipient=_integrations.redact_webhook_url(target),
                    ok=ok, detail=detail)
    if ok:
        return JsonResponse({'ok': True, 'detail': f'Sent ({detail}).'})
    return JsonResponse({'ok': False, 'error': detail}, status=502)


# ── CRM integrations (Zapier webhook + HubSpot/GHL OAuth) ──────────

def _crm_redirect_uri(request, provider: str) -> str:
    """Absolute URL the OAuth provider should redirect back to."""
    return request.build_absolute_uri(f'/integrations/{provider}/callback/')


@login_required
def crm_save_zapier_view(request):
    """POST {url} — save a Zapier 'Catch Hook' webhook URL for this user."""
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) if user_id else None
    if not user:
        return JsonResponse({'ok': False, 'error': 'Not signed in'}, status=401)
    if user.get('plan', 'starter').lower() != 'agency':
        return JsonResponse({'ok': False, 'error': 'Agency plan required'}, status=403)

    url = (request.POST.get('url') or '').strip()
    if url and not url.startswith('https://'):
        return JsonResponse({'ok': False, 'error': 'Webhook URL must be https://'}, status=400)
    save_zapier_webhook(user_id, url)
    return JsonResponse({'ok': True, 'connected': bool(url)})


@login_required
def crm_test_view(request):
    """POST {provider} — send a sample payload through a CRM integration."""
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) if user_id else None
    if not user:
        return JsonResponse({'ok': False, 'error': 'Not signed in'}, status=401)
    if user.get('plan', 'starter').lower() != 'agency':
        return JsonResponse({'ok': False, 'error': 'Agency plan required'}, status=403)

    provider = (request.POST.get('provider') or '').strip()
    integrations = get_crm_integrations(user_id)
    sample       = _build_sample_permit()

    if provider == 'zapier':
        url = (integrations.get('zapier', {}).get('webhook_url') or '').strip()
        if not url:
            return JsonResponse({'ok': False, 'error': 'Save a Zapier webhook URL first.'}, status=400)
        ok, detail = _integrations.post_generic_webhook(url, {
            'event':   'test',
            'sent_at': datetime.utcnow().isoformat() + 'Z',
            'permit':  sample,
        })
        _audit_dispatch(user_id, subject='Zapier test', channel='Zapier',
                        recipient=_integrations.redact_webhook_url(url),
                        ok=ok, detail=detail)
        if ok:
            return JsonResponse({'ok': True, 'detail': f'Sent ({detail}).'})
        return JsonResponse({'ok': False, 'error': detail}, status=502)

    if provider == 'hubspot':
        token = (integrations.get('hubspot', {}).get('access_token') or '').strip()
        if not token:
            return JsonResponse({'ok': False, 'error': 'Connect HubSpot first.'}, status=400)
        ok, detail = _integrations.hubspot_test_connection(token)
        _audit_dispatch(user_id, subject='HubSpot ping', channel='HubSpot',
                        recipient=_integrations.redact_token(token),
                        ok=ok, detail=detail)
        if ok:
            return JsonResponse({'ok': True, 'detail': f'HubSpot reachable ({detail}).'})
        return JsonResponse({'ok': False, 'error': detail}, status=502)

    if provider == 'ghl':
        rec   = integrations.get('ghl', {}) or {}
        token = (rec.get('access_token') or '').strip()
        loc   = (rec.get('locationId') or '').strip()
        if not token:
            return JsonResponse({'ok': False, 'error': 'Connect GoHighLevel first.'}, status=400)
        ok, detail = _integrations.ghl_test_connection(token, location_id=loc)
        _audit_dispatch(user_id, subject='GoHighLevel ping', channel='GoHighLevel',
                        recipient=_integrations.redact_token(token),
                        ok=ok, detail=detail)
        if ok:
            return JsonResponse({'ok': True, 'detail': f'GoHighLevel reachable ({detail}).'})
        return JsonResponse({'ok': False, 'error': detail}, status=502)

    return JsonResponse({'ok': False, 'error': 'Unsupported provider.'}, status=400)


@login_required
def crm_disconnect_view(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) if user_id else None
    if not user:
        return JsonResponse({'ok': False, 'error': 'Not signed in'}, status=401)
    if user.get('plan', 'starter').lower() != 'agency':
        return JsonResponse({'ok': False, 'error': 'Agency plan required'}, status=403)
    provider = (request.POST.get('provider') or '').strip()
    if provider not in CRM_PROVIDERS:
        return JsonResponse({'ok': False, 'error': 'Unsupported provider.'}, status=400)
    disconnect_crm_provider(user_id, provider)
    return JsonResponse({'ok': True})


@login_required
def crm_oauth_start(request, provider):
    """Begin an OAuth flow — redirect the user to the vendor's authorize URL."""
    user = get_user_by_id(request.session.get('user_id')) if request.session.get('user_id') else None
    if not user or user.get('plan', 'starter').lower() != 'agency':
        return HttpResponseForbidden('Agency plan required')
    if provider not in {'hubspot', 'ghl'}:
        return HttpResponseBadRequest('Unsupported provider')
    if not _integrations.oauth_provider_configured(provider):
        # Friendly fallback — bounce to settings with an error flag.
        return redirect(f'/settings/?tab=integrations&oauth_error={provider}_not_configured')
    state = secrets.token_urlsafe(24)
    request.session['crm_oauth'] = {
        'provider': provider,
        'state':    state,
        'user_id':  request.session.get('user_id'),
    }
    request.session.modified = True
    url = _integrations.oauth_authorize_url(provider, _crm_redirect_uri(request, provider), state)
    if not url:
        return redirect(f'/settings/?tab=integrations&oauth_error={provider}_not_configured')
    return redirect(url)


@login_required
def crm_oauth_callback(request, provider):
    """Receive ``code`` + ``state`` from the vendor and exchange for tokens."""
    if provider not in {'hubspot', 'ghl'}:
        return HttpResponseBadRequest('Unsupported provider')

    user_id = request.session.get('user_id')
    user    = get_user_by_id(user_id) if user_id else None
    # Re-check the plan — a user could have downgraded between authorize and
    # callback. Storing the resulting tokens for a non-Agency account would
    # silently grant them gated functionality.
    if not user or user.get('plan', 'starter').lower() != 'agency':
        request.session.pop('crm_oauth', None)
        return HttpResponseForbidden('Agency plan required')

    flow_state = (request.session.get('crm_oauth') or {})
    expected_state    = flow_state.get('state')
    expected_provider = flow_state.get('provider')
    expected_user     = flow_state.get('user_id')

    incoming_state = request.GET.get('state', '')
    code           = request.GET.get('code', '')

    if request.GET.get('error'):
        request.session.pop('crm_oauth', None)
        return redirect(f'/settings/?tab=integrations&oauth_error={provider}_denied')

    if (not expected_state or not incoming_state or
            not secrets.compare_digest(expected_state, incoming_state) or
            expected_provider != provider or expected_user != user_id):
        request.session.pop('crm_oauth', None)
        return redirect(f'/settings/?tab=integrations&oauth_error=state_mismatch')

    request.session.pop('crm_oauth', None)

    if not code:
        return redirect(f'/settings/?tab=integrations&oauth_error=no_code')

    ok, payload = _integrations.oauth_exchange_code(provider, code, _crm_redirect_uri(request, provider))
    if not ok or not isinstance(payload, dict) or not payload.get('access_token'):
        # payload is a string error message in the failure case.
        detail = payload if isinstance(payload, str) else (payload.get('message') or 'token exchange failed')
        _audit_dispatch(user_id, subject=f'{provider} connect failed', channel=provider.upper(),
                        recipient='', ok=False, detail=detail)
        return redirect(f'/settings/?tab=integrations&oauth_error=exchange_failed')

    tokens = _integrations.normalize_token_response(payload)
    label  = ''
    if provider == 'hubspot' and payload.get('hub_id'):
        label = f"hub {payload['hub_id']}"
    elif provider == 'ghl' and payload.get('locationId'):
        label = f"location {payload['locationId']}"
    set_crm_oauth_tokens(user_id, provider, tokens, account_label=label)
    _audit_dispatch(user_id, subject=f'{provider} connected', channel=provider.upper(),
                    recipient=label or _integrations.redact_token(tokens.get('access_token', '')),
                    ok=True, detail='oauth ok')
    return redirect('/settings/?tab=integrations&oauth_ok=1')


# ── Scraper ingest API ────────────────────────────────────────────

INGEST_MAX_BATCH = 1000


def _scraper_authed(request) -> bool:
    expected = (os.environ.get('SCRAPER_INGEST_KEY') or '').strip()
    if not expected:
        return False
    presented = (request.headers.get('X-Scraper-Key') or '').strip()
    if not presented:
        return False
    # constant-time compare
    return secrets.compare_digest(expected, presented)


@csrf_exempt
@require_http_methods(['POST'])
def api_permits_ingest(request):
    """Bulk ingest permits from the external scraper platform.

    Auth: ``X-Scraper-Key`` header must match the ``SCRAPER_INGEST_KEY``
    server secret. Body: ``{"permits": [ {...}, {...} ]}`` (max 1000).
    Each permit must include at least ``source``, ``source_permit_id``,
    ``state`` and ``city``; everything else is optional.
    """
    if not _scraper_authed(request):
        return JsonResponse({'ok': False, 'error': 'Invalid or missing X-Scraper-Key header.'}, status=401)

    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
    except (ValueError, UnicodeDecodeError):
        return JsonResponse({'ok': False, 'error': 'Body must be valid JSON.'}, status=400)

    permits = body.get('permits')
    if not isinstance(permits, list):
        return JsonResponse({'ok': False, 'error': 'Body must contain a "permits" array.'}, status=400)
    if not permits:
        return JsonResponse({'ok': True, 'inserted': 0, 'updated': 0, 'skipped': 0, 'errors': 0})
    if len(permits) > INGEST_MAX_BATCH:
        return JsonResponse({'ok': False,
                             'error': f'Batch too large (max {INGEST_MAX_BATCH} permits per request).'},
                            status=413)

    result = bulk_upsert_permits(permits)
    return JsonResponse({'ok': True, **result})


@login_required
def mark_notif_opened_view(request, notif_id):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'POST required'}, status=405)
    mark_notification_opened(notif_id)
    return JsonResponse({'ok': True})


@login_required
def notifications_export_csv(request):
    user_id     = request.session.get('user_id')
    type_filter = request.GET.get('type', 'all')
    all_notifs  = get_all_notifications_for_user(user_id, type_filter=type_filter)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="notifications.csv"'
    writer   = csv.writer(response)
    writer.writerow(['Type', 'Subject', 'Preview', 'Recipient', 'Channel', 'Status', 'Sent At'])
    for n in all_notifs:
        writer.writerow([
            n.get('type_label', ''),
            n.get('subject', ''),
            n.get('preview', ''),
            n.get('recipient', ''),
            n.get('channel', ''),
            n.get('status_label', ''),
            _fmt_notif_time(n.get('sent_at', '')),
        ])
    return response



# ─── SEO: robots.txt + sitemap.xml ───────────────────────────────────────
# Hand-rolled (no Django sitemap framework dependency, no DB hits) so they
# stay fast under load. Both responses are cached at the HTTP layer for an
# hour via Cache-Control to take the few requests/hour off our origin.

_PUBLIC_PATHS = [
    # (path,                changefreq, priority)
    ('/',                   'weekly',   '1.0'),
    ('/pricing/',           'weekly',   '0.9'),
    ('/how-it-works/',      'monthly',  '0.8'),
    ('/our-story/',         'monthly',  '0.7'),
    ('/blog/',              'weekly',   '0.8'),
    ('/developers/',        'monthly',  '0.7'),
    ('/contact/',           'monthly',  '0.6'),
    ('/careers/',           'monthly',  '0.5'),
    ('/press/',             'monthly',  '0.5'),
    ('/privacy/',           'yearly',   '0.3'),
    ('/terms/',             'yearly',   '0.3'),
    ('/login/',             'yearly',   '0.4'),
    ('/signup/',            'monthly',  '0.6'),
]

# Authenticated / app surfaces that must NEVER appear in search results, even
# if a third party links to them. Crawlers respect this list before fetching.
_DISALLOW_PATHS = [
    '/admin-panel/', '/dashboard/', '/permits/', '/notifications/',
    '/settings/', '/profile/', '/onboarding/', '/paywall/', '/support/',
    '/billing/', '/api/', '/auth/', '/integrations/',
    '/login/2fa/', '/forgot-password/', '/reset-password/',
    '/r/',  # referral redirector — not an index target
    '/logout/',
]


def _seo_origin(request):
    """
    Return the canonical site origin for SEO output.

    Prefers ``settings.SITE_ORIGIN`` (env-driven, locked to the production
    domain) so a forged Host header can't poison robots.txt or sitemap.xml.
    Falls back to the live request scheme + host when the env var isn't set
    (local dev / preview deploys), which keeps URLs working end-to-end.
    """
    from django.conf import settings as _s
    origin = (getattr(_s, 'SITE_ORIGIN', '') or '').rstrip('/')
    if origin:
        return origin
    scheme = 'https' if request.is_secure() else request.scheme
    return f'{scheme}://{request.get_host()}'


def robots_txt(request):
    """`/robots.txt` — tells crawlers what's off-limits and where the sitemap is."""
    origin = _seo_origin(request)
    lines = ['User-agent: *']
    for p in _DISALLOW_PATHS:
        lines.append(f'Disallow: {p}')
    lines += ['', f'Sitemap: {origin}/sitemap.xml', '']
    resp = HttpResponse('\n'.join(lines), content_type='text/plain; charset=utf-8')
    resp['Cache-Control'] = 'public, max-age=3600'
    return resp


def sitemap_xml(request):
    """`/sitemap.xml` — every public URL we want Google to crawl."""
    origin = _seo_origin(request)
    today = datetime.utcnow().strftime('%Y-%m-%d')
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for path, freq, prio in _PUBLIC_PATHS:
        parts.append(
            '<url>'
            f'<loc>{origin}{path}</loc>'
            f'<lastmod>{today}</lastmod>'
            f'<changefreq>{freq}</changefreq>'
            f'<priority>{prio}</priority>'
            '</url>'
        )
    # Per-article blog URLs — pulled from the same dict the views render.
    try:
        for slug in BLOG_ARTICLES.keys():
            parts.append(
                '<url>'
                f'<loc>{origin}/blog/{slug}/</loc>'
                f'<lastmod>{today}</lastmod>'
                '<changefreq>monthly</changefreq>'
                '<priority>0.7</priority>'
                '</url>'
            )
    except Exception:
        # Sitemap must never 500 — if blog imports fail, skip articles.
        pass
    parts.append('</urlset>')
    resp = HttpResponse(''.join(parts), content_type='application/xml; charset=utf-8')
    resp['Cache-Control'] = 'public, max-age=3600'
    return resp


# ── Dev-only email preview ────────────────────────────────────
# Renders any transactional email template against a baked sample
# context so we can iterate on the design without triggering a real
# send. Gated on settings.DEBUG so the route 404s in production —
# never expose this on a deployed env (it would let anyone read what
# our security-sensitive emails look like, and probe for template
# injection by inspecting the page source).

_EMAIL_PREVIEW_FIXTURES = {
    'login_code': {
        'name':           'Mohamed',
        'code':           '494670',
        'code_digits':    list('494670'),
        'expires_in_min': 10,
        'request_ip':     '198.51.100.42',
        'request_ua':     'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15',
    },
    'login_alert': {
        'first_name':   'Mohamed',
        'device':       'Edge on Windows',
        'ip':           '100.127.8.131',
        'ua':           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0',
        'method_label': 'Email + password (with email code)',
        'when_pretty':  'Apr 29, 2026 · 05:24 UTC',
        'security_url': 'https://permitlify.com/settings/security/',
    },
    'welcome': {
        'first_name':    'Mohamed',
        'joined_pretty': 'Apr 29, 2026 · 05:24 UTC',
        'dashboard_url': 'https://permitlify.com/dashboard/',
        'pricing_url':   'https://permitlify.com/pricing/',
        'support_url':   'https://permitlify.com/support/',
    },
    'payment_success': {
        'first_name':         'Mohamed',
        'plan_label':         'Pro',
        'amount_display':     '$49.00 USD',
        'billing_email':      'mohamed@example.com',
        'paid_at_pretty':     'Apr 29, 2026 · 05:24 UTC',
        'next_charge_pretty': 'May 29, 2026',
        'membership_id':      'mem_01HZX9K2P7QVR5MNAB3TYWFJ4S',
        'billing_url':        'https://permitlify.com/settings/billing/',
    },
    'support_reply': {
        'recipient':     'Mohamed',
        'agent':         'Sarah from Permitlify',
        'ref':           'PL-7421',
        'subject_topic': 'City filter not saving',
        'snippet':       "Hi Mohamed — thanks for the report! I just pushed a fix for the saved-city filter "
                         "issue. Could you reload the dashboard and confirm your Austin + Dallas filters now "
                         "stick? Happy to jump on a quick call if anything is still off.",
        'link':          'https://permitlify.com/support/tickets/PL-7421/',
    },
    'support_status': {
        'recipient':     'Mohamed',
        'ref':           'PL-7421',
        'subject_topic': 'City filter not saving',
        'status_key':    'in_progress',
        'status_lower':  'in progress',
        'status_pretty': 'In progress',
        'link':          'https://permitlify.com/support/tickets/PL-7421/',
    },
    'reset_password': {
        'name':          'Mohamed',
        'expires_in_hr': 1,
        'reset_link':    'https://permitlify.com/reset/?t=ZmFrZS10b2tlbi1mb3ItcHJldmlldy1vbmx5LWRvLW5vdC11c2U',
    },
}

def email_preview(request, template_name):
    from django.conf import settings as _s
    if not _s.DEBUG:
        raise Http404
    from django.template.loader import render_to_string
    fixture = dict(_EMAIL_PREVIEW_FIXTURES.get(template_name, {}))
    fixture.setdefault('year', date.today().year)
    try:
        html = render_to_string(f'core/emails/{template_name}.html', fixture)
    except Exception as e:
        return HttpResponse(f'<pre>Template render failed: {e}</pre>', status=500)
    return HttpResponse(html)


# ─────────────────────────────────────────────────────────────────────
# Admin: Blog editor
#
# Three-step authoring flow under /admin-panel/blog/:
#   1. List       — every published post + "+ New Post" button.
#   2. Editor     — paste URL → AJAX scrape (Firecrawl) → AJAX rewrite
#                   (Claude) → form fields → publish.
#   3. Settings   — three keys live in system_settings: claude_api_key,
#                   claude_model, firecrawl_api_key.
# ─────────────────────────────────────────────────────────────────────

from .blog_ai import (
    firecrawl_scrape, claude_rewrite, slugify as _ai_slugify,
    BlogAIError, DEFAULT_MODEL as _DEFAULT_CLAUDE_MODEL,
)


def _admin_ctx(request, **extra):
    """Tiny helper that builds the kwargs the admin sidebar expects
    (admin_initials / admin_name / today). Mirrors the pattern other
    admin views use without adding a new import surface."""
    user_id = request.session.get('user_id')
    user = get_user_by_id(user_id) or {} if user_id else {}
    name = (user.get('display_name') or user.get('email') or 'Admin').strip()
    initials = ''.join(part[:1].upper() for part in name.split()[:2]) or 'AD'
    ctx = {
        'admin_name':     name,
        'admin_initials': initials,
        'today':          date.today().strftime('%A, %B %-d, %Y'),
    }
    ctx.update(extra)
    return ctx


@admin_required
def admin_blog_view(request):
    """Blog post list. Search + pagination piggy-back on list_blog_posts."""
    q = (request.GET.get('q') or '').strip()
    try:
        page = int(request.GET.get('page') or 1)
    except (TypeError, ValueError):
        page = 1
    rows, total, total_pages, page = list_blog_posts(query=q, page=page, per_page=20)
    return render(request, 'core/admin_blog_list.html', _admin_ctx(
        request,
        active_section='blog',
        posts=rows,
        total=total,
        total_pages=total_pages,
        page=page,
        q=q,
    ))


@admin_required
def admin_blog_editor_view(request, slug=None):
    """Render the editor.

    * ``slug=None``  → blank "new post" form.
    * ``slug=<x>``   → load existing post for editing (the same form, just
                       pre-filled; Publish becomes "Save changes").
    """
    post = None
    if slug:
        post = get_blog_post(slug)
        if not post:
            raise Http404
    has_firecrawl = bool((get_system_setting('firecrawl_api_key') or '').strip())
    has_claude    = bool((get_system_setting('claude_api_key') or '').strip())
    return render(request, 'core/admin_blog_editor.html', _admin_ctx(
        request,
        active_section='blog',
        post=post,
        editing=bool(post),
        has_firecrawl=has_firecrawl,
        has_claude=has_claude,
    ))


def _json_err(msg, status=400):
    return JsonResponse({'ok': False, 'error': str(msg)}, status=status)


@admin_required
@require_http_methods(['POST'])
def admin_blog_scrape(request):
    """AJAX: scrape a URL via Firecrawl and return markdown + metadata."""
    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
    except json.JSONDecodeError:
        return _json_err('Invalid JSON body')
    try:
        result = firecrawl_scrape(body.get('url') or '')
    except BlogAIError as e:
        return _json_err(e)
    return JsonResponse({
        'ok':       True,
        'markdown': result['markdown'],
        'metadata': result['metadata'],
    })


@admin_required
@require_http_methods(['POST'])
def admin_blog_rewrite(request):
    """AJAX: hand scraped markdown to Claude and return a normalised post
    dict ready to drop into the editor form."""
    try:
        body = json.loads(request.body.decode('utf-8') or '{}')
    except json.JSONDecodeError:
        return _json_err('Invalid JSON body')
    try:
        post = claude_rewrite(
            scraped_markdown=body.get('markdown') or '',
            source_url=body.get('source_url') or '',
            extra_hint=body.get('hint') or '',
        )
    except BlogAIError as e:
        return _json_err(e)
    # Suggest a non-colliding slug if the AI's pick is taken.
    base_slug = post['slug']
    candidate = base_slug
    n = 2
    while slug_exists(candidate):
        candidate = f'{base_slug}-{n}'
        n += 1
        if n > 50:
            break
    post['slug'] = candidate
    return JsonResponse({'ok': True, 'post': post})


@admin_required
@require_http_methods(['POST'])
def admin_blog_publish(request):
    """Save (insert or update) a blog post.

    Accepts a normal form POST so the Publish button can be a plain
    ``<form>`` submit and we get free CSRF + browser nav semantics.
    """
    f = request.POST
    title = (f.get('title') or '').strip()
    if not title:
        return _json_err('Title is required')

    raw_slug   = (f.get('slug') or '').strip()
    slug       = _ai_slugify(raw_slug or title)
    original   = (f.get('original_slug') or '').strip()  # set when editing
    is_editing = bool(original)

    # If creating, auto-suffix to dodge collisions; if editing and the slug
    # changed to one that exists, refuse rather than silently overwrite a
    # different post.
    if not is_editing:
        candidate = slug
        n = 2
        while slug_exists(candidate):
            candidate = f'{slug}-{n}'
            n += 1
            if n > 50:
                break
        slug = candidate
    elif slug != original and slug_exists(slug):
        return _json_err(f"Slug '{slug}' already exists. Pick another.")

    # Preserve the original published_at on edit so the post keeps its
    # spot in the date-sorted list; only mint a new timestamp on create.
    # ``upsert_blog_post`` writes this into a NOT NULL TIMESTAMPTZ column,
    # so we must always supply a value.
    existing_published_at = None
    if is_editing:
        prior = get_blog_post(original)
        if prior:
            existing_published_at = prior.get('published_at')
    published_at = existing_published_at or datetime.utcnow()

    record = {
        'slug':            slug,
        'title':           title,
        'author':          (f.get('author') or 'Permitlify Team').strip(),
        'author_initials': (f.get('author_initials') or 'PL').strip()[:8],
        # ``upsert_blog_post`` reads this under the ``date`` key (writes to
        # the ``date_label`` column).
        'date':            (f.get('date_label') or date.today().strftime('%B %-d, %Y')).strip(),
        'published_at':    published_at,
        'read_time':       (f.get('read_time') or '5 min read').strip()[:40],
        'tag':             (f.get('tag') or 'Insights').strip()[:60],
        'tag_color':       (f.get('tag_color') or 'blue').strip()[:20],
        'thumb':           (f.get('thumb') or '📝').strip()[:8],
        'thumb_bg':        (f.get('thumb_bg') or 'linear-gradient(135deg,#1d4ed8,#059669)').strip(),
        'excerpt':         (f.get('excerpt') or '').strip(),
        'content':         (f.get('content') or '').strip(),
        'related':         [],
        'is_featured':     (f.get('is_featured') == 'on'),
    }
    if not record['excerpt']:
        return _json_err('Excerpt is required')
    if not record['content']:
        return _json_err('Content is required')

    # If editing AND the slug changed, drop the old row before upserting.
    if is_editing and slug != original:
        delete_blog_post(original)

    try:
        upsert_blog_post(record)
    except Exception as e:
        return _json_err(f'Database error: {e}', status=500)

    return JsonResponse({
        'ok':       True,
        'slug':     slug,
        'view_url': f'/blog/{slug}/',
        'edit_url': f'/admin-panel/blog/edit/{slug}/',
    })


@admin_required
@require_http_methods(['POST'])
def admin_blog_delete(request, slug):
    delete_blog_post(slug)
    return redirect('admin_blog')


@admin_required
def admin_blog_settings_view(request):
    """The 3-field AI config page (Firecrawl key, Claude key, Claude model)."""
    if request.method == 'POST':
        section = request.POST.get('section', '')
        try:
            if section == 'firecrawl':
                key = (request.POST.get('firecrawl_api_key') or '').strip()
                if key:
                    set_system_setting('firecrawl_api_key', key)
                result = {'ok': True, 'section': 'firecrawl'}
            elif section == 'claude':
                key   = (request.POST.get('claude_api_key') or '').strip()
                model = (request.POST.get('claude_model') or '').strip()
                if key:
                    set_system_setting('claude_api_key', key)
                if model:
                    set_system_setting('claude_model', model)
                result = {'ok': True, 'section': 'claude'}
            elif section == 'clear_firecrawl':
                set_system_setting('firecrawl_api_key', '')
                result = {'ok': True, 'section': 'clear_firecrawl'}
            elif section == 'clear_claude':
                set_system_setting('claude_api_key', '')
                result = {'ok': True, 'section': 'clear_claude'}
            else:
                result = {'ok': False, 'error': 'Unknown section'}
        except Exception as e:
            result = {'ok': False, 'error': str(e)}
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse(result)
        return redirect('admin_blog_settings')

    return render(request, 'core/admin_blog_settings.html', _admin_ctx(
        request,
        active_section='blog_settings',
        has_firecrawl=bool((get_system_setting('firecrawl_api_key') or '').strip()),
        has_claude=bool((get_system_setting('claude_api_key') or '').strip()),
        claude_model=(get_system_setting('claude_model') or '').strip() or _DEFAULT_CLAUDE_MODEL,
        default_claude_model=_DEFAULT_CLAUDE_MODEL,
    ))
