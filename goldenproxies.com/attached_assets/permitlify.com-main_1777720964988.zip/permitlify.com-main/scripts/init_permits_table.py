"""
Idempotent initializer for the `permits` table.

Run with:
    python scripts/init_permits_table.py

Creates the table if missing and ensures all indexes exist. Safe to re-run.
The table is designed to receive data pushed by the external scraper platform
via POST /api/v1/permits/ingest/. Each permit is uniquely identified by the
combination (source, source_permit_id) so the same permit re-pushed by the
scraper is upserted rather than duplicated.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'permitdaily.settings')
django.setup()

from core import pg


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS permits (
    id                  BIGSERIAL PRIMARY KEY,

    -- Provenance (which scraper produced this row, and its native id)
    source              TEXT        NOT NULL,
    source_permit_id    TEXT        NOT NULL,

    -- Identification & location
    permit_number       TEXT,
    state               TEXT        NOT NULL,
    city                TEXT        NOT NULL,
    jurisdiction        TEXT,
    address             TEXT,
    zip                 TEXT,
    latitude            DOUBLE PRECISION,
    longitude           DOUBLE PRECISION,

    -- Parties
    owner_name          TEXT,
    contractor_name     TEXT,
    contractor_phone    TEXT,
    contractor_email    TEXT,

    -- Work
    permit_type         TEXT,
    description         TEXT,
    trade               TEXT,
    status              TEXT,
    valuation_cents     BIGINT,
    square_feet         INTEGER,

    -- Dates
    applied_date        DATE,
    issued_date         DATE,
    expires_date        DATE,
    scraped_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- AI scoring (filled by scraper or by an enrichment job)
    ai_score            INTEGER,
    ai_grade            TEXT,
    ai_tier             TEXT,
    ai_reasoning        TEXT,
    ai_model_version    TEXT,
    ai_scored_at        TIMESTAMPTZ,

    -- Lineage: which scraper_runs row produced this permit. Nullable
    -- because (a) older permits pre-date the column, and (b) permits
    -- ingested via POST /api/v1/permits/ingest/ don't belong to any
    -- in-app run. The FK is added by core/db._ensure_scrapers_table()
    -- (it can only attach once the scraper_runs table exists), so this
    -- canonical CREATE just declares the bare BIGINT column to keep
    -- standalone init_permits_table.py runs idempotent.
    scraper_run_id      BIGINT,

    -- Full original payload from scraper (for debugging / re-processing)
    raw                 JSONB       NOT NULL DEFAULT '{}'::jsonb,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT permits_source_uid_uq UNIQUE (source, source_permit_id),
    CONSTRAINT permits_ai_score_range CHECK (ai_score IS NULL OR (ai_score BETWEEN 0 AND 100)),
    CONSTRAINT permits_ai_tier_vals   CHECK (ai_tier  IS NULL OR ai_tier IN ('hot','warm','cool'))
);

-- Idempotent additive migration for installs that already had the
-- table before scraper_run_id existed. ALTER TABLE … IF NOT EXISTS
-- is a no-op when the column is already present.
ALTER TABLE permits ADD COLUMN IF NOT EXISTS scraper_run_id BIGINT;

CREATE INDEX IF NOT EXISTS permits_state_city_idx     ON permits (state, lower(city));
CREATE INDEX IF NOT EXISTS permits_trade_idx          ON permits (trade);
CREATE INDEX IF NOT EXISTS permits_issued_date_idx    ON permits (issued_date DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS permits_ai_score_idx       ON permits (ai_score DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS permits_ai_tier_idx        ON permits (ai_tier);
CREATE INDEX IF NOT EXISTS permits_status_idx         ON permits (status);
CREATE INDEX IF NOT EXISTS permits_scraper_run_idx    ON permits (scraper_run_id) WHERE scraper_run_id IS NOT NULL;

-- Auto-bump updated_at on every UPDATE.
CREATE OR REPLACE FUNCTION permits_set_updated_at() RETURNS trigger AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS permits_set_updated_at ON permits;
CREATE TRIGGER permits_set_updated_at
    BEFORE UPDATE ON permits
    FOR EACH ROW
    EXECUTE FUNCTION permits_set_updated_at();
"""


def main():
    pg.execute(SCHEMA_SQL)
    rows = pg.query(
        """SELECT column_name, data_type FROM information_schema.columns
            WHERE table_name = 'permits' ORDER BY ordinal_position"""
    )
    print(f'permits table has {len(rows)} columns:')
    for r in rows:
        print(f'  - {r["column_name"]:<22} {r["data_type"]}')
    idx = pg.query(
        """SELECT indexname FROM pg_indexes
            WHERE tablename = 'permits' ORDER BY indexname"""
    )
    print(f'\nindexes ({len(idx)}):')
    for r in idx:
        print(f'  - {r["indexname"]}')


if __name__ == '__main__':
    main()
